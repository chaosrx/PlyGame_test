﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Flow", "System", "Game is Paused", BlockType.Condition, Order = 0, ShowName = "Game is Paused",
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if the game is in a paused state.")]
	public class plyGame_IsPaused_plyBlock : Bool_Value
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GameGlobal.Paused;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}