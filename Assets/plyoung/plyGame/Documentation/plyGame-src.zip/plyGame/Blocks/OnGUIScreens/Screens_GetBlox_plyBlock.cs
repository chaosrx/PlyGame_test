﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Get Blox", BlockType.Variable, Order = 10, ShowName="Screens Blox",
		ReturnValueString = "Return - plyBlox", ReturnValueType = typeof(plyBlox_Value),
		Description = "Return a reference to the plyBlox of the Screens System (GUIManager).")]
	public class Screens_GetBlox_plyBlock : plyBlox_Value
	{
		public override void Created()
		{
			GameGlobal.Create();
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GUIManager.Instance.bloxObject;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}