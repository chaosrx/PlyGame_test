﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Screen Resolution Changed", BlockType.Action, Order = 10, ShowName = "Inform Screens Of Resolution Change",
		Description = "Inform the screens that the screen resolution changed so that the element positions can be recalculated.")]
	public class InformScreensOfResChange_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.uiManager.ScreenResolutionChanged();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}