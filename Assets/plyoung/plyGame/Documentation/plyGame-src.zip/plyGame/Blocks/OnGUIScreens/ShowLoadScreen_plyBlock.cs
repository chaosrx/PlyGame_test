﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Show Load Screen", BlockType.Action, Order = 10, 
		ShowName = "Show Load Screen",
		Description = "Will hide all screens and show a random Load Screen or a simple 'now loading' if no load screens are defined.")]
	public class ShowLoadScreen_plyBlock : plyBlock
	{

		[plyBlockField("Screen", ShowValue = true, EmptyValueName="-random-", SubName="Screen Index or Name", Description="The Loading Screen index (Integer) or name (String). Leave empty to show random load screen or if you did not define any load screens.")]
		public plyValue_Block screen;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (screen == null) GameGlobal.Instance.uiManager.ShowLoadScreen();
			else
			{
				object o = screen.RunAndGetValue();
				if (o == null)
				{
					Log(LogType.Warning, "The provided type is not an Integer or String. Screen Name or Index should be provided. Now showing random loading screen.");
					GameGlobal.Instance.uiManager.ShowLoadScreen();
				}
				else
				{
					if (o.GetType() == typeof(int))
					{
						GameGlobal.Instance.uiManager.ShowLoadScreen((int)o);
					}
					else if (o.GetType() == typeof(string))
					{
						GameGlobal.Instance.uiManager.ShowLoadScreen((string)o);
					}
					else
					{
						Log(LogType.Warning, "The provided type is not an Integer or String. Screen Name or Index should be provided. Now showing random loading screen.");
						GameGlobal.Instance.uiManager.ShowLoadScreen();
					}
				}
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}