﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Hide Load Screen", BlockType.Action, Order = 10,
		ShowName = "Hides Load Screen",
		Description = "Will hide any visible load screen.")]
	public class HideLoadScreen_plyBlock : plyBlock
	{

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.uiManager.HideLoadScreen();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}