﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Set Listener Follow", BlockType.Action, Order = 1, ShowIcon = "listener", ShowName = "Set Listener",
		Description = "Set the target for the plyGame created audio listener to follow.")]
	public class plyGame_Audio_Follow : plyBlock
	{
		[plyBlockField("Follow", SubName = "Target - GameObject", EmptyValueName="-none-", ShowName = true, ShowValue = true, Description = "The GameObject to follow. Leaving this empty will make cause the listener to stop following any current target.")]
		public GameObject_Value target;

		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameObject go = target == null ? null : target.RunAndGetGameObject();
			GameGlobal.Instance.SetAudioListenerFollow(go);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}