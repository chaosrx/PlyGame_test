﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Reset Last Load", BlockType.Action, Order = 1, ShowName = "Reset Last-Load",
		Description = "The LoadSave System needs to keep track of what slot the game was last loaded/ restored from. If the player starts a 'new game' you need to make a call to this Block to tell the LoadSave System that a new game was started and the last load needs to be reset.")]
	public class LoadSave_ResetLastLoad_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.ResetLastLoadSlot();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}