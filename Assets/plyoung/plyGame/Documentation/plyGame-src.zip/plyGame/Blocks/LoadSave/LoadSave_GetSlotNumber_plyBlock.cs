﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Get Slot Number", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Return a slot number from the active LoadSave Profile. The saved slots are indexed from 0 up to one less that what 'Get Slot Count' Block returned. The actual slot number might not be the same as its saved position. Slot saved at position 1 in the file might be called slot 5. So you use this Block to get that actual slot number to be used in other Blocks.")]
	public class LoadSave_GetSlotNumber_plyBlock : Int_Value
	{

		[plyBlockField("Get LoadSave Slot Number at index", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), EmptyValueName = "-invalid-", SubName = "Slot Index- Integer", Description = "The index to get the slot number from.")]
		public Int_Value slotIndex;


		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slotIndex != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot index must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			int index = slotIndex.RunAndGetInt();
			value = GameGlobal.GetSavedSlotNumber(index);
			if (value == -1)
			{
				blockIsValid = false;
				Log(LogType.Error, "The Slot number could not be found at index: " + index);
				return BlockReturn.Error;
			}
			else return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}