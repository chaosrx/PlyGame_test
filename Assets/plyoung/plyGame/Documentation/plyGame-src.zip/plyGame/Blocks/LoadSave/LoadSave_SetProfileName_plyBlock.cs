﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Set Profile (name)", BlockType.Action, Order = 1,
		Description = "Set the active profile by name.")]
	public class LoadSave_SetProfileName_plyBlock : plyBlock
	{
		[plyBlockField("Set LoadSave Profile to", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), EmptyValueName = "-invalid-", SubName = "Profile Name - String", Description = "The name of the profile to activate. Profile will be added if not exist yet.")]
		public String_Value name;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = name != null;
			if (!blockIsValid) Log(LogType.Error, "The Profile name must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			string nm = name.RunAndGetString();
			
			if (string.IsNullOrEmpty(nm))
			{
				//blockIsValid = false; do not make block invalid so that it will run if called again - kind like a silent fail (technically the designer should have checked the name before calling this block)
				Log(LogType.Warning, "The Profile name can not be empty.");
				return BlockReturn.Error;
			}

			GameGlobal.SetActiveProfile(nm);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}