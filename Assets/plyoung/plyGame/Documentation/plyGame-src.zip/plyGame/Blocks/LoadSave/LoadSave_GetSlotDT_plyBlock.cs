﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Get Slot DateTime", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Return the recorded Date and Time that the slot was last saved in active LoadSave Profile. Returned value (string) will be empty if slot was not yet saved.")]
	public class LoadSave_GetSlotDT_plyBlock : String_Value
	{
		[plyBlockField("Slot", ShowAfterField ="DateTime", ShowName = true, ShowValue = true, EmptyValueName = "-current-", SubName = "Slot - Integer", Description = "The slot to get DateTime for. Leave empty if currently set slot should be used. Will change the current/ active slot to this one if set.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			//if (slot != null) GameGlobal.SetActiveSaveSlot(slot.RunAndGetInt());
			//value = GameGlobal.GetActiveSlotDateTime();
			if (slot == null) value = GameGlobal.GetActiveSlotDateTime();
			else value = GameGlobal.GetSlotDateTime(slot.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}