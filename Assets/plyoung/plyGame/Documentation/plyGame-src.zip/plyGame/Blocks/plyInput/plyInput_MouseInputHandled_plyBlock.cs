﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Input", "Input (plyGame)", "Mouse Button Handled", BlockType.Condition, Order = 1, ShowName = "Mouse Button Handled",
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if a mouse click was handled in this frame. This normally happens when the click was done over a user interface element, like a button; so this is useful to prevent 'GUI click-through'. Note that this should be used in an Update event and will not function correctly in the LateUpdate event.")]
	public class plyInput_MouseInputHandled_plyBlock : Bool_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = plyInput.MouseInputHandled;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}