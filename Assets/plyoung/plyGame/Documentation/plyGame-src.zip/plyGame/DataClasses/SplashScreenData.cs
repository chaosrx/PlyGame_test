﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class SplashScreenData
	{
		public GUIScreen screen;
		public float autoChangeTime = 2f;	// after how many seconds should this screen be auto-skipped?
		public bool allowSkipping = true;	// player allowed to skip this screen
#if MOVIE_SUPPORT
		public int autoAfterMovie = -1;		// movie block to watch to determine when to skip to next screen (when movie done)
#endif

		// ============================================================================================================

		public override string ToString()
		{
			return screen.name;
		}

		// ============================================================================================================
	}
}