﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Called when plyGame wants to create instance of prefab. Only some systems makes use of this. </summary>
	public interface IplyPool
	{
		GameObject Instantiate(GameObject prefab);
		void Destroy(GameObject gameObject);
	}

	// ================================================================================================================
}