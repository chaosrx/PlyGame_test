﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	public class LoadSaveTempKeyStore
	{

		// ============================================================================================================

		public Dictionary<string, bool> boolKeys = new Dictionary<string, bool>(0);
		public Dictionary<string, int> intKeys = new Dictionary<string, int>(0);
		public Dictionary<string, float> floatKeys = new Dictionary<string, float>(0);
		public Dictionary<string, string> stringKeys = new Dictionary<string, string>(0);
		public Dictionary<string, Vector2> vector2Keys = new Dictionary<string, Vector2>(0);
		public Dictionary<string, Vector3> vector3Keys = new Dictionary<string, Vector3>(0);
		public Dictionary<string, Vector4> vector4Keys = new Dictionary<string, Vector4>(0);
		public Dictionary<string, Rect> rectKeys = new Dictionary<string, Rect>(0);
		public List<string> deleteKeys = new List<string>(0);

		// <level, keys in the level>
		private Dictionary<int, List<string>> createLoadKeys = new Dictionary<int, List<string>>(0);
		private Dictionary<int, List<string>> createLoadKeys_deleted = new Dictionary<int, List<string>>(0);

		public void ClearData()
		{
			boolKeys = new Dictionary<string, bool>(0);
			intKeys = new Dictionary<string, int>(0);
			floatKeys = new Dictionary<string, float>(0);
			stringKeys = new Dictionary<string, string>(0);
			vector2Keys = new Dictionary<string, Vector2>(0);
			vector3Keys = new Dictionary<string, Vector3>(0);
			vector4Keys = new Dictionary<string, Vector4>(0);
			rectKeys = new Dictionary<string, Rect>(0);
			deleteKeys = new List<string>(0);
			createLoadKeys = new Dictionary<int, List<string>>(0);
			createLoadKeys_deleted = new Dictionary<int, List<string>>(0);
		}

		public void PersistData(string mainKey, LoadSaveProviderBase lsp)
		{
			// keep tract of all saved keys so that system knows what belongs to this
			// main key. too bad Unity do not provide a way to run through all keys 
			// in PlayerPrefs cause then this did not have to be done

			string k = lsp.GetString(mainKey + ".keys", "");
			foreach (KeyValuePair<string, bool> kv in boolKeys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, int> kv in intKeys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, float> kv in floatKeys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, string> kv in stringKeys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, Vector2> kv in vector2Keys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, Vector3> kv in vector3Keys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, Vector4> kv in vector4Keys) k = CheckExistingKeys(k, kv.Key);
			foreach (KeyValuePair<string, Rect> kv in rectKeys) k = CheckExistingKeys(k, kv.Key);
			lsp.SetString(mainKey + ".keys", k);

			// save the data

			k = mainKey + ".";
			foreach (KeyValuePair<string, bool> kv in boolKeys) lsp.SetBool(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, int> kv in intKeys) lsp.SetInt(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, float> kv in floatKeys) lsp.SetFloat(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, string> kv in stringKeys) lsp.SetString(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, Vector2> kv in vector2Keys) lsp.SetVector2(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, Vector3> kv in vector3Keys) lsp.SetVector3(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, Vector4> kv in vector4Keys) lsp.SetVector4(k + kv.Key, kv.Value);
			foreach (KeyValuePair<string, Rect> kv in rectKeys) lsp.SetRect(k + kv.Key, kv.Value);
			foreach (string key in deleteKeys) lsp.DeleteKey(k + key);

			// save CreateLoad keys

			foreach (KeyValuePair<int, List<string>> kv in createLoadKeys)
			{
				k = mainKey + ".clk" + kv.Key;
				string s = lsp.GetString(k, "");
				for (int i = 0; i < kv.Value.Count; i++)
				{
					string s2 = kv.Value[i] + (char)31;
					if (false == s.Contains(s2)) s += s2;
				}
				lsp.SetString(k, s);
			}

			foreach (KeyValuePair<int, List<string>> kv in createLoadKeys_deleted)
			{
				k = mainKey + ".clk" + kv.Key;
				string s = lsp.GetString(k, "");
				for (int i = 0; i < kv.Value.Count; i++)
				{
					string s2 = kv.Value[i] + (char)31;
					s = s.Replace(s2, "");
				}
				lsp.SetString(k, s);
			}

			// done

			ClearData();
		}

		// ============================================================================================================

		public void AddCreateLoadKey(int level, string key)
		{
			if (false == createLoadKeys.ContainsKey(level)) createLoadKeys.Add(plyUtil.loadedLevel, new List<string>(0));
			if (false == createLoadKeys[level].Contains(key)) createLoadKeys[level].Add(key);
			if (createLoadKeys_deleted.ContainsKey(level)) createLoadKeys_deleted[level].Remove(key);
		}

		public void RemoveCreateLoadKey(int level, string key)
		{
			if (false == createLoadKeys_deleted.ContainsKey(level)) createLoadKeys_deleted.Add(level, new List<string>(0));
			if (false == createLoadKeys_deleted[level].Contains(key)) createLoadKeys_deleted[level].Add(key);
			if (createLoadKeys.ContainsKey(level)) createLoadKeys[level].Remove(key);
		}

		public string GetMergedCreateLoadKeys(int level, string keys)
		{
			if (createLoadKeys.ContainsKey(level))
			{
				for (int i = 0; i < createLoadKeys[level].Count; i++)
				{
					string s = createLoadKeys[level][i] + (char)31;
					if (!keys.Contains(s)) keys += s;
				}
			}

			if (createLoadKeys_deleted.ContainsKey(level))
			{
				for (int i = 0; i < createLoadKeys_deleted[level].Count; i++)
				{
					string s = createLoadKeys_deleted[level][i] + (char)31;
					keys = keys.Replace(s, "");
				}
			}

			return keys;
		}

		// ============================================================================================================

		private string CheckExistingKeys(string existingKeys, string key)
		{
			// first check if key not already present and then add if not
			if (existingKeys.Contains(key + (char)31)) return existingKeys;
			existingKeys += key + (char)31;
			return existingKeys;
		}

		public void DeleteKey(string key)
		{
			if (!deleteKeys.Contains(key)) deleteKeys.Add(key);
			boolKeys.Remove(key);
			intKeys.Remove(key);
			floatKeys.Remove(key);
			stringKeys.Remove(key);
			vector2Keys.Remove(key);
			vector3Keys.Remove(key);
			vector4Keys.Remove(key);
			rectKeys.Remove(key);
		}

		public void SetString(string key, string value)
		{
			deleteKeys.Remove(key);
			if (stringKeys.ContainsKey(key)) stringKeys[key] = value;
			else stringKeys.Add(key, value);
		}

		public void SetInt(string key, int value)
		{
			deleteKeys.Remove(key);
			if (intKeys.ContainsKey(key)) intKeys[key] = value;
			else intKeys.Add(key, value);
		}

		public void SetFloat(string key, float value)
		{
			deleteKeys.Remove(key);
			if (floatKeys.ContainsKey(key)) floatKeys[key] = value;
			else floatKeys.Add(key, value);
		}

		public void SetBool(string key, bool value)
		{
			deleteKeys.Remove(key);
			if (boolKeys.ContainsKey(key)) boolKeys[key] = value;
			else boolKeys.Add(key, value);
		}

		public void SetVector2(string key, Vector2 value)
		{
			deleteKeys.Remove(key);
			if (vector2Keys.ContainsKey(key)) vector2Keys[key] = value;
			else vector2Keys.Add(key, value);
		}

		public void SetVector3(string key, Vector3 value)
		{
			deleteKeys.Remove(key);
			if (vector3Keys.ContainsKey(key)) vector3Keys[key] = value;
			else vector3Keys.Add(key, value);
		}

		public void SetVector4(string key, Vector4 value)
		{
			deleteKeys.Remove(key);
			if (vector4Keys.ContainsKey(key)) vector4Keys[key] = value;
			else vector4Keys.Add(key, value);
		}

		public void SetRect(string key, Rect value)
		{
			deleteKeys.Remove(key);
			if (rectKeys.ContainsKey(key)) rectKeys[key] = value;
			else rectKeys.Add(key, value);
		}

		//public string GetString(string key, string defaultVal)
		//{
		//	if (stringKeys.ContainsKey(key)) return stringKeys[key];
		//	return defaultVal;
		//}

		//public int GetInt(string key, int defaultVal)
		//{
		//	if (intKeys.ContainsKey(key)) return intKeys[key];
		//	return defaultVal;
		//}

		//public float GetFloat(string key, float defaultVal)
		//{
		//	if (floatKeys.ContainsKey(key)) return floatKeys[key];
		//	return defaultVal;
		//}

		//public bool GetBool(string key, bool defaultVal)
		//{
		//	if (boolKeys.ContainsKey(key)) return boolKeys[key];
		//	return defaultVal;
		//}
		
		//public Vector2 GetVector2(string key, Vector2 defaultVal)
		//{
		//	if (vector2Keys.ContainsKey(key)) return vector2Keys[key];
		//	return defaultVal;
		//}

		//public Vector3 GetVector3(string key, Vector3 defaultVal)
		//{
		//	if (vector3Keys.ContainsKey(key)) return vector3Keys[key];
		//	return defaultVal;
		//}

		//public Vector4 GetVector4(string key, Vector4 defaultVal)
		//{
		//	if (vector4Keys.ContainsKey(key)) return vector4Keys[key];
		//	return defaultVal;
		//}

		//public Rect GetRect(string key, Rect defaultVal)
		//{
		//	if (rectKeys.ContainsKey(key)) return rectKeys[key];
		//	return defaultVal;
		//}

		// ============================================================================================================
	}
}