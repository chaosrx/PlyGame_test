﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("")]
	public class Bootstrap : MonoBehaviour
	{
		// ============================================================================================================

		private enum State
		{
			Startup,
			ShowFirstSplash,
			ShowingSplashScreens,
			ShowLanguageSelect,
			WaitingForLangSelection,
			LoadResources,
			Done,
			None,
		}

		private State state = State.Startup;

		private int currSplash = 0;
		private float timer = 0f;
#if MOVIE_SUPPORT
		private OnGUIMovie watchMovie = null;
#endif

		private int customScreenID = -1; // the ID not index, of custom screen
		private string loadScene = "";
		private GUIScreen langScr;
		private List<GUIScreen> splashScreens = new List<GUIScreen>();

		// ============================================================================================================

		protected void Awake()
		{
			if (GameGlobal.EditorRunMode)
			{	// Play in Editor: The user pressed Unity play button. Need to skip normal startup process
				state = State.LoadResources;
			}
			else
			{	// Start normal startup process
				state = State.Startup;
			}
		}

		protected void Update()
		{
			switch (state)
			{
				case State.Startup:
				{
					LoadStartupScreens();
					state = State.ShowFirstSplash;
				} break;

				case State.ShowFirstSplash:
				{
					if (splashScreens.Count > 0)
					{
						currSplash = 0;
						timer = GameGlobal.Instance.splashAsset.screens[currSplash].autoChangeTime;
						GameGlobal.Instance.uiManager.Show(splashScreens[currSplash], true);
#if MOVIE_SUPPORT
						watchMovie = (OnGUIMovie)splashScreens[currSplash].GetElement(GameGlobal.Instance.splashAsset.screens[currSplash].autoAfterMovie);
#endif
						state = State.ShowingSplashScreens;
					}
					else
					{
						state = State.ShowLanguageSelect;
					}
				} break;

				case State.ShowingSplashScreens:
				{
#if MOVIE_SUPPORT
					if (watchMovie != null)
					{
						if (watchMovie.IsPlaying) timer = 99f;
						else timer = 0f;
					}
#endif
					if (GameGlobal.Instance.splashAsset.screens[currSplash].allowSkipping)
					{
						if (Input.anyKeyDown) timer = 0f;
					}

					timer -= Time.deltaTime;
					if (timer <= 0)
					{
						GameGlobal.Instance.uiManager.Show(splashScreens[currSplash], false);
						currSplash++;
						if (currSplash < GameGlobal.Instance.splashAsset.screens.Count)
						{
							timer = GameGlobal.Instance.splashAsset.screens[currSplash].autoChangeTime;
							GameGlobal.Instance.uiManager.Show(splashScreens[currSplash], true);
#if MOVIE_SUPPORT
							watchMovie = (OnGUIMovie)splashScreens[currSplash].GetElement(GameGlobal.Instance.splashAsset.screens[currSplash].autoAfterMovie);
#endif
						}
						else
						{
							state = State.ShowLanguageSelect;
						}
					}
				} break;

				case State.ShowLanguageSelect:
				{
					// change save slot to the default "0", from "-1", since this is a proper play test or stand-alone and not Unity Play button test
					GameGlobal.SetActiveSaveSlot(0);

					// check if there are any elements present on the language screen and show it if so
					if (langScr.uiElements.Count > 0)
					{						
						GameGlobal.Instance.uiManager.Show(langScr, true);
						state = State.WaitingForLangSelection;
					}
					else
					{	// use default language, no language selection screen is used
						state = State.LoadResources;
					}
				} break;

				case State.LoadResources:
				{
					GameGlobal.Instance.uiManager.ShowSimpleLoad();
					DoneWithStartupScreens();
					GameGlobal.Instance.LoadLanguageDependentData();
					state = State.Done;

					// clean up the resources that are no longer referenced
					Resources.UnloadUnusedAssets();

					if (GameGlobal.EditorRunMode)
					{	// Play in Editor: The use pressed Unity play button. Need to skip normal startup process
						state = State.None;
						GUIManager.Instance.HideAllScreens(true);

						// Destroy the Bootstrap object, done with it
						Destroy(gameObject);
					}
				} break;

				case State.Done:
				{
					state = State.None;
					if (!string.IsNullOrEmpty(loadScene))
					{
						plyUtil.LoadLevel(loadScene);
					}
					else
					{
						GUIScreen scr = GUIManager.Instance.GetScreen(customScreenID);
						if (scr != null)
						{
							GUIManager.Instance.HideAllScreens(true);
							GUIManager.Instance.Show(scr, true);
						}
						else
						{
							Debug.LogWarning("You have not specified any Custom Screen or any Level (scene) to load after the splash screens. Have a look at the documentation related to Screens to learn more about this. plyGame will now attempt to load the 1st valid Level from the build settings list.");
							plyUtil.LoadLevel(1);
						}

						// Destroy the Bootstrap object, done with it
						Destroy(gameObject);
					}
				} break;
			}
		}

		private void LoadStartupScreens()
		{
			customScreenID = GameGlobal.Instance.langScrAsset.nextScreen;
			loadScene = GameGlobal.Instance.langScrAsset.nextScene;

			for (int i = 0; i < GameGlobal.Instance.splashAsset.screens.Count; i++)
			{
				GUIScreen scr = GUIScreen.CreateInstance(GameGlobal.Instance.splashAsset.screens[i].screen);
				scr.Init();
				splashScreens.Add(scr);
			}

			langScr = GUIScreen.CreateInstance(GameGlobal.Instance.langScrAsset.screenData);
			langScr.Init();

			// Register the language button callbacks
			OnGUIButton o = langScr.GetElement(GameGlobal.Instance.langScrAsset.defaultLangBlockId) as OnGUIButton;
			if (o != null) o.SetCallback(OnLangButtonClick, new object[] { -1 });

			for (int i = 0; i < GameGlobal.Instance.langScrAsset.langBlockIds.Count; i++)
			{
				o = langScr.GetElement(GameGlobal.Instance.langScrAsset.langBlockIds[i]) as OnGUIButton;
				if (o != null) o.SetCallback(OnLangButtonClick, new object[] { i });
			}
		}

		private void DoneWithStartupScreens()
		{
			GameGlobal.Instance.uiManager.RemoveAllScreens();
#if MOVIE_SUPPORT
			watchMovie = null;
#endif
			// unload all the startup assets
			GameGlobal.Instance.splashAsset = null;
			GameGlobal.Instance.langScrAsset = null;
		}

		private void OnLangButtonClick(object sender, object[] args)
		{
			int i = (int)args[0];
			if (i >= 0 && i < Languages.Instance.DefinedLanguages.Count)
			{
				GameGlobal.Instance._internalSelectedLang = Languages.Instance.DefinedLanguages[i];				
			}
			state = State.LoadResources;
		}

		// ============================================================================================================
	}
}