﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Follow Target Object")]
	public class FollowTargetObject : MonoBehaviour
	{
		public Transform target;
		public bool updatePosition = true;
		public bool updateRotation = true;

		private Transform _tr;

		protected void Awake()
		{
			_tr = transform;
		}

		protected void LateUpdate()
		{
			if (target == null)
			{
				enabled = false;
				return;
			}

			_tr.position = target.position;

		}

		// ============================================================================================================
	}
}