﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// This will make an object fall to the floor. You need to instantiate the Item in the air
	/// then attach this component. The Item will then be dropped to the floor but at an arc
	/// from the start position. The object should have a collider. This component will 
	/// remove itself when done.
	/// </summary>
	[AddComponentMenu("")]
	public class FallToFloor : MonoBehaviour
	{
		//public bool useRB = false;
		public bool freezeRotation = false;
		public bool giveRandomPush = true;
		public Vector3 forwardVelocity = Vector3.zero; // not used if giveRandomPush = true

		private List<Collider> changedTriggers = new List<Collider>();
		private Rigidbody rb;
		private bool removeRB = false;
		private bool rotWasFrozen = false;

		//private float MOVESPEED1 = 8f;
		//private float MOVESPEED2 = 10f;

		//private LayerMask floorWallMask;
		//private Vector3 targetPos;
		//private float maxDist;
		//private bool falling = false;

		protected void Start()
		{
			//if (useRB)
			{
				// make sure there is rigidbody so it can handle the physics
				rb = gameObject.GetComponent<Rigidbody>();
				if (rb == null)
				{
					removeRB = true;
					rb = gameObject.AddComponent<Rigidbody>();
					rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
				}
				else
				{
					rotWasFrozen = rb.freezeRotation;
				}

				rb.freezeRotation = freezeRotation;

				// make sure all colliders are active and not triggers
				Collider[] c = gameObject.GetComponentsInChildren<Collider>();
				for (int i = 0; i < c.Length; i++)
				{
					if (c[i].isTrigger)
					{
						changedTriggers.Add(c[i]);
						c[i].isTrigger = false;
					}
				}

				// give the item a little push so the drop looks better
				if (giveRandomPush)
				{
					float x = Random.Range(1.5f, 2.5f) * (Random.Range(0, 2) == 0 ? -1 : 1);
					float z = Random.Range(1.5f, 2.5f) * (Random.Range(0, 2) == 0 ? -1 : 1);
					rb.velocity = new Vector3(x, 1.5f, z);
					//rigidbody.velocity = Random.onUnitSphere * 3f;
				}
				else
				{
					rb.velocity = forwardVelocity;
				}
			}
			//else
			//{
			//	floorWallMask = (1 << GameGlobal.LayerMapping.Floor | 1 << GameGlobal.LayerMapping.Wall);

			//	// calculate a destination position for the item
			//	if (giveRandomPush)
			//	{
			//		forwardVelocity = Random.insideUnitCircle;
			//		forwardVelocity.y = 0f;
			//	}

			//	targetPos = transform.position + (forwardVelocity * Random.Range(1f, 2f));
			//	maxDist = Vector3.Distance(transform.position, targetPos);
			//}
		}

		//protected void Update()
		//{
		//	if (!useRB)
		//	{
		//		if (falling == false)
		//		{
		//			// check if will hit wall or floor
		//			float f = Time.deltaTime * MOVESPEED1;
		//			if (Physics.Raycast(transform.position, forwardVelocity, f, floorWallMask))
		//			{
		//				falling = true;
		//			}
		//			else
		//			{
		//				transform.position += forwardVelocity * f;
		//				float d = Vector3.Distance(transform.position, targetPos);
		//				if (d < 0.5f || d > maxDist) falling = true;
		//			}
		//		}
		//		else
		//		{
		//			// check if floor or wall hit yet
		//			float f = Time.deltaTime * MOVESPEED2;
		//			RaycastHit hit;
		//			if (Physics.Raycast(transform.position, Vector3.down, out hit, f, floorWallMask))
		//			{
		//				transform.position = hit.point;
		//				Destroy(this);
		//			}
		//			else
		//			{
		//				transform.position += Vector3.down * f;
		//			}
		//		}

		//	}
		//}

		protected void LateUpdate()
		{
			//if (useRB)
			{
				if (rb == null) return;
				if (rb.IsSleeping())
				{
					for (int i = 0; i < changedTriggers.Count; i++) changedTriggers[i].isTrigger = true;
					if (removeRB) Destroy(rb);
					else rb.freezeRotation = rotWasFrozen;
					Destroy(this);
				}
			}
		}

		// ============================================================================================================
	}
}