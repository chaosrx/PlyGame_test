﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_LoadSaveSystem : plyEventHandler
	{
		private List<plyEvent> loadEvents = new List<plyEvent>(0);
		private List<plyEvent> saveEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			loadEvents = new List<plyEvent>(0);
			saveEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On After Load")) loadEvents.Add(e);
			else if (e.uniqueIdent.Equals("On After Save")) saveEvents.Add(e);
		}

		public override void CheckEvents()
		{
			loadEvents.TrimExcess();
			saveEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnAfterLoad()
		{
			if (loadEvents.Count == 0) return;
			RunEvents(loadEvents);
		}

		public void OnAfterSave()
		{
			if (saveEvents.Count == 0) return;
			RunEvents(saveEvents);
		}

		// ============================================================================================================
	}
}
