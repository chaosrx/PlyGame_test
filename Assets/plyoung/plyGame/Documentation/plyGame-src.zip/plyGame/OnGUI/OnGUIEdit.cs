﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIEdit : OnGUIElement
	{

		public string initText = "";

		// ============================================================================================================

		[System.NonSerialized] public string text;

		// ============================================================================================================

		public OnGUIEdit()
		{
			type = UIElementType.Edit;
			styleName = "textfield";
		}

		public override OnGUIElement Copy()
		{
			OnGUIEdit obj = new OnGUIEdit();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUIEdit o = obj as OnGUIEdit;
			o.initText = this.initText;
		}

		// ============================================================================================================

		public override void Init()
		{
			text = initText;
		}

		public override void Draw()
		{
			text = GUI.TextField(frame, text, style);
		}

		public override void EdDraw(Rect r)
		{
			GUI.Box(r, initText, style);
		}

		public override void SetText(string txt)
		{
			text = txt;
		}

		// ============================================================================================================
	}
}