﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	/// <summary>
	/// Base class for Input Definers. An input definer is called when the
	///  Reset is called in plyGame Input Manager settings to define inputs.
	/// </summary>
	public class InputDefiner
	{

		/// <summary>
		/// Overwrite to be called when it is time to define input. Should return a
		/// list of newly defined input to be added to main list of inputs.
		/// </summary>
		public virtual List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>(0);
		}

		// ============================================================================================================
	}
}
