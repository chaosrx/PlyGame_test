﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	[System.Serializable]
	public class EdDataAsset : ScriptableObject
	{

		[HideInInspector] public string bootstrapScene;

		// ============================================================================================================
	}
}