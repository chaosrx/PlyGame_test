﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommonEditor;
using plyBloxKitEditor;
using plyGame;

namespace plyGameEditor
{
	[ExecuteInEditMode]
	public class CustomHierarchy
	{

		static CustomHierarchy()
		{
			EditorApplication.hierarchyWindowItemOnGUI += OnDrawListItem;
		}

		private static void OnDrawListItem(int id, Rect area)
		{
			//drawInfo = EditorPrefs.GetBool("UnitySerializer.drawHierarchy", true);
			//if (!drawInfo)
			//	return;

			//var go = EditorUtility.InstanceIDToObject(id) as GameObject;
			//if (go == null)
			//	return;
			//if (go.transform.parent == null)
			//	width = area.width;

			//area.width = 16;
			//area.height = 16;

			//if (go.GetComponent<SaveGameManager>() || go.GetComponent<RoomDataSaveGameStorage>() || go.GetComponent<RadicalRoutineHelper>())
			//{
			//	area.x = width - 54;
			//	GUI.DrawTexture(area, manager);
			//}

			//var c = go.GetComponent<uniqueIdentifier>();
			//if (c != null)
			//{
			//	area.x = width - 36;
			//	if (c.GetType() == typeof(uniqueIdentifier) && uid != null)
			//	{

			//		GUI.DrawTexture(area, uid);
			//	}
			//	if (c.GetType() == typeof(StoreInformation) && store != null)
			//	{
			//		GUI.DrawTexture(area, store);
			//	}
			//	if (c.GetType() == typeof(Prefab.identifier) && prefab != null)
			//	{
			//		GUI.DrawTexture(area, prefab);
			//	}

			//}

			//if (go.GetComponent<DontStoreObjectInRoom>() != null && room != null)
			//{
			//	area.x = width;
			//	GUI.DrawTexture(area, room);

			//}
			//if (go.GetComponent<StoreMaterials>() != null && materials != null)
			//{
			//	area.x = width - 18;
			//	GUI.DrawTexture(area, materials);
			//	area.x += 18;
			//}
		}

		// ============================================================================================================
	}
}
