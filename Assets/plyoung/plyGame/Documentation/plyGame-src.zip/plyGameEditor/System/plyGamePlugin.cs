﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyBloxKitEditor;

namespace plyGameEditor
{
	/// <summary>
	/// Contain info on a plyGame plugin
	/// </summary>
	public class plyGamePluginInfo
	{

		/// <summary>
		/// Name of the plugin
		/// </summary>
		public string name = null;

		/// <summary>
		/// Version of the plugin. Will be overwritten by info from 
		/// versionFile if versioFile is set
		/// </summary>
		public string version = "Version: 0.0.0";

		/// <summary>
		/// Uniquely identifiable path to the version file of the plugin.
		/// The version file is simply a text file which includes the version number
		/// on the first line. You can add other info, for example update notes,
		/// in the text file too (as long as the version to show is on the first line)
		/// Leave null if you want to set version directly
		/// ex. "plyRPG/Documentation/version.txt"
		/// </summary>
		public string versionFile = null;

		// ============================================================================================================
	}
}
