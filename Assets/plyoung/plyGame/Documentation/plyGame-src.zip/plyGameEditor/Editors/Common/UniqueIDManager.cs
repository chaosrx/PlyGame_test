﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyBloxKit;
using plyCommonEditor;
using plyBloxKitEditor;

namespace plyGameEditor
{
	public class UniqueIDManager
	{
		public static Dictionary<Object, UniqueID> ids = new Dictionary<Object, UniqueID>();

		// return true if changed the id. Returns true if had to create new id and SetDirty should be called
		// obj: Is the target
		// prefabLink: is a helper that should be inited to null
		// id: Is the unique id
		// onFocus: Should be true if this is called from OnFocus/Enable and not OnGUI/OnInspectorGUI
		// alwaysUnique: Must always be unique among prefabs and scene objects, even if scene object comes from prefab
		public static bool CheckID(Object obj, ref Object prefabLink, ref UniqueID id, UniqueID prefabUniqueId, bool onFocus, bool alwaysUnique)
		{
			// this should not run when in play mode as it will mess up runtime created objects
			if (EditorApplication.isPlaying) return false;

			if (obj == null)
			{
				//Debug.LogError("obj = null");
				return false;
			}

			if (false == EditorUtility.IsPersistent(obj) || onFocus)
			{
				if (prefabLink != PrefabUtility.GetPrefabParent(obj) || onFocus)
				{
					prefabLink = PrefabUtility.GetPrefabParent(obj);
					return _CheckID(obj, ref id, prefabUniqueId, alwaysUnique);
				}
			}
			return false;
		}

		// return true if changed the id. Returns true if had to create new id and SetDirty should be called
		// alwaysUnique: Must always be unique among prefabs and scene objects, even if scene object comes from prefab
		private static bool _CheckID(Object obj, ref UniqueID id, UniqueID prefabUniqueId, bool alwaysUnique)
		{
			bool ret = false;

			// first check if object not already in list
			if (ids.ContainsKey(obj))
			{
				if (id != ids[obj])
				{	// for some reason the id was not same as one saved, reset
					id = ids[obj];
					ret = true;
					//ids[obj] = id;
				}

				if (alwaysUnique)
				{
					if (prefabUniqueId != null)
					{	// make sure it is not the same as that of the prefab
						if (id.Value == prefabUniqueId.Value)
						{
							id = UniqueID.Create();
							ids[obj] = id;
							ret = true;
						}
					}
				}
			}

			// else, if object not in list yet, check if its id is unique and add to list
			else
			{
				// if empty, generate new id now
				if (id.IsEmpty)
				{
					id = UniqueID.Create();
					ids.Add(obj, id);
					return true;
				}

				// else, check if id unique and add object to list
				else
				{
					if (alwaysUnique)
					{
						if (prefabUniqueId != null)
						{	// make sure it is not the same as that of the prefab
							if (id == prefabUniqueId)
							{
								id = UniqueID.Create();
								ids.Add(obj, id);
								return true;
							}
						}

						Object found = null;
						foreach (KeyValuePair<Object, UniqueID> kv in ids)
						{
							if (kv.Value == id)
							{
								found = kv.Key;
								break;
							}
						}

						if (found != null)
						{
							id = UniqueID.Create();
							ret = true;
						}

						ids.Add(obj, id);
					}
					else
					{
						bool isInList = false;
						Object objFab = EditorUtility.IsPersistent(obj) ? obj : PrefabUtility.GetPrefabParent(obj);
						objFab = objFab != null ? objFab : obj; // make sure the fab is not null for some reason

						// if obj has prefab then check if the prefab was saved before
						if (obj != objFab)
						{
							if (ids.ContainsKey(objFab))
							{
								isInList = true;
								if (id != ids[objFab])
								{	// for some reason the id was not same as one saved
									id = ids[objFab];
									ret = true;
									//ids[objFab] = id;
								}
							}
						}

						// if was not in list
						if (isInList == false)
						{
							// check if the same id was previously saved
							Object found = null;
							foreach (KeyValuePair<Object, UniqueID> kv in ids)
							{
								if (kv.Value == id)
								{
									found = kv.Key;
									break;
								}
							}

							// check if should generate new id if an object was found with the same id
							if (found != null)
							{
								// check if prefabs as it should always be unique among prefabs but I do 
								// not want to change it if a scene object that is linked with a prefab

								Object foundFab = EditorUtility.IsPersistent(found) ? found : PrefabUtility.GetPrefabParent(found);

								// only make changes if they are not the same prefab
								if (foundFab != objFab)
								{
									id = UniqueID.Create();
									ret = true;
								}
							}

							// save the object (or its prefab if it has one)
							ids.Add(objFab, id);
						}

					}
				}
			}
			return ret;
		}


		// ============================================================================================================
	}
}
