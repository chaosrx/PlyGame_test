﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

namespace plyGameEditor
{
	/// <summary> Attribute for child editor's of the plyGame Main Editor Window. </summary>
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
	public class ChildEditorAttribute : System.Attribute
	{
		public string Name;			//!< Name of editor, shown on the Tab
		public int Order = 0;		//!< Position editor appears on window [optional]
		public string Icon = null;	//!< Name of icon to use. Icon must be in '\Assets\plyoung\edRes\plyGame\mained\'. Do not include the last part of the icon name where the last part is ".png" (for dark theme) and "_l.png" (for light theme)

		public ChildEditorAttribute(string name)
		{
			this.Name = name;
		}

		// ============================================================================================================
	}
}