﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	public class ScreensEditor : EditorWindow
	{
		public const int SidebarWidth = 250;

		private static readonly string[] EditorLabels = { "Splash Screens", "Language Screen", "Loading Screens", "Custom Screens" };
		private static readonly ChildEditorBase[] ScreenEds = { new SplashScreens_Ed(), new LanguageScreen_Ed(), new LoadingScreens_Ed(), new CustomScreens_Ed() };

		private int currEd = 0;
		private int prevEd = 0;

		//private static Texture2D logo;

		// ============================================================================================================

		public static void Show_OnGUIScreensEditor()
		{
			if (EdGlobal.CheckDataExist())
			{
				EditorWindow.GetWindow<ScreensEditor>("ScreenEd");
			}
		}

		protected void OnFocus()
		{
			ScreenEds[currEd].ed = this;
			ScreenEds[currEd].OnFocus();
		}

		protected void OnGUI()
		{
			plyEdGUI.UseSkin();
			//GUI.DrawTexture(new Rect(position.width - 240, position.height - 80, 230, 75), logo);

			currEd = GUILayout.Toolbar(currEd, EditorLabels, plyEdGUI.MainToolbarStyle);
			plyEdGUI.DrawHorizontalLine(2, 0, plyEdGUI.MainToolbarDividerColor, plyEdGUI.FlatWhiteStyle, 0, 2);
			
			if (prevEd != currEd)
			{
				ScreenEds[currEd].ed = this;
				ScreenEds[currEd].OnFocus();
				GUI.FocusControl("");
				prevEd = currEd;
			}

			ScreenEds[currEd].ed = this;
			ScreenEds[currEd].OnGUI();
		}

		// ============================================================================================================
	}
}
