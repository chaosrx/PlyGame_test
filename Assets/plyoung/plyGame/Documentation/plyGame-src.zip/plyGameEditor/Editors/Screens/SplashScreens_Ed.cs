﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	public class SplashScreens_Ed : ChildEditorBase
	{
		// ============================================================================================================
		#region vars

		private OnGUIElementsEditor blocksEd = new OnGUIElementsEditor();
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		
		private SplashScreenAsset splashAsset;
		private SplashScreenData activeScreen;

#if MOVIE_SUPPORT
		private OnGUIElement movieBlock = null;
#endif

		#endregion
		// ============================================================================================================
		#region sys

		public override void OnFocus()
		{
			if (splashAsset == null)
			{
				splashAsset = (SplashScreenAsset)EdGlobal.LoadOrCreateAsset<SplashScreenAsset>(plyEdUtil.DATA_PATH_SYSTEM + "splash.asset", "Splash Screens Data");
				activeScreen = null;
			}
			if (activeScreen != null) blocksEd.SetElementList(activeScreen.screen);
		}

		public override void OnGUI()
		{
			if (splashAsset == null) return;
			EditorGUILayout.BeginHorizontal();
			// --------------------------------------------------------------------------------------------------------

			EditorGUILayout.BeginVertical();
			{

				if (plyEdGUI.ItemsList<SplashScreenData>(ref activeScreen, splashAsset.screens, false, false, true, false, OnListCallback, ref scroll[0], EdGlobal.HLP_SplashScreenEd, "Add a Screen", GUILayout.Width(ScreensEditor.SidebarWidth + 20), GUILayout.Height(ed.position.height / 4)))
				{
					blocksEd.SetElementList(activeScreen.screen);
#if MOVIE_SUPPORT
					movieBlock = null;
					if (activeScreen.autoAfterMovie >= 0)
					{
						movieBlock = activeScreen.screen.GetElement(activeScreen.autoAfterMovie);
					}
#endif
					ed.Repaint();
				}

				plyEdGUI.DrawHorizontalLine(2, ScreensEditor.SidebarWidth + 20, Color.white, plyEdGUI.SplitterStyle, 0, 0);

				// Show the Options (property blocks)
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1], false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView, GUILayout.Width(ScreensEditor.SidebarWidth + 20));
				GUILayout.Space(10);
				EditorGUILayout.BeginVertical(GUILayout.Width(ScreensEditor.SidebarWidth));
				{
					if (activeScreen != null)
					{
						plyEdGUI.SectionHeading("Settings");
						plyEdGUI.LookLikeControls(120, 105);
						activeScreen.autoChangeTime = EditorGUILayout.FloatField("Timeout (seconds)", activeScreen.autoChangeTime);

#if MOVIE_SUPPORT
						if (plyEdGUI.LabelButton("or after Movie", movieBlock == null ? "-none-" : movieBlock.name, 115, 0))
						{
							if (activeScreen.screen.movieEles.Count > 0)
							{
								plyListSelectWiz.ShowWiz("Select Movie", activeScreen.screen.movieEles.ConvertAll<object>((x) => { return (object)x; }), true, movieBlock, OnMovieSelected, null);
							}
						}
#endif
						activeScreen.allowSkipping = EditorGUILayout.Toggle("Allow skipping", activeScreen.allowSkipping);

						// Draw Blocks Editor Properties
						blocksEd.DrawProperties(ed, activeScreen.screen, splashAsset);
					}
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			EditorGUILayout.EndVertical();
			plyEdGUI.DrawVerticalLine(1, 0, Color.white, plyEdGUI.SplitterStyle, 0, 0);

			// Draw Blocks Editor main
			if (activeScreen != null)
			{
				blocksEd.DrawMain(ed, activeScreen.screen, splashAsset, null);
			}
			else GUILayout.FlexibleSpace();

			// --------------------------------------------------------------------------------------------------------
			EditorGUILayout.EndHorizontal();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(splashAsset);
			}

			HandleEvents();
		}

		private void HandleEvents()
		{
			// watch for an undo and repaint window just incase something in it was undone
			if (Event.current.type == EventType.ValidateCommand)
			{
				if (Event.current.commandName == "UndoRedoPerformed")
				{
					blocksEd.SetElementList(activeScreen.screen);
					ed.Repaint();
				}
			}
		}

#if MOVIE_SUPPORT
		private void OnMovieSelected(object sender, object[] args)
		{
			plyListSelectWiz wiz = sender as plyListSelectWiz;
			if (activeScreen != null)
			{
				movieBlock = wiz.selected as OnGUIMovie;
				if (movieBlock == null) activeScreen.autoAfterMovie = -1;
				else activeScreen.autoAfterMovie = movieBlock.id;
				EditorUtility.SetDirty(splashAsset);
			}
			wiz.Close();
			ed.Repaint();
		}
#endif
		private SplashScreenData OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:must create and add new, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed,

			if (act == 1)
			{
				activeScreen = new SplashScreenData();
				activeScreen.screen = new GUIScreen();
				activeScreen.screen.name = "Splash Screen " + (splashAsset.screens.Count + 1);
				splashAsset.screens.Add(activeScreen);
				EditorUtility.SetDirty(splashAsset);
				return activeScreen;
			}
			//else if (act == 2)
			//{
			//}
			else if (act == 3)
			{
				activeScreen = null;
			}
			//else if (act == 5)
			//{
			//}
			else if (act == 4 || act == 5)
			{
				for (int i = 0; i < splashAsset.screens.Count; i++) splashAsset.screens[i].screen.name = "Splash Screen " + (i+1);
			}

			EditorUtility.SetDirty(splashAsset);
			return null;
		}

		#endregion
		// ============================================================================================================
	}
}