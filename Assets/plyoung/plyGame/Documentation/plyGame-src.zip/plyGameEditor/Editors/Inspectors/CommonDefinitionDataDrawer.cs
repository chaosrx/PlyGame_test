﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	public class CommonDefinitionDataDrawer
	{
		private static int imgEd = 0;
		public static void Draw(CommonDefinitionData Target, ref int activeImg)
		{
			Target.ident = EditorGUILayout.TextField("Ident", Target.ident);
			Target.screenName = EditorGUILayout.TextField("Screen Name", Target.screenName);
			Target.shortName = EditorGUILayout.TextField("Short Name", Target.shortName);
			Target.meta = EditorGUILayout.TextField("Meta Data", Target.meta);

			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.BeginVertical(GUILayout.Width(EditorGUIUtility.labelWidth - 8));
				{
					//GUILayout.Label("Images");
					EditorGUILayout.BeginHorizontal();
					{
						if (GUILayout.Toggle(imgEd == 0, "Images", EditorStyles.miniButtonLeft)) imgEd = 0;
						if (GUILayout.Toggle(imgEd == 1, "Sprites", EditorStyles.miniButtonRight)) imgEd = 1;
						GUILayout.FlexibleSpace();
					}
					EditorGUILayout.EndHorizontal();
					if (imgEd == 0)
					{
						EditorGUILayout.BeginHorizontal();
						{
							Target.images[activeImg] = (Texture2D)EditorGUILayout.ObjectField(Target.images[activeImg], typeof(Texture2D), false, GUILayout.Width(70), GUILayout.Height(70));
							EditorGUILayout.BeginVertical();
							{
								if (plyEdGUI.ToggleButton(activeImg == 0, "1", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 0;
								if (plyEdGUI.ToggleButton(activeImg == 1, "2", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 1;
								if (plyEdGUI.ToggleButton(activeImg == 2, "3", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 2;
							}
							EditorGUILayout.EndVertical();
						}
						EditorGUILayout.EndHorizontal();
					}
					else
					{
						EditorGUILayout.BeginHorizontal();
						{
							Target.sprites[activeImg] = (Sprite)EditorGUILayout.ObjectField(Target.sprites[activeImg], typeof(Sprite), false, GUILayout.Width(70));
							EditorGUILayout.BeginVertical();
							{
								if (plyEdGUI.ToggleButton(activeImg == 0, "1", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 0;
								if (plyEdGUI.ToggleButton(activeImg == 1, "2", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 1;
								if (plyEdGUI.ToggleButton(activeImg == 2, "3", EditorStyles.miniButtonRight, GUILayout.Width(20))) activeImg = 2;
							}
							EditorGUILayout.EndVertical();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.BeginVertical();
				{
					GUILayout.Label("Description");
					Target.description = EditorGUILayout.TextArea(Target.description, plyEdGUI.TextAreaStyle);
					EditorGUILayout.Space();
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		// ============================================================================================================
	}
}
