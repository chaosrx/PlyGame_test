﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(ItemFieldData))]
	public class ItemFieldData_Handler : plyBlockFieldHandler
	{

		private ItemsAsset itemsAsset;

		public override object GetCopy(object obj)
		{
			ItemFieldData target = obj as ItemFieldData;
			if (target != null) return target.Copy();
			return new ItemFieldData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			ItemFieldData target = obj == null ? new ItemFieldData() : obj as ItemFieldData;
			if (itemsAsset == null)
			{
				itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Item Definitions");
			}

			itemsAsset.UpdateItemCache();

			// check if saved still valid
			if (!string.IsNullOrEmpty(target.id))
			{
				bool found = false;
				UniqueID id = new UniqueID(target.id);
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (id == itemsAsset.items[i].prefabId) { found = true; break; }
				}
				if (!found)
				{
					target.id = "";
					target.cachedName = "";
					ed.ForceSerialise();
				}
			}
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			ItemFieldData target = obj == null ? new ItemFieldData() : obj as ItemFieldData;

			if (GUILayout.Button(string.IsNullOrEmpty(target.cachedName) ? "-select-" : target.cachedName))
			{
				List<object> l = new List<object>();
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					l.Add(new UniqueIdNamePair()
					{
						id = itemsAsset.items[i].prefabId.Copy(),
						name = string.IsNullOrEmpty(itemsAsset.items[i].def.screenName) ? itemsAsset.items[i].name : itemsAsset.items[i].def.screenName
					});
				}
				l.Sort((a, b) => a.ToString().CompareTo(b.ToString()));
				plyListSelectWiz.ShowWiz("Select Item", l, true, null, OnSkillSelect, new object[] { ed, target });
			}

			obj = target;
			return ret;
		}

		private void OnSkillSelect(object sender, object[] args)
		{
			ItemFieldData target = args[1] as ItemFieldData;
			plyBloxEd plyed = args[0] as plyBloxEd;

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();

			if (plyed == null || target == null) return;

			GUI.changed = true;
			if (uimp != null)
			{
				target.id = uimp.id.ToString();
				target.cachedName = uimp.name;
			}
			else
			{
				target.id = "";
				target.cachedName = "";
			}
			plyed.ForceSerialise();
			plyed.Repaint();
		}

		// ============================================================================================================
	}
}