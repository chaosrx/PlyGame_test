﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	public class PlayerTopDownNAV_InputDefiner : InputDefiner
	{
		public override List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>()
			{
				new InputDefinition() {
					category = "Player Top-Down NAV", name = "ClickMove",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Mouse0 } }
				},
			};
		}

		// ============================================================================================================
	}
}
