﻿//// -= plyGame =-
//// www.plyoung.com
//// Copyright (c) Leslie Young
//// ====================================================================================================================

//using UnityEngine;
//using UnityEditor;
//using System.Collections;
//using System.Collections.Generic;
//using plyGame;
//using plyCommonEditor;
//using plyCommon;

//namespace plyGameEditor
//{
//	public class ItemsListWindow : EditorWindow
//	{

//		private DataAsset dataAsset;
//		private ItemsAsset itemsAsset;

//		private static Texture2D notx;
//		private static GUIStyle ButtonStyle;
//		private static Vector2 scroll = Vector2.zero;

//		// ============================================================================================================

//		public static void Show_ItemsListWindow()
//		{
//			if (EdGlobal.CheckDataExist())
//			{
//				EditorWindow.GetWindow<ItemsListWindow>("Items");
//			}
//		}

//		protected void OnFocus()
//		{
//			if (itemsAsset == null)
//			{
//				dataAsset = EdGlobal.GetDataAsset();
//				itemsAsset = (ItemsAsset)dataAsset.GetAsset<ItemsAsset>();
//				if (itemsAsset == null)
//				{
//					itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Item Definitions");
//					if (itemsAsset.items.Count > 0)
//					{	// make sure the asset is in the data asset if there is data defined
//						if (dataAsset.AddAsset(itemsAsset)) EditorUtility.SetDirty(dataAsset);
//					}
//				}
//			}

//			if (notx == null) notx = plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.item_notx.png", typeof(EdGlobal).Assembly);

//			for (int i = 0; i < itemsAsset.items.Count; i++)
//			{
//				itemsAsset.items[i].__gc = new GUIContent(" " + itemsAsset.items[i].def.screenName, notx);
//			}
//		}

//		private void InitGUI()
//		{
//			if (ButtonStyle == null)
//			{
//				ButtonStyle = new GUIStyle(GUI.skin.button)
//				{
//					imagePosition = ImagePosition.ImageLeft,
//					alignment = TextAnchor.MiddleLeft,
//					fixedHeight = 20,
//				};
//			}
//		}

//		protected void OnGUI()
//		{
//			InitGUI();

//			scroll = EditorGUILayout.BeginScrollView(scroll);
//			for (int i = 0; i < itemsAsset.items.Count; i++)
//			{
//				if (itemsAsset.items[i].__gc.image == notx)
//				{
//					if (itemsAsset.items[i].def.images[0] != null) itemsAsset.items[i].__gc.image = itemsAsset.items[i].def.images[0];
//					else if (itemsAsset.items[i].def.images[1] != null) itemsAsset.items[i].__gc.image = itemsAsset.items[i].def.images[1];
//					else if (itemsAsset.items[i].def.images[2] != null) itemsAsset.items[i].__gc.image = itemsAsset.items[i].def.images[2];
//					else if (itemsAsset.items[i].floorArtPrefab != null)
//					{
//						Texture2D t = AssetPreview.GetAssetPreview(itemsAsset.items[i].floorArtPrefab);
//						if (t != null) itemsAsset.items[i].__gc.image = t;
//					}
//					else if (itemsAsset.items[i].heldArtPrefab != null)
//					{
//						Texture2D t = AssetPreview.GetAssetPreview(itemsAsset.items[i].heldArtPrefab);
//						if (t != null) itemsAsset.items[i].__gc.image = t;
//					}
//				}

//				if (GUILayout.Button(itemsAsset.items[i].__gc, ButtonStyle))
//				{
//					//CreateItemInScene(itemsAsset.items[i]);
//					Vector3 pos = plyEdUtil.GetCreatePositionInSceneView(new Vector3(0f, 0.1f, 0f), true, -1);
//					ItemInScene its = ItemInScene.Create(itemsAsset.items[i], pos, Quaternion.identity, null);
//					Selection.activeGameObject = its.gameObject;
//				}
//			}
//			EditorGUILayout.Space();
//			EditorGUILayout.EndScrollView();
//		}

//		//private void CreateItemInScene(Item it)
//		//{
//		//	// 1st create the parent if it does not exist
//		//	GameObject parent = GameObject.Find("Items");
//		//	if (!parent) parent = new GameObject("Items");

//		//	// create item
//		//	GameObject obj = plyEdUtil.CreateGameObjectInSceneView(it.def.screenName, new Vector3(0f, 0.1f, 0f), true, -1, it.floorArtPrefab);
//		//	if (!obj) return;

//		//	obj.transform.parent = parent.transform;
//		//	ItemInScene its = obj.AddComponent<ItemInScene>();
//		//	its.itemID = it.id.Copy();
//		//	its.id = UniqueID.Create();

//		//	// select the new object
//		//	Selection.activeGameObject = obj;
//		//}

//		// ============================================================================================================
//	}
//}