﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyBloxKit;
using plyCommonEditor;
using plyBloxKitEditor;

namespace plyGameEditor
{
	public class ObjectDestroyerHandler_Drawer
	{

		public static void Draw(ObjectDestroyerHandler data)
		{
			data.method = (ObjectDestroyerHandler.DestroyMethod)EditorGUILayout.EnumPopup("Method", data.method);

			if (data.method == ObjectDestroyerHandler.DestroyMethod.Destroy)
			{
				data.opt_c = EditorGUILayout.FloatField("after (seconds)", data.opt_c);
			}

			else if (data.method == ObjectDestroyerHandler.DestroyMethod.SinkAndDestroy)
			{
				data.opt_a = EditorGUILayout.FloatField("Sink distance", data.opt_a);
				data.opt_b = EditorGUILayout.FloatField("Sink speed", data.opt_b);
				data.opt_c = EditorGUILayout.FloatField("after (seconds)", data.opt_c);
			}
		}

		// ============================================================================================================
	}
}