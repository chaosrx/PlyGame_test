﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	[ChildEditor("Attributes", Order = -99980, Icon="attrib")]
	public class Attributes_Ed : ChildEditorBase
	{
		private DataAsset dataAsset;
		private ActorAttributesAsset attribAsset;
		private ActorAttribute currAttrib = null;
		private int currIdx = -1;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		private int activeImg = 0;
		//private int imgEd = 0;

		private string[] attribNames = new string[0];
		private int hpIdx = -1;
		private int xpIdx = -1;

		// ============================================================================================================

		public override void OnFocus()
		{
			if (attribAsset == null)
			{
				currAttrib = null; currIdx = -1;

				dataAsset = EdGlobal.GetDataAsset();
				attribAsset = (ActorAttributesAsset)dataAsset.GetAsset<ActorAttributesAsset>();
				if (attribAsset == null)
				{
					attribAsset = (ActorAttributesAsset)EdGlobal.LoadOrCreateAsset<ActorAttributesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "attributes.asset", "Attribute Definitions");
					if (attribAsset.attributes.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(attribAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			UpdateAttribNameList();
		}

		private void UpdateAttribNameList()
		{
			if (attribAsset != null)
			{
				attribNames = new string[attribAsset.attributes.Count];
				for (int i = 0; i < attribNames.Length; i++)
				{
					attribNames[i] = attribAsset.attributes[i].def.screenName;
				}

				hpIdx = attribAsset.GetDefinitionIdx(attribAsset.hpAttribId);
				xpIdx = attribAsset.GetDefinitionIdx(attribAsset.xpAttribId);
			}
		}

		public override void OnGUI()
		{
			if (attribAsset == null) return;

			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.BeginVertical(GUILayout.Width(230));
				{
					EditorGUILayout.Space();
					plyEdGUI.SectionHeading("Attribute Links");
					plyEdGUI.LookLikeControls(80);

					EditorGUI.BeginChangeCheck();
					hpIdx = plyEdGUI.Popup("Health", hpIdx, attribNames);
					if (EditorGUI.EndChangeCheck())
					{
						if (hpIdx == -1) attribAsset.hpAttribId = UniqueID.Empty;
						else attribAsset.hpAttribId = attribAsset.attributes[hpIdx].id.Copy();
						GUI.changed = true;
					}

					EditorGUI.BeginChangeCheck();
					xpIdx = plyEdGUI.Popup("Experience", xpIdx, attribNames);
					if (EditorGUI.EndChangeCheck())
					{
						if (xpIdx == -1) attribAsset.xpAttribId = UniqueID.Empty;
						else attribAsset.xpAttribId = attribAsset.attributes[xpIdx].id.Copy();
						GUI.changed = true;
					}

					plyEdGUI.LookLikeControls();
					EditorGUILayout.Space();
					plyEdGUI.SectionHeading("Attribute Definitions", false);
					if (plyEdGUI.ItemsList<ActorAttribute>(ref currAttrib, attribAsset.attributes, true, false, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_AttributesEd, "No Attributes Defined", GUILayout.Width(230)))
					{
						currIdx = currAttrib == null ? -1 : attribAsset.GetDefinitionIdx(currAttrib.id);
						plyEdGUI.ClearFocus();
					}
				}
				EditorGUILayout.EndVertical();
				plyEdGUI.DrawVerticalLine(1, 0, Color.white, plyEdGUI.SplitterStyle, 0, 0);

				if (currAttrib != null)
				{
					ShowSelectedInfo();
				}
				else GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			// --------------------------------------------------------------------------------------------------------
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(attribAsset);
			}
		}

		private ActorAttribute OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				currAttrib = new ActorAttribute();
				currAttrib.id = UniqueID.Create();
				currAttrib.def.screenName = "Attribute " + attribAsset.attributes.Count;
				attribAsset.attributes.Add(currAttrib);
				EditorUtility.SetDirty(attribAsset);
				UpdateAttribNameList();
				currIdx = currAttrib == null ? -1 : attribAsset.GetDefinitionIdx(currAttrib.id);
				if (dataAsset.AddAsset(attribAsset)) EditorUtility.SetDirty(dataAsset);
				return currAttrib;
			}
			else if (act == 2)
			{
				ActorAttribute a = args[1] as ActorAttribute;
				currAttrib = (ActorAttribute)a.Copy();
				currAttrib.id = UniqueID.Create(); // need to create a new unique id for the copy
				currAttrib.def.screenName = currAttrib.def.screenName + " (copy)";
				attribAsset.attributes.Add(currAttrib);
				EditorUtility.SetDirty(attribAsset);
				UpdateAttribNameList();
				if (dataAsset.AddAsset(attribAsset)) EditorUtility.SetDirty(dataAsset);
				return currAttrib;
			}
			//else if (act == 3)
			//{
			//}
			else if (act == 4)
			{
				currAttrib = attribAsset.attributes.Count > 0 ? attribAsset.attributes[0] : null;
				UpdateAttribNameList();
				currIdx = currAttrib == null ? -1 : attribAsset.GetDefinitionIdx(currAttrib.id);
				EditorUtility.SetDirty(attribAsset);

				if (attribAsset.attributes.Count == 0)
				{	// remove from dataAsset if no data defined
					if (dataAsset.RemoveAsset(attribAsset)) EditorUtility.SetDirty(dataAsset);
				} 
				
				return currAttrib;
			}
			//else if (act == 5)
			//{
			//}
			//else if (act == 6)
			//{
			//}

			EditorUtility.SetDirty(attribAsset);
			return null;
		}

		private void ShowSelectedInfo()
		{
			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
			EditorGUILayout.BeginVertical();
			{
				BasicInfo();
				plyEdGUI.HLine(20);
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
		}

		private void BasicInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Attribute Definition");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				EditorGUI.BeginChangeCheck();
				CommonDefinitionDataDrawer.Draw(currAttrib.def, ref activeImg);
				if (EditorGUI.EndChangeCheck())
				{
					if (currIdx == -1) currIdx = attribAsset.GetDefinitionIdx(currAttrib.id);
					attribNames[currIdx] = currAttrib.def.screenName;
				}
			}
			EditorGUILayout.EndVertical();
		}

		// ============================================================================================================
	}
}