﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	[EdMenuOption("Player Selectors", typeof(Markers_Ed))]
	public class Markers_PlayerSelection_Ed : ChildEditorBase
	{

		private DataAsset dataAsset;
		private MarkersAsset markersAsset;
		private PlayerSelectorsAsset asset;

		private string[] markerNames = new string[0];
		private int[] sel = new int[] { -1, -1, -1, -1, -1 };

		private GUIContent GC_Clear = new GUIContent("x", "Clear");

		// ============================================================================================================

		public override void OnFocus()
		{
			if (asset == null)
			{
				dataAsset = EdGlobal.GetDataAsset();
				asset = (PlayerSelectorsAsset)dataAsset.GetAsset<PlayerSelectorsAsset>();
				if (asset == null)
				{
					asset = (PlayerSelectorsAsset)EdGlobal.LoadOrCreateAsset<PlayerSelectorsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "playerselectors.asset", "Player Selector Definitions");
					if (dataAsset.AddAsset(asset)) EditorUtility.SetDirty(dataAsset);
				}
			}

			if (markersAsset == null)
			{
				dataAsset = EdGlobal.GetDataAsset();
				markersAsset = (MarkersAsset)dataAsset.GetAsset<MarkersAsset>();
				if (markersAsset == null)
				{
					markersAsset = (MarkersAsset)EdGlobal.LoadOrCreateAsset<MarkersAsset>(plyEdUtil.DATA_PATH_SYSTEM + "markers.asset", "Marker Definitions");
					if (markersAsset.markerFabs.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(markersAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			if (markersAsset.UpdateCache())
			{
				EditorUtility.SetDirty(markersAsset);
			}

			markerNames = markersAsset.GetNames();
			sel[0] = markersAsset.GetDefinitionIdx(asset.friendlyNPC);
			sel[1] = markersAsset.GetDefinitionIdx(asset.neutralNPC);
			sel[2] = markersAsset.GetDefinitionIdx(asset.hostileNPC);
			sel[3] = markersAsset.GetDefinitionIdx(asset.interactObject);
			sel[4] = markersAsset.GetDefinitionIdx(asset.item);
		}

		public override void OnGUI()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Player Selector Settings");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				asset.friendlyNPC = ShowEntry(0, "Friendly NPC", asset.friendlyNPC);
				asset.neutralNPC = ShowEntry(1, "Neutral NPC", asset.neutralNPC);
				asset.hostileNPC = ShowEntry(2, "Hostile NPC", asset.hostileNPC);
				asset.interactObject = ShowEntry(3, "Interact Object", asset.interactObject);
				asset.item = ShowEntry(4, "Item", asset.item);
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed) EditorUtility.SetDirty(asset);
		}

		private UniqueID ShowEntry(int s, string label, UniqueID id)
		{
			EditorGUILayout.BeginHorizontal();

			GUILayout.Label(label, GUILayout.Width(EditorGUIUtility.labelWidth));

			EditorGUI.BeginChangeCheck();
			sel[s] = EditorGUILayout.Popup(sel[s], markerNames);
			if (EditorGUI.EndChangeCheck())
			{
				id = markersAsset.GetDefinitionUniqueId(sel[s]);
				GUI.changed = true;
			}

			if (GUILayout.Button(GC_Clear, EditorStyles.miniButton, GUILayout.Width(25)))
			{
				sel[s] = -1;
				id = UniqueID.Empty;
				GUI.changed = true;
			}

			EditorGUILayout.EndHorizontal();
			return id;
		}

		// ============================================================================================================
	}
}