﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKit;
using plyBloxKitEditor;
using plyGame;

namespace plyGameEditor
{
	[ChildEditor("Factions", Order = -99974, Icon = "fact")]
	public class Factions_Ed : ChildEditorBase
	{
		private ActorFactionManager factionsMan;
		private ActorFaction currFaction = null;
		private int currIdx = -1;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		private int activeImg = 0;
		//private int imgEd = 0;
		private Rect toprect;

		private string newVarName = "";
		private VariableType newVarType = VariableType.Int;

		private static GUIContent bFriendly;
		private static GUIContent bNeutral;
		private static GUIContent bHostile;
		private static GUIStyle buttonStyle;

		private static GUIContent GC_plyBlox;
		private static GUIContent GC_plyBloxVars;

		// ============================================================================================================

		public override void OnFocus()
		{
			GameObject fab = plyEdUtil.LoadOrCreatePrefab<ActorFactionManager>("Factions Manager", plyEdUtil.DATA_PATH_SYSTEM + "factionsman.prefab");
			factionsMan = fab.GetComponent<ActorFactionManager>();
			if (factionsMan.blox == null)
			{
				factionsMan.blox = fab.AddComponent<plyBlox>();
				EditorUtility.SetDirty(factionsMan);
				EditorUtility.SetDirty(fab);
			}

			// make sure factions manager will be auto loaded when game starts since it is used (there are factions defined)
			if (factionsMan.definedFactions.Count > 0) EdGlobal.RegisterAutoCreate(fab);

			CheckRelationList();
			CheckVarLists();
		}

		private void CheckGUIContent()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_plyBlox = new GUIContent(FA.cube.ToString() + " Edit Events", "Open plyBlox Editor");
				GC_plyBloxVars = new GUIContent(FA.code.ToString() + " Edit Variables", "Edit Local plyBlox variables of object");

				bFriendly = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_green.png", typeof(EdGlobal).Assembly), "Friendly");
				bNeutral = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_blue.png", typeof(EdGlobal).Assembly), "Neutral");
				bHostile = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_red.png", typeof(EdGlobal).Assembly), "Hostile");
				buttonStyle = new GUIStyle();
			}
		}

		public override void OnGUI()
		{
			if (factionsMan == null) return;
			CheckGUIContent();

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.ItemsList<ActorFaction>(ref currFaction, factionsMan.definedFactions, true, false, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_FactionsEd, "No Factions Defined", true, new GUIContent[] { plyEdGUI.GC_Settings }, new BasicCallback[] { GearIconPressed }, GUILayout.Width(230)))
				{
					currIdx = currFaction == null ? -1 : factionsMan.GetDefinitionIdx(currFaction);
					plyEdGUI.ClearFocus();
				}

				toprect = EditorGUILayout.BeginVertical();
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
				if (currFaction != null) ShowSelectedInfo();
				else 
				{
					FactionManOpts();
					FactionVarDefs();
					FactionRelations();
				}

				plyEdGUI.HLine(20);
				EditorGUILayout.EndScrollView();
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			// --------------------------------------------------------------------------------------------------------
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(factionsMan);
			}
		}

		private ActorFaction OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				currFaction = new ActorFaction();
				currFaction.id = UniqueID.Create();
				currFaction.def.screenName = "Faction " + factionsMan.definedFactions.Count;
				factionsMan.definedFactions.Add(currFaction);
				AddedFaction();
				EditorUtility.SetDirty(factionsMan);
				currIdx = currFaction == null ? -1 : factionsMan.GetDefinitionIdx(currFaction);
				return currFaction;
			}
			else if (act == 2)
			{
				ActorFaction a = args[1] as ActorFaction;
				currFaction = (ActorFaction)a.Copy();
				currFaction.id = UniqueID.Create(); // need to create a new unique id for the copy
				currFaction.def.screenName = currFaction.def.screenName + " (copy)";
				factionsMan.definedFactions.Add(currFaction);
				AddedFaction();
				EditorUtility.SetDirty(factionsMan);
				return currFaction;
			}
			else if (act == 3)
			{
				DeletingFaction(factionsMan.GetDefinitionIdx(currFaction));
			}
			else if (act == 4)
			{
				currFaction = factionsMan.definedFactions.Count > 0 ? factionsMan.definedFactions[0] : null;
				currIdx = currFaction == null ? -1 : factionsMan.GetDefinitionIdx(currFaction);
				EditorUtility.SetDirty(factionsMan);

				if (factionsMan.definedFactions.Count == 0)
				{	// remove it since there are no factions to manage and thus assumed will not use faction system
					EdGlobal.RemoveAutoCreate(factionsMan.gameObject);
				}

				return currFaction;
			}

			EditorUtility.SetDirty(factionsMan);
			return null;
		}

		private void GearIconPressed()
		{
			currFaction = null;
			CheckRelationList();
		}

		private void AddedFaction()
		{
			// make sure factions manager will be auto loaded when game starts since it is used (there are factions defined)
			EdGlobal.RegisterAutoCreate(factionsMan.gameObject);

			// make sure the var and relation lists for new and old factions are big enough
			CheckVarLists();
			CheckRelationList();
		}

		private void DeletingFaction(int idx)
		{
			if (idx < 0)
			{
				Debug.LogError("[DeletingFaction] The idx was: " + idx);
				return;
			}

			for (int i = 0; i < factionsMan.definedFactions.Count; i++)
			{
				ActorFaction f = factionsMan.definedFactions[i];

				// remove relation entry
				f.statusTo.RemoveAt(idx);

				// remove from variable lists
				for (int j = 0; j < f.varListDef.Count; j++)
				{
					f.varListDef[j].vars.RemoveAt(idx);
				}
			}
		}

		private void FactionManOpts()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Faction Manager");

			factionsMan.persistVars = EditorGUILayout.Toggle("Persists Faction variables", factionsMan.persistVars);

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			if (GUILayout.Button(GC_plyBlox, plyEdGUI.ButtonStyle, GUILayout.Width(120), GUILayout.Height(25)))
			{
				if (factionsMan.blox != null)
				{
					Selection.activeObject = factionsMan.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd(factionsMan.blox, "Factions Manager");
				}
				else Debug.LogError("[Factions Editor] The Faction Manager object is invalid. No plyBlox object was found on it.");
			}
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_plyBloxVars, plyEdGUI.ButtonStyle, GUILayout.Width(135), GUILayout.Height(25)))
			{
				if (factionsMan.blox != null)
				{
					Selection.activeObject = factionsMan.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
				}
				else Debug.LogError("[Factions Editor] The Faction Manager object is invalid. No plyBlox object was found on it.");
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		}

		// ============================================================================================================

		private void ShowSelectedInfo()
		{
			BasicInfo();
			VarGrid();
		}

		private void BasicInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Faction Definition");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				CommonDefinitionDataDrawer.Draw(currFaction.def, ref activeImg);
			}
			EditorGUILayout.EndVertical();
		}

		private void VarGrid()
		{
			bool style2 = true;
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Variables");

			if (factionsMan.varTypes.Count == 0)
			{
				GUILayout.Label("No variables defined.");
				return;
			}

			EditorGUILayout.BeginVertical(plyEdGUI.LRPaddingHelperStyle);
			{
				EditorGUILayout.BeginHorizontal(plyEdGUI.MenuListItemStyle2);
				{
					GUILayout.Label(" ", GUILayout.Width(120));
					for (int i = 0; i < factionsMan.varTypes.Count; i++)
					{
						GUILayout.Label(factionsMan.varTypes[i].name, plyEdGUI.LargeBoldLabelStyle, GUILayout.Width(120));
					}
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorGUIUtility.fieldWidth = 120;
				for (int i = 0; i < factionsMan.definedFactions.Count; i++)
				{
					style2 = !style2;
					EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.MenuListItemStyle2 : plyEdGUI.MenuListItemStyle1);
					{
						GUILayout.Label(factionsMan.definedFactions[i].def.screenName, GUILayout.Width(120));

						for (int j = 0; j < currFaction.varListDef.Count; j++)
						{
							plyBloxGUI.VariableField(currFaction.varListDef[j].vars[i], 120);
						}
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			EditorGUILayout.EndVertical();
		}

		// ============================================================================================================

		private void FactionVarDefs()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Faction Variables", false);
			EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
			{
				newVarName = EditorGUILayout.TextField(newVarName, plyEdGUI.ToolbarTextFieldStyle, GUILayout.Width(112));
				newVarType = (VariableType)EditorGUILayout.EnumPopup(newVarType, plyEdGUI.ToolbarPopupStyle, GUILayout.Width(120));
				if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
				{
					if (VarNameValid(newVarName))
					{
						factionsMan.varTypes.Add(new FactionVarList() { name = newVarName, varType = newVarType });
						CheckVarLists();
						EditorUtility.SetDirty(factionsMan);
						plyEdGUI.ClearFocus();
						newVarName = "";
					}
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			if (factionsMan.varTypes.Count == 0)
			{
				GUILayout.Label("None Faction variables defined.");
				return;
			}

			bool style2 = true;
			FactionVarList del = null;
			foreach (FactionVarList v in factionsMan.varTypes)
			{
				style2 = !style2;
				EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.MenuListItemStyle2 : plyEdGUI.MenuListItemStyle1);
				{
					GUILayout.Label(v.name + " (" + v.varType + ")", GUILayout.Width(200));

					if (GUILayout.Button(plyEdGUI.GC_Rename, plyEdGUI.FlatIconButtonStyle, GUILayout.Width(20)))
					{
						plyTextInputWiz.ShowWiz("Rename Variable", "Enter a unique name", v.name, OnRenameEvent, new object[] { v });
					}

					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonStyle, GUILayout.Width(20))) del = v;
				}
				EditorGUILayout.EndHorizontal();
			}

			if (del != null)
			{
				factionsMan.varTypes.Remove(del);

				// remove from faction var lists
				for (int i = 0; i < factionsMan.definedFactions.Count; i++)
				{
					ActorFaction f = factionsMan.definedFactions[i];
					for (int j = 0; j < f.varListDef.Count; j++)
					{
						if (f.varListDef[j].name == del.name)
						{
							f.varListDef.RemoveAt(j);
							break;
						}
					}
				}

				EditorUtility.SetDirty(factionsMan);
			}

		}

		private bool VarNameValid(string nm)
		{
			if (string.IsNullOrEmpty(nm)) return false;
			for (int i = 0; i < factionsMan.varTypes.Count; i++)
			{
				if (factionsMan.varTypes[i].name.Equals(nm)) return false;
			}
			return true;
		}

		private void OnRenameEvent(object sender, object[] args)
		{
			FactionVarList v = (FactionVarList)args[0];
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				if (!v.name.Equals(s))
				{
					if (false == VarNameValid(s))
					{
						EditorUtility.DisplayDialog("Error", "Each variable name should be unique.", "Ok");
					}
					else
					{
						// update the factions lists with new name too
						for (int i = 0; i < factionsMan.definedFactions.Count; i++)
						{
							ActorFaction f = factionsMan.definedFactions[i];
							for (int j = 0; j < f.varListDef.Count; j++)
							{
								if (f.varListDef[j].name.Equals(v.name))
								{
									f.varListDef[j].name = s;
									for (int a = 0; a < f.varListDef[j].vars.Count; a++)
									{
										f.varListDef[j].vars[a].name = s;
									}
									break;
								}
							}
						}

						v.name = s;
						EditorUtility.SetDirty(factionsMan);
					}
				}
			}
			ed.Repaint();
		}

		private void CheckVarLists()
		{
			bool changed = false;
			for (int i = 0; i < factionsMan.definedFactions.Count; i++)
			{
				for (int j = 0; j < factionsMan.varTypes.Count; j++)
				{
					if (CheckVar(factionsMan.definedFactions[i], factionsMan.varTypes[j]))
					{
						changed = true;
					}
				}
			}
			if (changed) EditorUtility.SetDirty(factionsMan);
		}

		private bool CheckVar(ActorFaction fac, FactionVarList varDef)
		{
			int idx = -1;
			int cnt = factionsMan.definedFactions.Count;
			for (int i = 0; i < fac.varListDef.Count; i++)
			{
				if (fac.varListDef[i].name.Equals(varDef.name))
				{
					// found, check if enough entries to cover all factions
					idx = i;
					cnt = factionsMan.definedFactions.Count - fac.varListDef[i].vars.Count;
					break;
				}
			}

			if (cnt > 0)
			{
				if (idx < 0)
				{
					fac.varListDef.Add(new FactionVarList() { name = varDef.name, varType = varDef.varType, vars = new List<plyVar>() });
					idx = fac.varListDef.Count - 1;
				}
				for (int i = 0; i < cnt; i++) fac.varListDef[idx].vars.Add(new plyVar() { name = varDef.name, type = varDef.varType });
				return true;
			}

			return false;
		}

		// ============================================================================================================

		private void FactionRelations()
		{
			EditorGUILayout.Space();
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Factions Relationship");

			if (factionsMan.definedFactions.Count == 0)
			{
				GUILayout.Label("No Factions defined.");
				return;
			}

			int cnt = factionsMan.definedFactions.Count;
			Rect rect = GUILayoutUtility.GetRect((20 * cnt) + 150, (20 * cnt) + 150f);
			Vector2 vector = new Vector2(rect.x, rect.y);
			Vector3 pos = Vector3.zero;

			for (int j = 0; j < cnt; j++)
			{
				string name = factionsMan.definedFactions[j].def.screenName;
				if (string.IsNullOrEmpty(name)) name = "Faction-" + j;

				pos = new Vector3(102 + vector.x + ((cnt - j) * 20), vector.y, 0f);
				GUIUtility.RotateAroundPivot(90, new Vector2(pos.x, pos.y));
				if (SystemInfo.graphicsDeviceVersion.StartsWith("Direct3D 9.0")) GUI.matrix *= Matrix4x4.TRS(new Vector3(-0.5f, -0.5f, 0f), Quaternion.identity, Vector3.one);

				GUI.Label(new Rect(pos.x, pos.y, 100f, 20f), name, "RightLabel");

				GUI.matrix = Matrix4x4.identity;
			}

			GUI.matrix = Matrix4x4.identity;
			rect.y = rect.y + 103f;

			for (int j = 0; j < cnt; j++)
			{
				string name = factionsMan.definedFactions[j].def.screenName;
				if (string.IsNullOrEmpty(name)) name = "Faction-" + j;

				GUI.Label(new Rect(rect.x, rect.y + (j * 20), 100f, 20f), name, "RightLabel");

				Rect r = new Rect(rect.x + 105, rect.y + (j * 20), 20, 20);

				for (int i = cnt - 1; i >= 0; i--)
				{
					if (factionsMan.definedFactions[j].statusTo[i] == StatusTowardsOther.Friendly)
					{
						if (GUI.Button(r, bFriendly, buttonStyle))
						{
							factionsMan.definedFactions[j].statusTo[i] = StatusTowardsOther.Neutral;
							EditorUtility.SetDirty(factionsMan);
						}
					}
					else if (factionsMan.definedFactions[j].statusTo[i] == StatusTowardsOther.Neutral)
					{
						if (GUI.Button(r, bNeutral, buttonStyle))
						{
							factionsMan.definedFactions[j].statusTo[i] = StatusTowardsOther.Hostile;
							EditorUtility.SetDirty(factionsMan);
						}
					}
					else if (factionsMan.definedFactions[j].statusTo[i] == StatusTowardsOther.Hostile)
					{
						if (GUI.Button(r, bHostile, buttonStyle))
						{
							factionsMan.definedFactions[j].statusTo[i] = StatusTowardsOther.Friendly;
							EditorUtility.SetDirty(factionsMan);
						}
					}

					r.x += 20;
				}
			}
		}

		private void CheckRelationList()
		{
			bool changed = false;
			for (int i = 0; i < factionsMan.definedFactions.Count; i++)
			{
				if (factionsMan.definedFactions[i].statusTo.Count < factionsMan.definedFactions.Count)
				{
					changed = true;
					int cnt = factionsMan.definedFactions.Count - factionsMan.definedFactions[i].statusTo.Count;
					for (int j = 0; j < cnt; j++) factionsMan.definedFactions[i].statusTo.Add(StatusTowardsOther.Friendly);
				}
			}
			if (changed) EditorUtility.SetDirty(factionsMan);
		}

		// ============================================================================================================
	}
}