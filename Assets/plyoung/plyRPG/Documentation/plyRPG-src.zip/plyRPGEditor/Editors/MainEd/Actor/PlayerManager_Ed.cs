﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[EdMenuOption("Player Manager", typeof(Characters_Ed))]
	public class PlayerManager_Ed : ChildEditorBase
	{

		private PlayerManager playerMan;
		private int selected = -1;
		private int artSel = -1;
		//private int metaSel = -1;

		private static GUIContent GC_plyBlox;
		private static GUIContent GC_plyBloxVars;

		// ============================================================================================================

		public override void OnFocus()
		{
			GameObject fab = plyEdUtil.LoadOrCreatePrefab<PlayerManager>("Player Manager", plyEdUtil.DATA_PATH_SYSTEM + "playerman.prefab");
			playerMan = fab.GetComponent<PlayerManager>();
			if (playerMan.blox == null)
			{
				playerMan.blox = fab.AddComponent<plyBlox>();
				EditorUtility.SetDirty(playerMan);
				EditorUtility.SetDirty(fab);
			}

			// check if the player manager is used and should be auto loaded by plyGame (or not)
			// is only "used" when at least the defaultPlayerFab is set to valid prefab
			if (playerMan.defaultPlayerFab != null || playerMan.defaultCharaIdx >= 0) EdGlobal.RegisterAutoCreate(fab);
			else EdGlobal.RemoveAutoCreate(fab);

			if (selected >= playerMan.playerCharacters.Count) selected = -1;
			artSel = -1;
			//metaSel = -1;
		}

		private void InitGUI()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_plyBlox = new GUIContent(FA.cube.ToString() + " Edit Events", "Open plyBlox Editor");
				GC_plyBloxVars = new GUIContent(FA.code.ToString() + " Edit Variables", "Edit Local plyBlox variables of object");
			}
		}

		public override void OnGUI()
		{
			InitGUI();
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Player Manager");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				EditorGUI.BeginChangeCheck();
				playerMan.defaultPlayerFab = (GameObject)EditorGUILayout.ObjectField("Default Player Prefab", playerMan.defaultPlayerFab, typeof(GameObject), false);
				if (EditorGUI.EndChangeCheck())
				{
					// check if the player manager is used and should be auto loaded by plyGame (or not)
					// is only "used" when at least the defaultPlayerFab is set to valid prefab
					if (playerMan.defaultPlayerFab != null || playerMan.defaultCharaIdx >= 0) EdGlobal.RegisterAutoCreate(playerMan.gameObject);
					else EdGlobal.RemoveAutoCreate(playerMan.gameObject);
				}

				GUILayout.Label("or use from defined");
				EditorGUI.indentLevel++;
				EditorGUI.BeginChangeCheck();
				playerMan.defaultCharaIdx = EditorGUILayout.IntField("character idx", playerMan.defaultCharaIdx);
				if (EditorGUI.EndChangeCheck())
				{
					if (playerMan.defaultPlayerFab != null || playerMan.defaultCharaIdx >= 0) EdGlobal.RegisterAutoCreate(playerMan.gameObject);
					else EdGlobal.RemoveAutoCreate(playerMan.gameObject);
				}
				playerMan.defaultCharaArtIdx = EditorGUILayout.IntField("art idx", playerMan.defaultCharaArtIdx);
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.EndVertical();

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			if (GUILayout.Button(GC_plyBlox, plyEdGUI.ButtonStyle, GUILayout.Width(120), GUILayout.Height(25)))
			{
				if (playerMan.blox != null)
				{
					Selection.activeObject = playerMan.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd(playerMan.blox, "Player Manager");
				}
				else Debug.LogError("[PlayerManager Editor] The Player Manager object is invalid. No plyBlox object was found on it.");
			}
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_plyBloxVars, plyEdGUI.ButtonStyle, GUILayout.Width(135), GUILayout.Height(25)))
			{
				if (playerMan.blox != null)
				{
					Selection.activeObject = playerMan.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
				}
				else Debug.LogError("[PlayerManager Editor] The Player Manager object is invalid. No plyBlox object was found on it.");
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			plyEdGUI.SectionHeading("Player Characters");
			EditorGUILayout.BeginHorizontal(GUILayout.MaxWidth(450));
			{
				int res = plyEdGUI.SimpleItemList<PlayerManagerCharacterData>(ref selected, playerMan.playerCharacters, "Player Prefab", CharaData, GUILayout.Width(220));
				if (res >= 1)
				{
					if (res == 2)
					{
						playerMan.playerCharacters.Add(new PlayerManagerCharacterData());
						GUI.changed = true;
					}
					else if (res >= 10)
					{
						res -= 10;
						playerMan.playerCharacters.RemoveAt(res);
						GUI.changed = true;
					}

					plyEdGUI.ClearFocus();
					//metaSel = -1;
					artSel = -1;
				}

				if (selected >= 0)
				{
					res = plyEdGUI.SimpleItemList<GameObject>(ref artSel, playerMan.playerCharacters[selected].artPrefabs, "Art Prefab", ArtData);
					if (res >= 1)
					{
						if (res == 2)
						{
							playerMan.playerCharacters[selected].artPrefabs.Add(null);
							GUI.changed = true;
						}
						else if (res >= 10)
						{
							res -= 10;
							playerMan.playerCharacters[selected].artPrefabs.RemoveAt(res);
							GUI.changed = true;

						}
						plyEdGUI.ClearFocus();
					}

					//plyEdGUI.MetaDataEditor(ref metaSel, ref playerMan.playerCharacters[selected].metaData, ed.Repaint, SaveData, null);
				}
				else
				{
					GUILayout.FlexibleSpace();
				}
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed) EditorUtility.SetDirty(playerMan);
		}

		public void SaveData(object sender, object[] args)
		{
			EditorUtility.SetDirty(playerMan);
		}

		public void CharaData(object sender, object[] args)
		{
			int idx = (int)args[0];
			EditorGUI.BeginChangeCheck();
			playerMan.playerCharacters[idx].characterPrefab = (GameObject)EditorGUILayout.ObjectField(playerMan.playerCharacters[idx].characterPrefab, typeof(GameObject), false);
			if (EditorGUI.EndChangeCheck()) EditorUtility.SetDirty(playerMan);
		}

		public void ArtData(object sender, object[] args)
		{
			int idx = (int)args[0];
			EditorGUI.BeginChangeCheck();
			playerMan.playerCharacters[selected].artPrefabs[idx] = (GameObject)EditorGUILayout.ObjectField(playerMan.playerCharacters[selected].artPrefabs[idx], typeof(GameObject), false);
			if (EditorGUI.EndChangeCheck()) EditorUtility.SetDirty(playerMan);
		}

		// ============================================================================================================
	}
}