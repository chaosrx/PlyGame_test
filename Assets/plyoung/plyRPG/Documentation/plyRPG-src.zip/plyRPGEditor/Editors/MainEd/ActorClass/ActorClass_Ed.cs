﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKit;
using plyBloxKitEditor;
using plyGame;

namespace plyGameEditor
{
	[ChildEditor("Classes", Order = -99975, Icon="class")]
	public class ActorClass_Ed : ChildEditorBase
	{
		private DataAsset dataAsset;
		private ActorClassesAsset classesAsset;
		private ActorClass currClass = null;

		private ActorAttributesAsset attribsAsset;
		private ActorAttributeData currAtt = null;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		private int activeImg = 0;
		//private int imgEd = 0;

		private static GUIContent GC_AddAttribute;
		private static GUIContent GC_AddAllAttributes;
		private static GUIContent GC_DelAttribute;
		private static GUIContent GC_plyBlox;
		private static GUIContent GC_plyBloxVars;

		private GenericMenu attribsMenu;

		// ============================================================================================================

		public override void OnFocus()
		{
			if (classesAsset == null)
			{
				currAtt = null; currClass = null;
				dataAsset = EdGlobal.GetDataAsset();
				classesAsset = (ActorClassesAsset)dataAsset.GetAsset<ActorClassesAsset>();
				if (classesAsset == null)
				{
					classesAsset = (ActorClassesAsset)EdGlobal.LoadOrCreateAsset<ActorClassesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "classes.asset", "Class Definitions");
					if (classesAsset.classFabs.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(classesAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			classesAsset.UpdateCache();

			if (attribsAsset == null)
			{
				currAtt = null;
				dataAsset = EdGlobal.GetDataAsset();
				attribsAsset = (ActorAttributesAsset)dataAsset.GetAsset<ActorAttributesAsset>();
				if (attribsAsset == null)
				{
					attribsAsset = (ActorAttributesAsset)EdGlobal.LoadOrCreateAsset<ActorAttributesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "attributes.asset", "Attribute Definitions");
				}
			}
			
			attribsMenu = new GenericMenu();
			for (int i = 0; i < attribsAsset.attributes.Count; i++)
			{
				attribsMenu.AddItem(new GUIContent(attribsAsset.attributes[i].def.screenName), false, OnAttribMenuSelect, i);
			}

			// update the attributes' name cache
			foreach(ActorClass c in classesAsset.classes)
			{
				foreach (ActorAttributeData att in c.attributesInitData)
				{
					att.nameCache = attribsAsset.GetScreenName(att.id);
				}
			}
		}

		private void CheckGUIContent()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_AddAttribute = new GUIContent(FA.plus + " Add Attribute", "Add an Attribute");
				GC_AddAllAttributes = new GUIContent(FA.refresh + " Add All", "Add all defined Attributes");
				GC_DelAttribute = new GUIContent(FA.minus + " Remove Selected", "Remove selected Attribute");
				GC_plyBlox = new GUIContent(FA.cube.ToString() + " Edit Events", "Open plyBlox Editor");
				GC_plyBloxVars = new GUIContent(FA.code.ToString() + " Edit Variables", "Edit Local plyBlox variables of object");
			}
		}
		
		public override void OnGUI()
		{
			if (classesAsset == null) return;			
			CheckGUIContent();

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.ItemsList<ActorClass>(ref currClass, classesAsset.classes, true, false, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_ClassesEd, "No Classes Defined", GUILayout.Width(230)))
				{
					plyEdGUI.ClearFocus();
					currAtt = null;
				}

				if (currClass != null)
				{
					ShowSelectedInfo();
				}
				else GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			// --------------------------------------------------------------------------------------------------------
			if (GUI.changed)
			{
				GUI.changed = false;
				if (currClass != null) EditorUtility.SetDirty(currClass);
				EditorUtility.SetDirty(classesAsset);
			}
		}

		private ActorClass OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				UniqueID id = UniqueID.Create();
				string fn = plyRPGEdGlobal.DATA_PATH_CLASSES + id.ToString() + ".prefab";
				plyRPGEdGlobal.CheckDataPaths();
				
				//AssetDatabase.CopyAsset(EdGlobal.PACKAGE_PATH + "System/classtemplate.prefab", fn);
				//GameObject classFab = (GameObject)AssetDatabase.LoadAssetAtPath(fn, typeof(GameObject));
				GameObject classFab = plyEdUtil.CreatePrefab<ActorClass>("Class", fn);
				AssetDatabase.Refresh();

				currClass = classFab.GetComponent<ActorClass>();
				currClass.id = id;
				currClass.def.screenName = "Class " + classesAsset.classes.Count;
				EditorUtility.SetDirty(classFab);

				classesAsset.classFabs.Add(classFab);
				EditorUtility.SetDirty(classesAsset);

				classesAsset.classes.Add(currClass);
				if (dataAsset.AddAsset(classesAsset)) EditorUtility.SetDirty(dataAsset);
				return currClass;
			}
			else if (act == 2)
			{
				currAtt = null;
				ActorClass a = args[1] as ActorClass;

				plyRPGEdGlobal.CheckDataPaths();
				UniqueID id = UniqueID.Create();
				string fn = plyRPGEdGlobal.DATA_PATH_CLASSES + id.ToString() + ".prefab";

				//AssetDatabase.CopyAsset(EdGlobal.PACKAGE_PATH + "System/classtemplate.prefab", fn);
				//GameObject classFab = (GameObject)AssetDatabase.LoadAssetAtPath(fn, typeof(GameObject));
				GameObject classFab = plyEdUtil.CreatePrefab<ActorClass>("Class", fn);
				AssetDatabase.Refresh();

				currClass = classFab.GetComponent<ActorClass>();
				a.CopyTo(currClass);
				currClass.id = id;
				currClass.def.screenName = currClass.def.screenName + " (copy)";

				classesAsset.classFabs.Add(classFab);
				EditorUtility.SetDirty(classFab);
				EditorUtility.SetDirty(classesAsset);

				classesAsset.classes.Add(currClass);

				if (dataAsset.AddAsset(classesAsset)) EditorUtility.SetDirty(dataAsset);
				return currClass;
			}
			else if (act == 3)
			{
				plyRPGEdGlobal.CheckDataPaths();
				currAtt = null;
				ActorClass a = args[1] as ActorClass;
				string fn = plyRPGEdGlobal.DATA_PATH_CLASSES + a.id.ToString() + ".prefab";
				//classesAsset.classes.Remove(a); < the plyEdGUI.ItemsList does this, do not do it here
				classesAsset.classFabs.Remove(a.gameObject);
				EditorUtility.SetDirty(classesAsset);
				AssetDatabase.DeleteAsset(fn);
				AssetDatabase.Refresh();
				return null;
			}
			else if (act == 4)
			{
				currClass = classesAsset.classes.Count > 0 ? classesAsset.classes[0] : null;

				if (classesAsset.classFabs.Count == 0)
				{	// remove from dataAsset if no data defined
					if (dataAsset.RemoveAsset(classesAsset)) EditorUtility.SetDirty(dataAsset);
				} 

				return currClass;
			}
			else if (act == 5)
			{
				classesAsset.classFabs = new List<GameObject>();
				for (int i = 0; i < classesAsset.classes.Count; i++) classesAsset.classFabs.Add(classesAsset.classes[i].gameObject);
			}

			EditorUtility.SetDirty(classesAsset);
			return null;
		}

		private void ShowSelectedInfo()
		{
			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
			EditorGUILayout.BeginVertical();
			{
				BasicInfo();
				plyBloxEdButtons();
				LevelingInfo();
				Attributes();
				plyEdGUI.HLine(20);
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
		}

		private void BasicInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Class Definition");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				CommonDefinitionDataDrawer.Draw(currClass.def, ref activeImg);
			}
			EditorGUILayout.EndVertical();
		}

		private void plyBloxEdButtons()
		{
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			if (GUILayout.Button(GC_plyBlox, plyEdGUI.ButtonStyle, GUILayout.Width(120), GUILayout.Height(25)))
			{
				if (currClass.blox == null)
				{
					currClass.blox = currClass.gameObject.GetComponent<plyBlox>();
					EditorUtility.SetDirty(currClass);
				}

				if (currClass.blox != null)
				{
					Selection.activeObject = currClass.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd(currClass.blox, currClass.def.screenName);
				}
				else Debug.LogError("[Class Editor] The Actor Class object is invalid. No plyBlox object was found on it.");
			}
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_plyBloxVars, plyEdGUI.ButtonStyle, GUILayout.Width(135), GUILayout.Height(25)))
			{
				if (currClass.blox == null)
				{
					currClass.blox = currClass.gameObject.GetComponent<plyBlox>();
					EditorUtility.SetDirty(currClass);
				}

				if (currClass.blox != null)
				{
					Selection.activeObject = currClass.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
				}
				else Debug.LogError("[Class Editor] The Actor Class object is invalid. No plyBlox object was found on it.");
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		}

		private void LevelingInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Leveling (Experience Curve)");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				EditorGUILayout.BeginHorizontal();
				{
					EditorGUILayout.BeginVertical(GUILayout.MaxWidth(200));
					{
						plyEdGUI.LookLikeControls(120);
						EditorGUI.BeginChangeCheck();
						currClass.maxLevel = EditorGUILayout.IntField("Max Level", currClass.maxLevel);
						currClass.maxXP = EditorGUILayout.IntField("Max Experience", currClass.maxXP);
						if (EditorGUI.EndChangeCheck())
						{
							if (currClass.maxXP < 1) currClass.maxXP = 1;
							if (currClass.maxLevel < 1) currClass.maxLevel = 1;
							currClass.xpCurve.Create(currClass.maxLevel, 0, currClass.maxXP);
						}
						plyEdGUI.LookLikeControls();
					}
					EditorGUILayout.EndVertical();
					if (plyEdGUI.CurveField(currClass.xpCurve, 230, 70, plyEdGUI.ColorTealTrans))
					{
						plyCurveEditor.ShowEditor("Experience Curve", currClass.xpCurve, 1, plyEdGUI.ColorTealTrans, "Level", "Experience", OnCurveChange);
					}
				}
				EditorGUILayout.EndHorizontal();
			}
			EditorGUILayout.EndVertical();
		}

		private void OnCurveChange(object sender, object[] args)
		{
			ed.Repaint();
		}

		private void Attributes()
		{
			plyEdGUI.SectionHeading("Attributes", false);
			EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
			{
				if (GUILayout.Button(GC_AddAttribute, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(130)))
				{
					attribsMenu.ShowAsContext();
				}
				
				if (GUILayout.Button(GC_AddAllAttributes, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(130)))
				{
					AddAllAttribs();
				}

				GUI.enabled = (currAtt != null);
				if (GUILayout.Button(GC_DelAttribute, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(130)))
				{
					plyEdGUI.ClearFocus();
					currClass.attributesInitData.Remove(currAtt);
					EditorUtility.SetDirty(currClass);
					currAtt = currClass.attributesInitData.Count > 0 ? currClass.attributesInitData[0] : null;
				}
				GUI.enabled = true;
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal(GUILayout.Width(450));
			{
				if (plyEdGUI.SimpleList<ActorAttributeData>(ref currAtt, currClass.attributesInitData, "No attributes added yet.", GUILayout.Width(225)))
				{
					plyEdGUI.ClearFocus();
				}
				EditorGUILayout.BeginVertical();
				{
					if (currAtt != null)
					{
						AttribInfo();
					}
					EditorGUILayout.Space();
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		private void AddAllAttribs()
		{
			plyEdGUI.ClearFocus();

			for (int idx = 0; idx < attribsAsset.attributes.Count; idx++)
			{
				bool found = false;
				for (int i = 0; i < currClass.attributesInitData.Count; i++)
				{
					if (currClass.attributesInitData[i].id == attribsAsset.attributes[idx].id)
					{
						found = true; break;
					}
				}

				if (!found)
				{
					ActorAttributeData att = new ActorAttributeData();
					att.id = attribsAsset.attributes[idx].id.Copy();
					att.nameCache = attribsAsset.attributes[idx].def.screenName;
					currClass.attributesInitData.Add(att);
				}
			}

			EditorUtility.SetDirty(currClass);
			currAtt = currClass.attributesInitData.Count > 0 ? currClass.attributesInitData[0] : null;
		}

		private void OnAttribMenuSelect(object obj)
		{
			int idx = (int)obj;
			if (idx >= attribsAsset.attributes.Count) return;
			if (attribsAsset.attributes[idx] == null) return;

			// check if the attribute not already added
			for (int i = 0; i < currClass.attributesInitData.Count; i++)
			{
				if (currClass.attributesInitData[i].id == attribsAsset.attributes[idx].id)
				{
					return;
				}
			}

			ActorAttributeData att = new ActorAttributeData();
			att.id = attribsAsset.attributes[idx].id.Copy();
			att.nameCache = attribsAsset.attributes[idx].def.screenName;
			currClass.attributesInitData.Add(att);
			EditorUtility.SetDirty(currClass);

			plyEdGUI.ClearFocus();
			currAtt = att;
		}

		private void AttribInfo()
		{
			EditorGUILayout.Space();

			if (currAtt.id == attribsAsset.xpAttribId)
			{
				GUILayout.Label("Editing the Experience Attribute\nhere has no effect.");
				return;
			}

			EditorGUI.BeginChangeCheck();
			currAtt.baseValue = EditorGUILayout.IntField("Base value", currAtt.baseValue);
			currAtt.maxValue = EditorGUILayout.IntField("Max value", currAtt.maxValue);
			if (EditorGUI.EndChangeCheck())
			{
				if (currAtt.canGrow) currAtt.growthCurve.Create(currClass.maxLevel, currAtt.baseValue, currAtt.maxValue);
			}

			EditorGUILayout.Space();
			EditorGUI.BeginChangeCheck();
			currAtt.canGrow = EditorGUILayout.Toggle("Grows with Level", currAtt.canGrow);
			if (EditorGUI.EndChangeCheck())
			{
				if (currAtt.canGrow) currAtt.growthCurve.Create(currClass.maxLevel, currAtt.baseValue, currAtt.maxValue);
				else currAtt.growthCurve = new plyCurve(0, 0, 0);
			}

			if (currAtt.canGrow)
			{
				currAtt.alsoUpdateConsumable = EditorGUILayout.Toggle("Update Consumable too", currAtt.alsoUpdateConsumable);
				if (plyEdGUI.CurveField(currAtt.growthCurve, 215, 70, plyEdGUI.ColorFuchsiaTrans))
				{
					plyCurveEditor.ShowEditor("Attribute Growth Curve", currAtt.growthCurve, 1, plyEdGUI.ColorFuchsiaTrans, "Level", currAtt.nameCache, OnCurveChange);
				}
			}
		}

		// ============================================================================================================
	}
}