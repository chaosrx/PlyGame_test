﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace plyGameEditor
{
	[ChildEditor("Loot", Order = -99700, Icon = "loot")]
	public class Loot_Ed : ChildEditorBase
	{
		private LootAsset lootAsset;
		private LootAsset.LootTable curr = null;
		private int sel = -1;

		private ActorAttributesAsset attribAsset;
		private ItemsAsset itemsAsset;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero };

		private static string[] TriggerTargetOpts = { "Player", "Subject" };

		private static GUIContent GC_AddItem;
		private static GUIContent GC_AddAttrib;
		private static GUIContent GC_AddEventTrigger;
		private static GUIContent GC_Remove;
		private static GUIStyle ButtonStyle;

		// ============================================================================================================

		public override void OnFocus()
		{
			DataAsset dataAsset = EdGlobal.GetDataAsset();

			if (lootAsset == null)
			{
				curr = null;
				lootAsset = (LootAsset)dataAsset.GetAsset<LootAsset>();
				if (lootAsset == null)
				{
					lootAsset = (LootAsset)EdGlobal.LoadOrCreateAsset<LootAsset>(plyEdUtil.DATA_PATH_SYSTEM + "loot.asset", "Loot Tables");
					if (dataAsset.AddAsset(lootAsset)) EditorUtility.SetDirty(dataAsset);
				}
			}

			if (attribAsset == null)
			{
				attribAsset = (ActorAttributesAsset)dataAsset.GetAsset<ActorAttributesAsset>();
				if (attribAsset == null)
				{
					attribAsset = (ActorAttributesAsset)EdGlobal.LoadOrCreateAsset<ActorAttributesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "attributes.asset", "Attribute Definitions");
					if (attribAsset.attributes.Count > 0)
					{
						if (dataAsset.AddAsset(attribAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			if (itemsAsset == null)
			{
				itemsAsset = (ItemsAsset)dataAsset.GetAsset<ItemsAsset>();
				if (itemsAsset == null)
				{
					itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Items System");
					if (dataAsset.AddAsset(itemsAsset)) EditorUtility.SetDirty(dataAsset);
				}
			}

			itemsAsset.UpdateItemCache();
		}

		private void CheckGUI()
		{
			if (GC_AddItem == null)
			{
				GC_AddItem = new GUIContent(FA.plus.ToString() + " Add Item", "Add an Item");
				GC_AddAttrib = new GUIContent(FA.plus.ToString() + " Add Attribute", "Add an Attribute");
				GC_AddEventTrigger = new GUIContent(FA.plus.ToString() + " Add Event",  "Add an Event to Trigger");
				GC_Remove = new GUIContent(FA.minus.ToString(), "Remove Selected");
				ButtonStyle = new GUIStyle(plyEdGUI.ItemListButtonStyle)
				{
					fixedWidth = 0,
					fontSize = 12,
					font = FA.Font
				};
			}
		}

		public override void OnGUI()
		{
			if (lootAsset == null) return;
			CheckGUI();

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.ItemsList<LootAsset.LootTable>(ref curr, lootAsset.lootTables, true, true, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_LootEd, "No Tables Defined", GUILayout.Width(230)))
				{
					sel = -1;
					plyEdGUI.ClearFocus();
					for (int i = 0; i < curr.loot.Count; i++)
					{
						if (curr.loot[i].id.IsEmpty)
						{
							curr.loot[i]._nameCache = "-select-";
						}
						else
						{
							if (curr.loot[i].type == LootAsset.Loot.LootType.Attribute)
							{
								ActorAttribute att = attribAsset.GetDefinition(curr.loot[i].id);
								if (att != null) curr.loot[i]._nameCache = att.ToString();
								else
								{
									curr.loot[i].id = UniqueID.Empty;
									curr.loot[i]._nameCache = "-select-";
								}
							}
							else
							{
								Item it = itemsAsset.GetDefinition(curr.loot[i].id);
								if (it != null) curr.loot[i]._nameCache = it.ToString();
								else
								{
									curr.loot[i].id = UniqueID.Empty;
									curr.loot[i]._nameCache = "-select-";
								}
							}
						}
					}
				}

				if (curr != null) ShowSelectedInfo();
				else GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(lootAsset);
			}
		}

		private LootAsset.LootTable OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				curr = new LootAsset.LootTable();
				curr.name = GetUniqueName();
				lootAsset.lootTables.Add(curr);
				EditorUtility.SetDirty(lootAsset);
				return curr;
			}
			else if (act == 2)
			{
				LootAsset.LootTable a = args[1] as LootAsset.LootTable;
				curr = (LootAsset.LootTable)a.Copy();
				curr.name = GetUniqueName();
				lootAsset.lootTables.Add(curr);
				EditorUtility.SetDirty(lootAsset);
				return curr;
			}
			//else if (act == 3)
			//{
			//}
			//else if (act == 4)
			//{
			//}
			//else if (act == 5)
			//{
			//}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Loot Table", "Enter a unique name", curr.name, OnRename, null);
				return curr;
			}

			EditorUtility.SetDirty(lootAsset);
			return null;
		}

		private string GetUniqueName()
		{
			int cnt = lootAsset.lootTables.Count;
			string name = "Loot " + cnt;
			bool done = true;
			do
			{
				done = true;
				for (int i = 0; i < lootAsset.lootTables.Count; i++)
				{
					if (name.Equals(lootAsset.lootTables[i].name))
					{
						done = false;
						break;
					}
				}

				if (!done)
				{
					cnt++;
					name = "Loot " + cnt;
				}

			} while (!done);
			return name;
		}

		private void OnRename(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s) && !curr.name.Equals(s))
			{
				bool found = false;
				for (int i = 0; i < lootAsset.lootTables.Count; i++)
				{
					if (s.Equals(lootAsset.lootTables[i].name))
					{
						found = true;
						break;
					}
				}

				if (!found)
				{
					curr.name = s;
					EditorUtility.SetDirty(lootAsset);
				}
				else EditorUtility.DisplayDialog("Error", "The Loot Table name must be unique", "OK");
			}

			ed.Repaint();
		}

		private void ShowSelectedInfo()
		{
			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.Space();
				plyEdGUI.SectionHeading("Options", false);
				lootAsset.useRB = EditorGUILayout.Toggle("Use Rigidbody", lootAsset.useRB);
				EditorGUILayout.Space();

				plyEdGUI.SectionHeading("Loot Table", false);

				EditorGUILayout.BeginVertical(plyEdGUI.ItemListBoxStyle, GUILayout.MaxWidth(450));
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUILayout.Space(6);
						//GUILayout.Label(heading, ItemListHeadStyle);
						GUILayout.FlexibleSpace();
						if (GUILayout.Button(GC_AddItem, ButtonStyle))
						{
							LootAsset.Loot l = new LootAsset.Loot() { type = LootAsset.Loot.LootType.Item, _nameCache = "-select-" };
							curr.loot.Add(l);
							EditorUtility.SetDirty(lootAsset);
						}

						if (GUILayout.Button(GC_AddAttrib, ButtonStyle))
						{
							LootAsset.Loot l = new LootAsset.Loot() { type = LootAsset.Loot.LootType.Attribute, _nameCache = "-select-" };
							curr.loot.Add(l);
							EditorUtility.SetDirty(lootAsset);
						}

						if (GUILayout.Button(GC_AddEventTrigger, ButtonStyle))
						{
							LootAsset.Loot l = new LootAsset.Loot() { type = LootAsset.Loot.LootType.EventTrigger };
							curr.loot.Add(l);
							EditorUtility.SetDirty(lootAsset);
						}

						GUI.enabled = sel != -1;
						if (GUILayout.Button(GC_Remove, ButtonStyle))
						{
							curr.loot.RemoveAt(sel);
							EditorUtility.SetDirty(lootAsset);
							sel = -1;
						}
						GUI.enabled = true;
						GUILayout.Space(6);

					}
					EditorGUILayout.EndHorizontal();
					GUILayout.Space(1);

					EditorGUILayout.BeginHorizontal(plyEdGUI.ItemListEntry1Style);
					{
						GUILayout.Label("Reward", GUILayout.Width(226));
						GUILayout.Label("Chance", GUILayout.Width(60));
						GUILayout.Label("NPC Level", GUILayout.Width(90));
						GUILayout.Label("Group", GUILayout.Width(40));
						GUILayout.FlexibleSpace();
					}
					EditorGUILayout.EndHorizontal();

					bool style2 = false;
					bool isSelected = false;
					for (int i = 0; i < curr.loot.Count; i++)
					{
						style2 = !style2;
						isSelected = i == sel;

						Rect r = EditorGUILayout.BeginHorizontal(isSelected ? plyEdGUI.ItemListEntrySelectedStyle : style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
						{
							if (Event.current.type == EventType.MouseDown && !isSelected)
							{
								if (r.Contains(Event.current.mousePosition))
								{
									sel = i;
									plyEdGUI.ClearFocus();
									ed.Repaint();
								}
							}

							if (curr.loot[i].type == LootAsset.Loot.LootType.EventTrigger)
							{
								GUILayout.Label("Trigger");
								curr.loot[i].eventName = EditorGUILayout.TextField(curr.loot[i].eventName);
								GUILayout.Label("in");
								curr.loot[i].bloxOf = EditorGUILayout.Popup(curr.loot[i].bloxOf, TriggerTargetOpts);
								GUILayout.Label("with param1");
								curr.loot[i].param1 = EditorGUILayout.TextField(curr.loot[i].param1);
								EditorGUILayout.EndHorizontal();
								EditorGUILayout.BeginHorizontal(isSelected ? plyEdGUI.ItemListEntrySelectedStyle : style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
								GUILayout.Label("options: ", GUILayout.Width(230));
							}

							else
							{
								if (GUILayout.Button(curr.loot[i]._nameCache, GUILayout.Width(180)))
								{
									if (curr.loot[i].type == LootAsset.Loot.LootType.Attribute)
									{
										List<object> l = new List<object>();
										for (int j = 0; j < attribAsset.attributes.Count; j++) l.Add(new UniqueIdNamePair() { id = attribAsset.attributes[j].id.Copy(), name = attribAsset.attributes[j].def.screenName });
										plyListSelectWiz.ShowWiz("Select Attribute", l, false, null, OnSelected, new object[] { i });
									}
									else if (curr.loot[i].type == LootAsset.Loot.LootType.Item)
									{
										List<object> l = new List<object>();
										for (int j = 0; j < itemsAsset.items.Count; j++) l.Add(new UniqueIdNamePair() { id = itemsAsset.items[j].prefabId.Copy(), name = itemsAsset.items[j].ToString() });
										plyListSelectWiz.ShowWiz("Select Item", l, false, null, OnSelected, new object[] { i });
									}
								}

								GUILayout.Label("x");
								curr.loot[i].count = EditorGUILayout.IntField(curr.loot[i].count, GUILayout.Width(30));
							}

							curr.loot[i].chance = EditorGUILayout.FloatField(curr.loot[i].chance, GUILayout.Width(30));
							GUILayout.Label("%");
							GUILayout.Space(10);

							curr.loot[i].lookatNpcLevel = EditorGUILayout.Toggle(curr.loot[i].lookatNpcLevel, GUILayout.Width(20));
							GUI.enabled = curr.loot[i].lookatNpcLevel;
							GUILayout.Label(">=");
							curr.loot[i].npcLevelCheck = EditorGUILayout.IntField(curr.loot[i].npcLevelCheck, GUILayout.Width(30));
							GUI.enabled = true;

							GUILayout.Space(10);
							curr.loot[i].group = EditorGUILayout.IntField(curr.loot[i].group, GUILayout.Width(30));
						

							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
		}

		private void OnSelected(object sender, object[] args)
		{
			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair sel = wiz.selected as UniqueIdNamePair;

			if (sel != null)
			{
				int i = (int)args[0];
				curr.loot[i].id = sel.id;
				curr.loot[i]._nameCache = sel.name;
				EditorUtility.SetDirty(lootAsset);
			}

			wiz.Close();
			ed.Repaint();
		}

		// ============================================================================================================
	}
}