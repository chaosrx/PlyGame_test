﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(ItemBag))]
	public class ItemBag_Inspector : Editor
	{
		private static bool showDebugInfo = false;
		private ItemsAsset asset;

		protected void OnEnable()
		{
			if (asset == null) asset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Item Definitions");
		}

		public override void OnInspectorGUI()
		{
			plyEdGUI.UseSkin();
			ItemBag Target = (ItemBag)target;

			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);

			if (asset.storageMethod == ItemsAsset.StorageMethod.Weight)
			{
				Target.maxWeight = EditorGUILayout.FloatField("Max Weight", Target.maxWeight);
				if (Target.maxWeight < 1) { Target.maxWeight = 1; GUI.changed = true; }
			}
			else if (asset.storageMethod == ItemsAsset.StorageMethod.Slots)
			{
				GUILayout.Label("Slots Layout");
				EditorGUI.indentLevel++;
				Target.slotsWidth = EditorGUILayout.IntField("Width", Target.slotsWidth);
				Target.slotsHeight = EditorGUILayout.IntField("Height", Target.slotsHeight);
				if (Target.slotsWidth < 1) { Target.slotsWidth = 1; GUI.changed = true; }
				if (Target.slotsHeight < 1) { Target.slotsHeight = 1; GUI.changed = true; }
				EditorGUI.indentLevel--;
			}

			Target.allowMultiStackSame = EditorGUILayout.Toggle("allowMultiStackSame", Target.allowMultiStackSame);

			if (GUI.changed)
			{
				EditorUtility.SetDirty(target);
				GUI.changed = false;
			}

			if (false == EditorApplication.isPlaying || Target.items == null) return;

			GUI.color = Color.red;
			if (plyEdGUI.ToggleButton(showDebugInfo, "Show Debug Info", GUI.skin.button)) showDebugInfo = !showDebugInfo;
			GUI.color = Color.white;

			if (false == showDebugInfo) return;

			Rect container = new Rect();
			Rect r;
			EditorGUILayout.BeginVertical(GUI.skin.box);
			{
				EditorGUILayout.LabelField("Currency", Target.currency.ToString());
				if (asset.storageMethod == ItemsAsset.StorageMethod.Weight)
				{
					EditorGUILayout.LabelField("Weight", Target.currWeight + "/ " + Target.maxWeight);
				}
				else if (asset.storageMethod == ItemsAsset.StorageMethod.Slots)
				{
					GUILayout.Label("Slots");
					container = GUILayoutUtility.GetRect(Target.slotsWidth * 6, Target.slotsHeight * 6);
					r = new Rect(container.x, container.y, 5, 5);
					GUI.color = Color.black;
					for (int y = 0; y < Target.slotsHeight; y++)
					{
						for (int x = 0; x < Target.slotsWidth; x++)
						{
							GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
							r.x += 6;
						}
						r.x = container.x;
						r.y += 6;
					}
					GUI.color = Color.white;
				}
				EditorGUILayout.Space();

				plyEdGUI.SectionHeading("Items");
				EditorGUI.indentLevel++;
				for (int i = 0; i < Target.items.Count; i++)
				{
					EditorGUILayout.LabelField((Target.items[i].slot < 10 ? "0" : "") + Target.items[i].slot + ": ", Target.items[i].stack + "x " + (string.IsNullOrEmpty(Target.items[i].item.def.screenName) ? Target.items[i].item.name : Target.items[i].item.def.screenName));

					if (asset.storageMethod == ItemsAsset.StorageMethod.Slots)
					{
						int py = Target.items[i].slot / Target.slotsWidth;
						int px = Target.items[i].slot - (py * Target.slotsWidth);

						float rx = container.x + (px * 6);
						float ry = container.y + (py * 6);
						r = new Rect(rx, ry, 5, 5);
						for (int y = 0; y < Target.items[i].item.vSlots; y++)
						{
							for (int x = 0; x < Target.items[i].item.hSlots; x++)
							{
								GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
								r.x += 6;
							}
							r.y += 6;
							r.x = rx;
						}
					}
				}
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.EndVertical();
			Repaint();
		}
	}
}
