﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(WaypointPath))]
	public class WaypointPath_Inspector : Editor
	{
		private WaypointPath Target;
		private bool doRepaint = false;
		private bool refreshInspector = false;

		private Waypoint curr = null;
		private Waypoint del = null;
		private static Tool currTool = Tool.Move;

		// ============================================================================================================

		protected void OnEnable() 
		{
			Target = (WaypointPath)target;
			currTool = Tools.current;
		}

		protected void OnDisable()
		{
			Tools.current = currTool;
		}

		public override void OnInspectorGUI()
		{
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("Add Waypoint", GUILayout.Width(120), GUILayout.Height(25)))
				{
					Waypoint p = new Waypoint();

					if (curr != null)
					{
						int pos = Target.points.IndexOf(curr);
						p.localPosition = curr.position + new Vector3(0.5f, 0f, 0f);
						Target.points.Insert(pos + 1, p);
					}
					else
					{
						if (Target.points.Count == 0) p.localPosition = new Vector3(-2f, 0.1f, 0f);
						else p.localPosition = new Vector3(0.5f, 0f, 0f) + Target.points[Target.points.Count - 1].localPosition;
						Target.points.Add(p);
					}
					curr = p;
					doRepaint = true;
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Label("Points in Path", EditorStyles.largeLabel);
			for (int i = 0; i < Target.points.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Space(10f);
					if (plyEdGUI.ToggleButton(curr == Target.points[i], "Point " + i, EditorStyles.miniButtonLeft))
					{
						if (curr == Target.points[i])
						{
							Tools.current = currTool;
							curr = null;
						}
						else
						{
							currTool = Tools.current;
							Tools.current = Tool.None;
							curr = Target.points[i];
						}
						doRepaint = true;
					}
					if (GUILayout.Button("X", EditorStyles.miniButtonRight, GUILayout.Width(20))) del = Target.points[i];
					GUILayout.Space(10f);
				}
				EditorGUILayout.EndHorizontal();

				if (curr == Target.points[i])
				{
					EditorGUILayout.Space();
					curr.localPosition = EditorGUILayout.Vector3Field("Position", curr.localPosition);
					curr.rotation.eulerAngles = EditorGUILayout.Vector3Field("Rotation", curr.rotation.eulerAngles);
					EditorGUILayout.Space();
				}
			}

			GUILayout.Space(15f);

			// ------------------------------------------------

			if (del != null)
			{
				if (curr == del) curr = null;
				Target.points.Remove(del);
				del = null;
				doRepaint = true;
			}

			if (doRepaint)
			{
				doRepaint = false;
				HandleUtility.Repaint();
				if (SceneView.lastActiveSceneView) SceneView.lastActiveSceneView.Repaint();
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		protected void OnSceneGUI()
		{
			if (Tools.current != Tool.None && curr != null)
			{
				currTool = Tools.current;
				Tools.current = Tool.None;
			}

			Vector3 offset = Target.transform.position;
			Vector3 lineOffset = offset + new Vector3(0f, 0.1f, 0f);

			for (int i = 0; i < Target.points.Count; i++)
			{
				int j = (i == Target.points.Count - 1 ? 0 : i + 1);

				if (Target.points[i] == curr)
				{
					Handles.color = Color.red;
					if (currTool == Tool.Rotate)
					{
						Handles.color = Color.blue;
						Handles.ArrowCap(0, Target.points[i].localPosition + offset, Target.points[i].rotation, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset));
						Handles.color = Color.red;
						Handles.CubeCap(0, Target.points[i].localPosition + offset, Target.points[i].rotation, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.2f);
						Target.points[i].rotation = Handles.RotationHandle(Target.points[i].rotation, Target.points[i].localPosition + offset);
					}
					else if (currTool == Tool.Move)
					{
						Handles.CubeCap(0, Target.points[i].localPosition + offset, Target.points[i].rotation, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.2f);
						Target.points[i].localPosition = Handles.PositionHandle(Target.points[i].localPosition + offset, Target.points[i].rotation) - offset;
					}
					else
					{
						Handles.CubeCap(0, Target.points[i].localPosition + offset, Target.points[i].rotation, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.2f);
					}
				}
				else
				{
					Handles.color = Color.green;
					if (Handles.Button(Target.points[i].localPosition + offset, Target.points[i].rotation, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.2f, HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.1f, DrawWaypointButton))
					{
						curr = Target.points[i];
						doRepaint = true;
						refreshInspector = true;
					}
				}

				Handles.DrawLine(Target.points[i].localPosition + offset, Target.points[i].localPosition + lineOffset);
				Handles.DrawLine(Target.points[i].localPosition + lineOffset, Target.points[j].localPosition + lineOffset);
				Vector3 f = (Target.points[j].localPosition + lineOffset) - (Target.points[i].localPosition + lineOffset); f.Normalize();
				Handles.ArrowCap(0, Target.points[i].localPosition + lineOffset, Quaternion.LookRotation(f), HandleUtility.GetHandleSize(Target.points[i].localPosition + offset) * 0.7f);
			}

			// ------------------------------------------------

			if (refreshInspector)
			{
				refreshInspector = false;
				this.Repaint();
			}
		}

		private void DrawWaypointButton(int controlId, Vector3 position, Quaternion rotation, float size)
		{
			Handles.CubeCap(controlId, position, rotation, size);
		}

		// ============================================================================================================
	}
}
