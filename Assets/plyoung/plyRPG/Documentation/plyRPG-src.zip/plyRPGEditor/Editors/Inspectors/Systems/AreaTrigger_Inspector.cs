﻿//// -= plyGame =-
//// www.plyoung.com
//// Copyright (c) Leslie Young
//// ====================================================================================================================

//using UnityEngine;
//using UnityEditor;
//using System.Collections;
//using System.Collections.Generic;
//using plyCommonEditor;
//using plyGame;
//using plyBloxKit;
//using plyBloxKitEditor;

//namespace plyGameEditor
//{
//	[CustomEditor(typeof(AreaTrigger))]
//	public class AreaTrigger_Inspector : Editor
//	{
//		private AreaTrigger Target;
//		private static GUIContent GC_plyBlox;

//		// ============================================================================================================

//		protected void OnEnable() 
//		{
//			Target = (AreaTrigger)target;
//			//GC_plyBlox = GC_plyBlox  new GUIContent(" Edit Events", plyEdGUI.LoadEditorTexture(plyEdGUI.ResPath + "Icons/plyBlox" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png"), "Open plyBlox Editor");
//		}

//		private void CheckGUIContent()
//		{
//			plyBloxGUI.UseSkin();
//			if (GC_plyBlox == null)
//			{
//				GC_plyBlox = new GUIContent(" Edit Events", plyBloxGUI.LogoIcon, "Open plyBlox Editor");
//			}
//		}

//		public override void OnInspectorGUI()
//		{
//			CheckGUIContent();
//			DrawDefaultInspector();

//			EditorGUILayout.Space();
//			EditorGUILayout.BeginHorizontal();
//			{
//				GUILayout.FlexibleSpace();
//				if (GUILayout.Button(GC_plyBlox, GUILayout.Width(120), GUILayout.Height(25)))
//				{
//					plyBlox b = Target.GetComponent<plyBlox>();
//					if (b == null) Target.gameObject.AddComponent<plyBlox>();
//					EditorGUIUtility.PingObject(Selection.activeObject);
//					plyBloxEd.Show_plyBloxEd();
//				}
//				GUILayout.FlexibleSpace();
//			}
//			EditorGUILayout.EndHorizontal();
//			EditorGUILayout.Space();

//			if (GUI.changed)
//			{
//				GUI.changed = false;
//				EditorUtility.SetDirty(target);
//			}
//		}

//		// ============================================================================================================
//	}
//}
