﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[CustomEditor(typeof(Actor))]
	public class Actor_Inspector : Editor
	{
		private ActorClassesAsset classesAsset;
		private SkillsAsset skillsAsset;
		private ActorFactionManager factionsMan;
		private ActorAttributesAsset attribAsset;

		private Actor Target;
		private int activeImg = 0;
		//private int imgEd = 0;
		private string[] classNames = new string[0];
		private int classIdx = -1;
		private bool isPlayer = false;
		private List<UniqueIdNamePair> skills = new List<UniqueIdNamePair>();
		private List<UniqueIdNamePair> factions = new List<UniqueIdNamePair>();
		private UniqueIdNamePair selectedSkill = null;
		private UniqueIdNamePair selectedFaction = null;
		private Component selectedDisableBehaviour = null;
		private static bool showDebugInfo = false;
		private int hpErr = 0;
		private Object prefabLink = null;
		private bool doListCheck = true;
		private UniqueID prefabUniqueId = null;

		// --------------------------------------------

		protected void OnEnable() 
		{
			Target = (Actor)target;

			if (false == EditorUtility.IsPersistent(target))
			{
				Actor fab = PrefabUtility.GetPrefabParent(target) as Actor;
				if (fab != null) prefabUniqueId = fab.id;
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref Target.id, prefabUniqueId, true, false))
			{
				EditorUtility.SetDirty(target);
			}

			if (classesAsset==null) classesAsset = (ActorClassesAsset)EdGlobal.LoadOrCreateAsset<ActorClassesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "classes.asset", "Class Definitions");
			if (attribAsset==null) attribAsset = (ActorAttributesAsset)EdGlobal.LoadOrCreateAsset<ActorAttributesAsset>(plyEdUtil.DATA_PATH_SYSTEM + "attributes.asset", "Attribute Definitions");

			classNames = classesAsset.GetNames();
			classIdx = classesAsset.GetDefinitionIdx(Target.classId);

			if (classIdx == -1 && classesAsset.classes.Count > 0)
			{
				classIdx = 0;
				Target.classId = classesAsset.classes[0].id.Copy();
				EditorUtility.SetDirty(target);
			}

			CharacterControllerBase cb = Target.gameObject.GetComponent<CharacterControllerBase>();
			if (cb != null) isPlayer = cb.IsPlayer();

			if (skillsAsset == null)
			{
				skillsAsset = (SkillsAsset)EdGlobal.LoadOrCreateAsset<SkillsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "skills.asset", "Skill Definitions");
			}

			if (factionsMan == null)
			{
				GameObject fab = plyEdUtil.LoadOrCreatePrefab<ActorFactionManager>("Factions Manager", plyEdUtil.DATA_PATH_SYSTEM + "factionsman.prefab");
				factionsMan = fab.GetComponent<ActorFactionManager>();
			}

			skillsAsset.UpdateCache();
			skills = new List<UniqueIdNamePair>();
			for (int i = 0; i < Target.startSkills.Count; i++)
			{
				Skill s = skillsAsset.GetDefinition(Target.startSkills[i]);
				if (s == null) skills.Add(new UniqueIdNamePair() { name = null, id = Target.startSkills[i].Copy() });
				else skills.Add(new UniqueIdNamePair() { name = s.def.screenName, id = s.id.Copy() });
			}

			factions = new List<UniqueIdNamePair>();
			for (int i = 0; i < Target.startFactions.Count; i++)
			{
				ActorFaction f = factionsMan.GetDefinitionById(Target.startFactions[i]);
				if (f == null) factions.Add(new UniqueIdNamePair() { name = null, id = Target.startFactions[i].Copy() });
				else factions.Add(new UniqueIdNamePair() { name = f.def.screenName, id = f.id.Copy() });
			}

			if (Target.persistenceOn)
			{	// make sure the PersistableObject is present
				PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
				if (p == null)
				{
					Target.gameObject.AddComponent<PersistableObject>();
					EditorUtility.SetDirty(Target.gameObject);
				}
			}

			if (attribAsset.hpAttribId.IsEmpty) hpErr = 1;
			else if (classIdx < 0) hpErr = 2;
			else
			{
				bool found = false;
				for (int i = 0; i < classesAsset.classes[classIdx].attributesInitData.Count; i++)
				{
					if (classesAsset.classes[classIdx].attributesInitData[i].id == attribAsset.hpAttribId)
					{
						found = true; break;
					}
				}
				if (!found) hpErr = 3;
			}

			// should check if this actor is in list and if not, add it
			doListCheck = true;
		}

		public override void OnInspectorGUI()
		{
			plyEdGUI.UseSkin();
			Target = (Actor)target;

			if (doListCheck && plyRPGEdGlobal.edData != null)
			{	
				// needed to wait for edData to become valid as it is loaded later
				doListCheck = false;
				plyRPGEdGlobal.edData.CheckActorFab(Target);
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref Target.id, prefabUniqueId, false, false))
			{
				EditorUtility.SetDirty(target);
			}

			PersistenceInfo();
			BasicInfo();
			ActorInfo();
			ShowDebugInfo();

			if (false == showDebugInfo || false == EditorApplication.isPlaying)
			{	// show the following only if debug info is not shown
				plyEdGUI.HLine(1, 0);
				DeathSettings();
				plyEdGUI.HLine(1, 0);
				StartSkills();
				StartFactions();
			}

			EditorGUILayout.Space();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		private void PersistenceInfo()
		{
			EditorGUI.BeginChangeCheck();
			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);
			if (EditorGUI.EndChangeCheck())
			{
				if (Target.persistenceOn)
				{	// make sure the PersistableObject is present
					PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
					if (p == null)
					{
						Target.gameObject.AddComponent<PersistableObject>();
						EditorUtility.SetDirty(Target.gameObject);
					}
				}
				//else
				//{
				//	PersistableObject[] p = Target.gameObject.GetComponents<PersistableObject>();
				//	if (p.Length > 0)
				//	{
				//		for (int i = 0; i < p.Length; i++) DestroyImmediate(p[i]);
				//		EditorUtility.SetDirty(Target.gameObject);
				//	}
				//}
			}

			if (Target.persistenceOn)
			{
				EditorGUI.indentLevel++;
				Target.persistActorData = EditorGUILayout.Toggle("Actor Data", Target.persistActorData);
				Target.persistClass = EditorGUILayout.Toggle("Class Data", Target.persistClass);
				Target.persistKnowSkills = EditorGUILayout.Toggle("Known Skills", Target.persistKnowSkills);
				Target.persistFactions = EditorGUILayout.Toggle("Factions", Target.persistFactions);
				EditorGUI.indentLevel--;
				plyEdGUI.HLine(0);
			}
		}

		private void BasicInfo()
		{
			CommonDefinitionDataDrawer.Draw(Target.def, ref activeImg);
		}

		private void ActorInfo()
		{
			EditorGUI.BeginChangeCheck();
			classIdx = EditorGUILayout.Popup("Class", classIdx, classNames);
			if (EditorGUI.EndChangeCheck()) Target.classId = classesAsset.classes[classIdx].id.Copy();
			Target.startLevel = EditorGUILayout.IntField("Init to Level", Target.startLevel);

			plyEdGUI.LookLikeControls();
			if (!isPlayer)
			{
				Target.overwriteStatus = EditorGUILayout.Toggle("Overwrite Status to Player", Target.overwriteStatus);
				if (Target.overwriteStatus)
				{
					EditorGUI.indentLevel++;
					Target.statusTowardsPlayer = (StatusTowardsOther)EditorGUILayout.EnumPopup("Status", Target.statusTowardsPlayer);
					EditorGUI.indentLevel--;
				}
			}

			Target.essential = EditorGUILayout.Toggle("Is Essential", Target.essential);			
		}

		// ============================================================================================================

		private void DeathSettings()
		{
			EditorGUILayout.Space();
			GUILayout.Label("Death");
			EditorGUI.indentLevel++;
			Target.autoDetectDeath = EditorGUILayout.Toggle("Auto-detect Death", Target.autoDetectDeath);

			if (Target.autoDetectDeath)
			{
				if (hpErr == 1) EditorGUILayout.HelpBox("You have not set any Attribute to represent Health. Open the plyGame Editor Attributes section to set.", MessageType.Warning, true);
				else if (hpErr == 2) EditorGUILayout.HelpBox("You need to set an Actor Class for the Actor.", MessageType.Warning, true);
				else if (hpErr == 3) EditorGUILayout.HelpBox("The Actor Class [" + classesAsset.classes[classIdx].def.screenName + "] of the Actor does not contain the Health Attribute.", MessageType.Warning, true);

				ObjectDestroyerHandler_Drawer.Draw(Target.objectDestroyer);

				int res = plyEdGUI.SimpleItemList<Component>(ref selectedDisableBehaviour, Target.disableOnDeath, "Disable Components", DrawDisableBehaviourItem);
				if (res == 1)
				{
					Repaint();
				}
				if (res == 2)
				{
					Target.disableOnDeath.Add(null);
					EditorUtility.SetDirty(target);
				}
				else if (res >= 10)
				{
					res = res - 10; // to get idx
					Target.disableOnDeath.RemoveAt(res);
					EditorUtility.SetDirty(target);
				}
			}
			EditorGUI.indentLevel--;
		}

		private void DrawDisableBehaviourItem(object sender, object[] args)
		{
			int idx = (int)args[0];
			Target.disableOnDeath[idx] = (Component)EditorGUILayout.ObjectField(Target.disableOnDeath[idx], typeof(Component), true);
			EditorGUILayout.Space();
		}

		// ============================================================================================================

		private void StartSkills()
		{
			EditorGUILayout.Space();

			int res = plyEdGUI.SimpleItemList<UniqueIdNamePair>(ref selectedSkill, skills, "Start Skills");
			
			if (res == 2)
			{
				skillsAsset.UpdateCacheIfNeeded();
				List<object> l = new List<object>();
				for (int i = 0; i < skillsAsset.skills.Count; i++) l.Add(new UniqueIdNamePair() { id = skillsAsset.skills[i].id.Copy(), name = skillsAsset.skills[i].def.screenName });
				l.Sort((a, b) => a.ToString().CompareTo(b.ToString()));
				plyListSelectWiz.ShowWiz("Select Skill", l, false, null, OnSkillSelect, null);
			}
			else if (res >= 10)
			{
				res = res - 10; // get idx of item to delete
				plyEdGUI.ClearFocus();
				Target.startSkills.Remove(skills[res].id);
				EditorUtility.SetDirty(target);
				if (System.Object.ReferenceEquals(selectedSkill, skills[res])) selectedSkill = null;
				skills.RemoveAt(res);
			}
		}

		private void OnSkillSelect(object sender, object[] args)
		{
			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();
			if (uimp != null)
			{
				if (false == Target.startSkills.Contains(uimp.id))
				{
					Target.startSkills.Add(uimp.id.Copy());
					skills.Add(new UniqueIdNamePair() { id = uimp.id.Copy(), name = uimp.name });
					EditorUtility.SetDirty(target);
				}
			}
			Repaint();
		}

		// ============================================================================================================

		private void StartFactions()
		{
			EditorGUILayout.Space();

			int res = plyEdGUI.SimpleItemList<UniqueIdNamePair>(ref selectedFaction, factions, "Start Factions");

			if (res == 2)
			{
				List<object> l = new List<object>();
				for (int i = 0; i < factionsMan.definedFactions.Count; i++) l.Add(new UniqueIdNamePair() { id = factionsMan.definedFactions[i].id.Copy(), name = factionsMan.definedFactions[i].def.screenName });
				plyListSelectWiz.ShowWiz("Select Faction", l, false, null, OnFactionSelect, null);
			}
			else if (res >= 10)
			{
				res = res - 10; // get idx of item to delete
				plyEdGUI.ClearFocus();
				Target.startFactions.Remove(factions[res].id);
				EditorUtility.SetDirty(target);
				if (System.Object.ReferenceEquals(selectedFaction, factions[res])) selectedFaction = null;
				factions.RemoveAt(res);
			}
		}

		private void OnFactionSelect(object sender, object[] args)
		{
			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();
			if (uimp != null)
			{
				if (false == Target.startFactions.Contains(uimp.id))
				{
					Target.startFactions.Add(uimp.id.Copy());
					factions.Add(new UniqueIdNamePair() { id = uimp.id.Copy(), name = uimp.name });
					EditorUtility.SetDirty(target);
				}
			}
			Repaint();
		}

		// ============================================================================================================

		private void ShowDebugInfo()
		{
			if (false == EditorApplication.isPlaying) return;

			GUI.color = Color.red;
			if (plyEdGUI.ToggleButton(showDebugInfo, "Show Debug Info", GUI.skin.button)) showDebugInfo = !showDebugInfo;
			GUI.color = Color.white;

			if (false == showDebugInfo) return;

			EditorGUILayout.BeginVertical(GUI.skin.box);
			if (Target.actorClass != null)
			{
				plyEdGUI.SectionHeading("Attributes");

				if (Target.actorClass.XP != null)
					EditorGUILayout.LabelField("Level", Target.actorClass.currLevel + "/ " + Target.actorClass.maxLevel + " (" + Target.actorClass.XP.Value + " XP)");
				if (Target.actorClass.HP != null)
					EditorGUILayout.LabelField("Health", Target.actorClass.HP.ConsumableValue + "/ " + Target.actorClass.HP.Value);

				EditorGUILayout.Space();
				for (int i = 0; i < Target.actorClass.attributes.Count; i++)
				{
					EditorGUILayout.LabelField(Target.actorClass.attributes[i].def.screenName, Target.actorClass.attributes[i].ConsumableValue + " / " + Target.actorClass.attributes[i].Value);
				}
			}

			plyEdGUI.SectionHeading("Skills");
			EditorGUILayout.LabelField("Executing", Target.executingSkill == null ? "-none-" : Target.executingSkill.def.screenName);
			EditorGUILayout.LabelField("Queued", Target.queuedSkill == null ? "-none-" : Target.queuedSkill.def.screenName);

			plyEdGUI.SectionHeading("Known Skills");
			if (Target.knownSkills != null)
			{
				for (int i = 0; i < Target.knownSkills.Count; i++)
				{
					GUILayout.Label(Target.knownSkills[i].def.screenName);
				}
			}

			EditorGUILayout.EndVertical();
			Repaint();
		}

		// ============================================================================================================
	}
}
