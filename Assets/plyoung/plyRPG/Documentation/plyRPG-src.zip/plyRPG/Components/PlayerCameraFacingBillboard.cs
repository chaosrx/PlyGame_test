﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/PlayerCamera Facing Billboard")]
	public class PlayerCameraFacingBillboard : MonoBehaviour
	{
		public bool limitOnY = false;

		private Transform _tr;
		private Transform camTr;
		private Vector3 v;

		protected void Awake()
		{
			GameGlobal.Create();
			_tr = transform;
		}

		protected void Update()
		{
			if (Player.Camera == null) return;
			if (camTr == null) camTr = Player.Camera.transform;

			if (limitOnY)
			{
				v = camTr.position - _tr.position;
				v.x = v.z = 0.0f;
				_tr.LookAt(camTr.transform.position - v);
			}
			else
			{
				_tr.LookAt(_tr.position + camTr.rotation * Vector3.back, camTr.rotation * Vector3.up);
			}
		}
		
		// ============================================================================================================
	}
}