﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Skills : plyEventHandler
	{
		private List<plyEvent> activateEvents = new List<plyEvent>(0);
		private List<plyEvent> effectEvents = new List<plyEvent>(0);
		private List<plyEvent> interruptEvents = new List<plyEvent>(0);
		private List<plyEvent> hitEvents = new List<plyEvent>(0);
		private List<plyEvent> hit2Events = new List<plyEvent>(0);
		private List<plyEvent> fizzleEvents = new List<plyEvent>(0);
		private List<plyEvent> validateEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			activateEvents = new List<plyEvent>(0);
			effectEvents = new List<plyEvent>(0);
			interruptEvents = new List<plyEvent>(0);
			hitEvents = new List<plyEvent>(0);
			hit2Events = new List<plyEvent>(0);
			fizzleEvents = new List<plyEvent>(0);
			validateEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Skill Activate"))
			{
				activateEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Skill Effect"))
			{
				effectEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Skill Interrupt"))
			{
				interruptEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Skill Hit"))
			{
				hitEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Skill Secondary Hit"))
			{
				hit2Events.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Skill Fizzle"))
			{
				fizzleEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Validate"))
			{
				validateEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (activateEvents.Count > 0 || effectEvents.Count > 0 || interruptEvents.Count > 0 || hitEvents.Count > 0 || hit2Events.Count > 0 || fizzleEvents.Count > 0 || validateEvents.Count > 0);

			activateEvents.TrimExcess();
			effectEvents.TrimExcess();
			interruptEvents.TrimExcess();
			hitEvents.TrimExcess();
			hit2Events.TrimExcess();
			fizzleEvents.TrimExcess();
			validateEvents.TrimExcess();
		}

		// ============================================================================================================

		// note that Unity defined "OnValidate" for MonoBehaviour so I named it something else here
		public bool OnValidateSkill(Actor skillOwner, Skill skillObject)
		{
			// default is to execute if no events are defined
			if (validateEvents.Count == 0) return true;
			for (int i = 0; i < validateEvents.Count; i++)
			{
				validateEvents[i].SetTempVarValue("skillOwner", skillOwner.gameObject);
				validateEvents[i].SetTempVarValue("skillObject", skillObject.gameObject);
				validateEvents[i].SetTempVarValue("skillOwnerData", skillOwner);
				validateEvents[i].SetTempVarValue("skillData", skillObject);
				bloxObject.RunEvent(validateEvents[i]);

				// return as soon as False is encountered
				bool res;
				if (plyReflectionUtil.TryGetBool(validateEvents[i].returnValue, out res))
				{
					if (res == false) return false;
				}
				else
				{
					Debug.LogError("[On Validate] for Skill ["+skillObject.ToString()+"] could not perform as the Event did not set its Return Value or it could not be converted to a Boolean (True/ False) value.");
					return false;
				}
			}

			return true;
		}

		public void OnActivate(Actor skillOwner, Skill skillObject, Vector3 selectedPos, Vector3 mouseClickPos)
		{
			if (activateEvents.Count == 0) return;
			RunEvents(activateEvents,
				new plyEventArg("skillOwner", skillOwner.gameObject),
				new plyEventArg("skillObject", skillObject.gameObject),
				new plyEventArg("skillOwnerData", skillOwner),
				new plyEventArg("skillData", skillObject),
				new plyEventArg("selectedPos", selectedPos),
				new plyEventArg("mouseClickPos", mouseClickPos)
			);
		}

		public void OnEffect(Actor skillOwner, Skill skillObject, Vector3 targetLocation, GameObject targetObject, Vector3 projectileForward, GameObject projectile)
		{
			if (effectEvents.Count == 0) return;
			RunEvents(effectEvents,
				new plyEventArg("skillOwner", skillOwner.gameObject),
				new plyEventArg("skillObject", skillObject.gameObject),
				new plyEventArg("skillOwnerData", skillOwner),
				new plyEventArg("skillData", skillObject),
				new plyEventArg("targetLocation", targetLocation),
				new plyEventArg("targetObject", targetObject),
				new plyEventArg("projectileForward", projectileForward),
				new plyEventArg("projectileObject", projectile)
			);
		}

		//public void OnInterrupted(Actor skillOwner, Skill skillObject)
		//{
		//	if (interruptEvents.Count == 0) return;
		//	RunEvents(interruptEvents,
		//		new plyEventArg("skillOwner", skillOwner.gameObject),
		//		new plyEventArg("skillObject", skillObject.gameObject),
		//		new plyEventArg("skillOwnerData", skillOwner),
		//		new plyEventArg("skillData", skillObject)
		//	);
		//}

		public void OnHit(Actor skillOwner, Skill skillObject, Targetable hitObject, Vector3 hitPoint, GameObject projectile)
		{
			if (hitEvents.Count == 0) return;
			RunEvents(hitEvents,
				new plyEventArg("skillOwner", skillOwner.gameObject),
				new plyEventArg("skillObject", skillObject.gameObject),
				new plyEventArg("hitObject", hitObject.gameObject),
				new plyEventArg("hitPoint", hitPoint),
				new plyEventArg("skillOwnerData", skillOwner),
				new plyEventArg("skillData", skillObject),
				new plyEventArg("hitObjectData", hitObject.DataObject()),
				new plyEventArg("projectileObject", projectile)
			);
		}

		public void OnSecondaryHit(Actor skillOwner, Skill skillObject, Targetable hitObject, Vector3 hitPoint, GameObject projectile)
		{
			if (hit2Events.Count == 0) return;
			RunEvents(hit2Events,
				new plyEventArg("skillOwner", skillOwner.gameObject),
				new plyEventArg("skillObject", skillObject.gameObject),
				new plyEventArg("hitObject", hitObject.gameObject),
				new plyEventArg("hitPoint", hitPoint),
				new plyEventArg("skillOwnerData", skillOwner),
				new plyEventArg("skillData", skillObject),
				new plyEventArg("hitObjectData", hitObject.DataObject()),
				new plyEventArg("projectileObject", projectile)
			);
		}

		public void OnFizzle(Actor skillOwner, Skill skillObject, Vector3 fizzlePos, bool wasObstacle, GameObject projectile)
		{
			if (fizzleEvents.Count == 0) return;
			RunEvents(fizzleEvents,
				new plyEventArg("skillOwner", skillOwner.gameObject),
				new plyEventArg("skillObject", skillObject.gameObject),
				new plyEventArg("fizzlePos", fizzlePos),
				new plyEventArg("wasObstacle", wasObstacle),
				new plyEventArg("skillOwnerData", skillOwner),
				new plyEventArg("skillData", skillObject),
				new plyEventArg("projectileObject", projectile)
			);
		}

		// ============================================================================================================
	}
}
