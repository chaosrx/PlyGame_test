﻿//// -= plyGame =-
//// www.plyoung.com
//// Copyright (c) Leslie Young
//// ====================================================================================================================

//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using plyBloxKit;

//namespace plyGame
//{
//	[plyEvent("plyRPG/Skill", "On Skill Interrupt",
//		Description = "Called when a skill is interrupted before it can create its effect, like a projectile. Instant Skills can't be interrupted as the effect is considered to be created immediately.\n\nThe following Temporary Variables will be set:\n\n"+
//		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
//		"- <b>skillObject</b>: The Skill (GameObject).\n" +
//		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
//		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"
//		)]
//	public class SkillInterruptEvent : plyEvent
//	{

//		public override System.Type HandlerType()
//		{
//			return typeof(EventHandler_Skills);
//		}

//		// ============================================================================================================
//	}
//}