﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_PlayerManager : plyEventHandler
	{
		private List<plyEvent> playerCreatedEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			playerCreatedEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Player Created"))
			{
				playerCreatedEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (playerCreatedEvents.Count > 0);

			playerCreatedEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnPlayerCreated()
		{
			if (playerCreatedEvents.Count == 0) return;
			RunEvents(playerCreatedEvents);
		}

		// ============================================================================================================
	}
}
