﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/PlayerManager", "On Player Created",
		Description = "Called when the Player Manager created/ instantiated the Player Character object. The event is triggered in the Blox of the PlayeManager only. It is called immediately after the character was created and the player might not yet be ready for use. Rather use `On Actor Ready` if you need to access the player properties during the event."
	)]
	public class PM_PlayerCreatedEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_PlayerManager);
		}

		// ============================================================================================================
	}
}