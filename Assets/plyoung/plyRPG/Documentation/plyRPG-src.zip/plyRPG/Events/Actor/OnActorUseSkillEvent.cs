﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor Uses Skill",
		Description = "Called when the Actor (Character) uses a Skill. This Event should be used in a Blox on the Actor object.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n" +
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"
		)]
	public class OnActorUseSkillEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Actor);
		}

		// ============================================================================================================
	}
}