﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor Ready",
		Description = "Called when the Actor (Character) is ready to be accessed. This is called after the Awake and Start Events and the LoadSave System are done, making this the best place to do initialization that might need to access properties of the character like the attributes and skills. This Event will trigger in Blox on the Character Object.\n")]
	public class OnActorReadyEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Actor);
		}

		// ============================================================================================================
	}
}