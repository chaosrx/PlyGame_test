﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Attribute", "On Level Change",
		Description = "Called when the Level of the Actor changes. This Event will only trigger in Blox on a Character object and child objects of it, like the Actor Class.\n\nThe following Temporary Variables will be set:\n\n- <b>level</b>: The current level of the Actor.\n")]
	public class LevelChangeEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Attributes);
		}

		// ============================================================================================================
	}
}