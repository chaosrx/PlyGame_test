﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Attribute", "On XP Change",
		Description = "Called when the Experience points (XP) of the Actor changed. This Event will only trigger in Blox on a Character object and child objects of it, like the Actor Class.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>attrib</b>: The attribute (System.Object). This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>attribValue</b>: The attribute value.\n" +
		"- <b>attribConsumable</b>: The consumable value of the attribute.\n" +
		"- <b>deltaVal</b>: With how much the Value changed (this can be a negative or positive number).\n" +
		"- <b>deltaCVal</b>: With how much the Consumable Value changed (this can be a negative or positive number).\n"
	)]
	public class XPChangeEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Attributes);
		}

		// ============================================================================================================
	}
}