﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/Player/Third Person Controller")]
	[RequireComponent(typeof(CharacterController))]
	public class PlayerThirdPersonController : PlayerBaseController
	{
		public CharacterController characterController;

		public float moveBackMulti = 0.7f;
		public bool allowJump = false;
		public float jumpSpeed = 10f;
		public float mouseTurnSpeedMulti = 0.5f;
		public float gamepadTurnSpeedMulti = 2f;
		public float gravity = 25f;

		public bool requireCursorLock = false;			// Turn this off if the camera should be controllable even without cursor lock
		public bool controlCursorLock = false;			// Turn this on if you want mouse lock controlled by this script

		public bool pf_Support = false;
		public float pf_CheckHeight = 1.0f;
		public float pf_CheckDist = 1.1f;

		// ============================================================================================================

		private Transform camTr;

		private const float inputThreshold = 0.01f;
		private float moved = 0f;
		private Vector3 movement = Vector3.zero;
		private Vector3 moveDirection = Vector3.zero;
		private Vector3 gravityVec = Vector3.zero;
		private bool startJump = false;
		private float jumpWaitTimer = 0f;
		private const float nextJumpTimeout = 0.5f; // helper to prevent weird bunny hopping jumping that fails the animation system
		private float nextJumpTimer = 0f;
		private float rotationAmount = 0f;
		private bool wasGrounded = false;

		private Vector3 targetFacing = Vector3.zero;
		private Vector3 forward = Vector3.zero;
		private Vector3 targetForcedPosition;
		private Vector3 lastMovement = Vector3.zero;
		private bool forcedMoving = false;
		private bool forcedTurning = false;
		private bool forcedTurningCompleting = false;
		private float forcedTurnTimeout = 0f;

		private int Key_LRMove = -1;
		private int Key_FBMove = -1;
		private int Key_TurnLR = -1;
		private int Key_Jump = -1;
		private int Key_HoldToTurn = -1;
		private int Key_TurnAxis = -1;
		private int Key_GamepadLRMove = -1;
		private int Key_GamepadFBMove = -1;
		private int Key_GamepadTurn = -1;

		// ============================================================================================================

		new protected void Reset()
		{
			base.Reset();
			moveSpeed = 7.0f;
			turnSpeed = 120.0f;
			mouseSelDistance = 10f;
			mouseSelAngle = 60;
			buttonSelDistance = 20f;
			buttonSelAngle = 60;
			autoMoveToInteract = false;
			
			if (characterController == null) characterController = GetComponent<CharacterController>();
		}

		protected override void Awake()
		{
			//useEdgeToEdge = false;
			base.Awake();
			
			if (characterController == null) characterController = GetComponent<CharacterController>();
			if (characterController == null)
			{
				Debug.LogError("[ThirdPersonController] No CharacterController assigned. Character will now be disabled.");
				enabled = false;
				return;
			}

			_tr = characterController.transform;
		}

		protected override void Start()
		{
			base.Start();

			// Cache the input idx
			Key_FBMove = plyInput.GetInputIdx("Player 3rd Person/ForwardBack Move");
			Key_LRMove = plyInput.GetInputIdx("Player 3rd Person/LeftRight Move");
			Key_TurnLR = plyInput.GetInputIdx("Player 3rd Person/LeftRight Turn");
			Key_Jump = plyInput.GetInputIdx("Player 3rd Person/Jump");
			Key_HoldToTurn = plyInput.GetInputIdx("Player 3rd Person/Hold to Turn");
			Key_TurnAxis = plyInput.GetInputIdx("Player 3rd Person/Turn Axis");
			Key_GamepadFBMove = plyInput.GetInputIdx("Player 3rd Person/Gamepad ForwardBack Move");
			Key_GamepadLRMove = plyInput.GetInputIdx("Player 3rd Person/Gamepad LeftRight Move");
			Key_GamepadTurn = plyInput.GetInputIdx("Player 3rd Person/Gamepad LeftRight Turn");
			
		}

		new protected void Update()
		{
			base.Update();

			if (camTr == null)
			{
				if (Player.Camera != null)
				{
					camTr = Player.Camera.transform;
				}
				else return;
			}

			if (GameGlobal.Paused) return;
			UpdateRotation();
			UpdateMovement();
		}

		private void UpdateRotation()
		{
			//if (!controlEnabled || hint_DoNotMove || Interacting) return;
			if (false == MovementControlAllowed()) return;

			rotationAmount = 0f;
#if UNITY5
			if (plyInput.GetButton(Key_HoldToTurn) && (!requireCursorLock || controlCursorLock || Cursor.lockState == CursorLockMode.Locked))
			{
				if (controlCursorLock) Cursor.lockState = CursorLockMode.Locked;
				rotationAmount = plyInput.GetAxis(Key_TurnAxis) * mouseTurnSpeedMulti * turnSpeed * Time.deltaTime;
			}
			else
			{
				if (controlCursorLock) Cursor.lockState = CursorLockMode.None;
				rotationAmount = plyInput.GetAxis(Key_TurnLR) * turnSpeed * Time.deltaTime;
				if (plyInput.IsActive(Key_GamepadTurn) && rotationAmount == 0.0f) rotationAmount = plyInput.GetAxis(Key_GamepadTurn) * gamepadTurnSpeedMulti * turnSpeed * Time.deltaTime;
			}
#else
			if (plyInput.GetButton(Key_HoldToTurn) && (!requireCursorLock || controlCursorLock || Screen.lockCursor))
			{
				if (controlCursorLock) Screen.lockCursor = true;
				rotationAmount = plyInput.GetAxis(Key_TurnAxis) * mouseTurnSpeedMulti * turnSpeed * Time.deltaTime;
			}
			else
			{
				if (controlCursorLock) Screen.lockCursor = false;
				rotationAmount = plyInput.GetAxis(Key_TurnLR) * turnSpeed * Time.deltaTime;
				if (plyInput.IsActive(Key_GamepadTurn) && rotationAmount == 0.0f) rotationAmount = plyInput.GetAxis(Key_GamepadTurn) * gamepadTurnSpeedMulti * turnSpeed * Time.deltaTime;
			}
#endif

			_tr.Rotate(_tr.up, rotationAmount);
		}

		private void UpdateMovement()
		{
			if (MovementControlAllowed())
			{
				moved = plyInput.GetAxis(Key_FBMove);
				if (plyInput.IsActive(Key_GamepadFBMove) && moved == 0.0f) moved = plyInput.GetAxis(Key_GamepadFBMove);
				
				movement = (moved * _tr.forward) + (SidestepAxisInput * _tr.right);
				
				if (moved != 0.0f)
				{
					StopInteract();
					forcedMoving = false;
					forcedTurning = false;
					actor.ReceivedMoveCommand();
				}
			}

			if (allowJump)
			{
				if (!startJump)
				{
					if (nextJumpTimer > 0.0f) nextJumpTimer -= Time.deltaTime;
					if (plyInput.GetButtonDown(Key_Jump) && nextJumpTimer <= 0.0f && wasGrounded && MovementControlAllowed())
					{
						StopInteract();
						forcedMoving = false;
						forcedTurning = false;
						startJump = true;
						jumpWaitTimer = 0f;
						moveDirection = Vector3.zero;
						if (onJump != null) jumpWaitTimer = (float)onJump(this, null);
						actor.ReceivedMoveCommand();
					}

					// Movement controls if did not just jump
					else
					{
						if (movement.magnitude > inputThreshold)
						{	// Apply movement if have sufficient input
							float appliedSpeed = (moved < 0.0f ? moveSpeed * moveBackMulti : moveSpeed);
							moveDirection = movement.normalized * appliedSpeed;
						}
						else
						{	// If grounded and don't have significant input, just stop horizontal movement
							moveDirection = Vector3.zero;
						}
					}
				}

				else
				{
					jumpWaitTimer -= Time.deltaTime;
					if (jumpWaitTimer <= 0.0f)
					{
						startJump = false;
						nextJumpTimer = nextJumpTimeout;
						gravityVec.y = jumpSpeed;
					}
				}
			}
			else
			{
				if (movement.magnitude > inputThreshold)
				{
					float appliedSpeed = (moved < 0.0f ? moveSpeed * moveBackMulti : moveSpeed);
					moveDirection = movement.normalized * appliedSpeed;
				}
				else moveDirection = Vector3.zero;
			}

			if (forcedTurning && !forcedMoving)
			{
				forward = Vector3.Lerp(_tr.forward, targetFacing, Time.deltaTime * turnSpeed);
				if (forward != Vector3.zero) _tr.rotation = Quaternion.LookRotation(forward, Vector3.up);

				if (forcedTurningCompleting)
				{
					forcedTurnTimeout -= Time.deltaTime;
					if (forcedTurnTimeout <= 0.0f)
					{
						forcedTurning = false;
						if (movement != Vector3.zero) targetFacing = movement.normalized;
					}
				}
				else
				{
					// check if facing in relatively correct direction and turn this off
					if (Vector3.Dot(_tr.forward, targetFacing) > 0.98f)
					{
						// I can't allow immediate return to facing the direction the character is moving
						// in as it will look stupid with a turn sped of 5 or more. So lets run backward
						// for a while before returning to facing correctly
						forcedTurningCompleting = true;
					}
				}
			}

			if (forcedMoving)
			{
				targetForcedPosition.y = _tr.position.y;
				movement = (targetForcedPosition - _tr.position);
				if (movement.magnitude < 0.2f)
				{
					forcedMoving = false;
					moveDirection = Vector3.zero;
					movement = Vector3.zero;
				}
				else
				{
					targetFacing = movement.normalized;
					moveDirection = movement.normalized * moveSpeed;
					forward = Vector3.Lerp(_tr.forward, targetFacing, Time.deltaTime * turnSpeed);
					if (forward != Vector3.zero) _tr.rotation = Quaternion.LookRotation(forward, Vector3.up);
				}
			}

			if (pf_Support && !startJump)
			// check if inside floor and force out of it
			{
				if (gravityVec.y <= 0.0f)
				{
					RaycastHit hitinfo;
					if (Physics.Raycast(_tr.position + (Vector3.up * pf_CheckHeight), -Vector3.up, out hitinfo, pf_CheckDist, 1 << GameGlobal.LayerMapping.Floor))
					{
						_tr.position = new Vector3(_tr.position.x, hitinfo.point.y, _tr.position.z);
						wasGrounded = true;
						gravityVec.y = 0.0f;
						moveDirection.y = 0f;
					}
				}
			}

			gravityVec.y -= gravity * Time.deltaTime;
			if ((characterController.Move((moveDirection + gravityVec) * Time.deltaTime) & CollisionFlags.Below) != 0)
			{
				wasGrounded = true;
				gravityVec = Vector3.zero;
			}
			else
			{
				wasGrounded = false;
			}
		}

		private float SidestepAxisInput
		{
			get
			{
				if (plyInput.GetButton(Key_HoldToTurn))
				{
					float sidestep = plyInput.GetAxis(Key_LRMove);  //plyInput.GetAxis(HMoveKey, GamepadHMove);
					float horizontal = plyInput.GetAxis(Key_TurnLR); //plyInput.GetAxis(TurnKey, GamepadTurn);
					return Mathf.Abs(sidestep) > Mathf.Abs(horizontal) ? sidestep : horizontal;
				}
				else
				{
					return plyInput.GetAxis(Key_LRMove, Key_GamepadLRMove);
				}
			}
		}

		// ============================================================================================================

		public override bool Grounded()
		{
			return wasGrounded;
		}

		public override Vector3 Velocity()
		{
			return characterController.velocity;
		}

		public override bool RequestFaceDirection(Vector3 direction, float delayAfter)
		{
			forcedTurning = true;
			forcedTurningCompleting = false;
			targetFacing = direction;
			targetFacing.y = 0f;
			forcedTurnTimeout = delayAfter;
			return true;
		}

		public override bool RequestMoveTo(Vector3 position, bool useFasterMovement)
		{
			forcedMoving = true;
			targetForcedPosition = position;
			movement = (targetForcedPosition - _tr.position);
			movement.y = 0f;
			return true;
		}

		public override void Stop()
		{
			movement = Vector3.zero;
		}

		public override Vector3 Movement()
		{
			return moveDirection;
		}

		public override void OnDeath()
		{
			Stop();
			base.OnDeath();
			if (characterController) characterController.enabled = false;
		}

		public override void OnRestore()
		{
			base.OnRestore();
			if (characterController) characterController.enabled = true;
		}

		// ============================================================================================================
	}
}