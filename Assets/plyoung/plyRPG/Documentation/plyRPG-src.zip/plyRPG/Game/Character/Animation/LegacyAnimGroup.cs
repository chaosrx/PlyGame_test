﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// Animation group used in Legacy animation controller
	/// </summary>
	[System.Serializable]
	public class LegacyAnimGroup
	{
		public string name; //!< name of group
		public LegacyAnimClipDef idleAnim = new LegacyAnimClipDef();	//!< idle animation
		public LegacyAnimClipDef deathAnim = new LegacyAnimClipDef();	//!< death animation
		public LegacyAnimClipDef jumpAnim = new LegacyAnimClipDef();	//!< jump animation
		public LegacyAnimClipDef fallAnim = new LegacyAnimClipDef();	//!< fall animation
		public LegacyAnimClipDef landAnim = new LegacyAnimClipDef();	//!< land animation
		public List<LegacyAnimMoveDef> moveDefs = new List<LegacyAnimMoveDef>(0); //!< the movement animation definitions
		public float jumpDelay = 0f; // tell controller to wait this long before actually moving the character upwards
		public float landMoveMulti = 0.7f;
	}
}