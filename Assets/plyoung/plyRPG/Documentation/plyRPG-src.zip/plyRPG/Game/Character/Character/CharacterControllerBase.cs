﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> The base class for all plyGame related character controllers. </summary>
	[AddComponentMenu("")]
	[RequireComponent(typeof(Actor))]
	public class CharacterControllerBase : Targetable, IPersistable
	{
		[System.Flags]
		public enum ValidInteractTargets
		{
			FriendlyActor = (1 << 0),
			NeutralActor = (1 << 1),
			HostileActor = (1 << 2),
			RPGObject = (1 << 3),
		}

		#region properties

		[HideInInspector] public bool persistenceOn = false;
		[HideInInspector] public bool persistSpeed = true;

		public bool useEdgeToEdge = false;
		public float moveSpeed = 5.0f;  //!< How fast the character should be moving when moving (or max speed it can reach)
		public float turnSpeed = 10.0f; //!< How fast the character can turn when turning (or max turn speed)
		public float maxInteractDistance = 2f;  //!< max distance this character can be from something to interact with it
		[EnumFlag("Valid Interact Target")]
		public ValidInteractTargets validInteractTarget = (ValidInteractTargets.FriendlyActor | ValidInteractTargets.NeutralActor | ValidInteractTargets.RPGObject);
		
		#endregion
		// ============================================================================================================
		#region runtime vars

		/// <summary> This character's currently selected Targetable object. For player controllers this
		///  would be what the player clicked on (characters, items and objects) last and for NPCs this
		///  would be what the AI selected (only other characters) </summary>
		public Targetable selectedTarget { get; set; }
		
		/// <summary> The object queued to be interacted with once character is in range and facing it. </summary>
		public Targetable queuedInteract { get; set; }
		private bool interactActive = false; // used to determine if should trigger stop interact event
		
		/// <summary> True while the character is "interacting" with something. StopInteract() must be called to stop it. </summary>
		public bool Interacting { get { return interactActive; } }

		[System.NonSerialized, HideInInspector]
		public ResultCallback onJump; //!< Assign to this a delegate to respond to the character jumping. LegacyAnimControl for example hooks into this so it knows when to play the jump clip. 

		// Assign to this a delegate to respond to the character dying. LegacyAnimControl for example hooks into this so it knows when to play the death clip. 
		public event GeneralCallback onDeath { add { onDeathInvoker += value; } remove { onDeathInvoker -= value; } }
		public event GeneralCallback onRestore { add { onRestoreInvoker += value; } remove { onRestoreInvoker -= value; } }

		private GeneralCallback onDeathInvoker;		// Because iOS doesn't have a JIT - Multi-cast function pointer.
		private GeneralCallback onRestoreInvoker;	// Because iOS doesn't have a JIT - Multi-cast function pointer.

		/// <summary> The Actor component of the character </summary>
		public Actor actor { get; private set; }

		/// <summary> The Transform component of the character </summary>
		public Transform _tr { get; set; }

		/// <summary> If set then the character should not move. Normally set by actor when a skill being used do not allow movement.</summary>
		public bool hint_DoNotMove { get; set; }

		/// <summary> Is control of the character enabled? Player characters should not accept input and an
		///  NPC's I should be off when this is false. </summary>
		public bool controlEnabled { get; set; }

		public Vector3 lastCalcedTargetPos { get; set; } // helper for edge-to-edge
		public Vector3 lastTargetPos { get; set; } // helper for edge-to-edge

		#endregion
		// ============================================================================================================
		#region sys

		protected override void Awake()
		{
			base.Awake();
			GameGlobal.Create(); // make sure it is available

			_tr = transform;
			actor = GetComponent<Actor>();

			controlEnabled = true;
			hint_DoNotMove = false;

			if (persistenceOn)
			{	// make sure a PersistableObject is present
				PersistableObject p = GetComponent<PersistableObject>();
				if (p == null)
				{
					persistenceOn = false;
					Debug.LogError("PersistableObject not found on [" + gameObject.name + "]. Persistence turned off.");
				}
			}
		}

		protected virtual void Start()
		{
			selectedTarget = null;
		}

		protected void LateUpdate()
		{
			if (GameGlobal.Paused) return;

			// check if should move towards or face an interact target
			if (queuedInteract != null && interactActive == false)
			{
				// only if not performing a skill
				if (actor.executingSkill == null)
				{   // check if in range

					bool inRange = true;
					Vector3 facePoint = queuedInteract.transform.position;
					if (useEdgeToEdge)
					{
						bool hit = false;
						Vector3 myPos = _tr.position; myPos.y = queuedInteract.transform.position.y + selectedTarget.centerOffs.y;
						Vector3 rayDir = ((lastTargetPos + queuedInteract.centerOffs) - myPos);
						RaycastHit[] hits = Physics.RaycastAll(myPos, rayDir.normalized, rayDir.magnitude + 1f);							
						for (int i = 0; i < hits.Length; i++)
						{
							if (hits[i].transform == queuedInteract.transform)
							{
								hit = true;
								facePoint = hits[i].point;
								if (false == plyUtil.IsInRange(_tr, hits[i].point, maxInteractDistance, 0, true))
								{
									inRange = false;
									RequestMoveTo(hits[i].point, true);
								}
								break;
							}
						}

						if (!hit)
						{
							inRange = false;
							RequestMoveTo(queuedInteract.transform.position, true);
						}
					}
					else if (false == plyUtil.IsInRange(_tr, queuedInteract.transform.position, maxInteractDistance, 0, true))
					{   // need to move closer still
						inRange = false;
						RequestMoveTo(queuedInteract.transform.position, true);
					}

					if (inRange)
					{   // check if facing in general direction of the interact target
						if (queuedInteract.MustFaceToInteract() && false == plyUtil.FacingInRange(_tr, facePoint, 0.96f))
						{
							RequestLookAt(facePoint, 0.1f);
						}
						else
						{
							Stop();

							interactActive = true;
							// tell this character that it is starting interaction with a target
							gameObject.BroadcastMessage("OnInteractStarted", queuedInteract, SendMessageOptions.DontRequireReceiver);

							// tell target that interaction with it is started
							queuedInteract.gameObject.BroadcastMessage("OnInteract", this, SendMessageOptions.DontRequireReceiver);
						}
					}
				}
			}
		}

		#endregion
		// ============================================================================================================
		#region Loading and Saving

		public virtual void Save(string key)
		{
			if (this.IsPlayer())
			{
				// player position should always be saved. player manager might have changed this.
				PersistableObject p = gameObject.GetComponent<PersistableObject>();
				if (p != null) p.persistPosition = true;
			}

			if (!persistenceOn) return;
			key = key + ".chr";
			if (persistSpeed)
			{
				GameGlobal.SetFloatKey(key + ".spdm", moveSpeed);
				GameGlobal.SetFloatKey(key + ".spdt", turnSpeed);
			}
		}

		public virtual void Load(string key)
		{
			if (!persistenceOn) return;
			key = key + ".chr";
			if (persistSpeed)
			{
				moveSpeed = GameGlobal.GetFloatKey(key + ".spdm", moveSpeed);
				turnSpeed = GameGlobal.GetFloatKey(key + ".spdt", turnSpeed);
			}
		}

		public virtual void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			key = key + ".chr";
			if (persistSpeed)
			{
				GameGlobal.DeleteKey(key + ".spdm");
				GameGlobal.DeleteKey(key + ".spdt");
			}
		}

		public virtual void DisablePersistence()
		{
			persistenceOn = false;
		}

		#endregion
		// ============================================================================================================
		#region targeting and interaction

		/// <summary> Called when a target is selected. et the selected target. If null or passed object
		///  is not a Targetable, then the selected target will be cleared. You should call
		///  base.SelectTarget() if you override this. </summary>
		public void SelectTarget(GameObject go)
		{
			Targetable t = go==null ? null : go.GetComponent<Targetable>();
			SelectTarget(t);
		}

		/// <summary> Called when a target is selected. If null then the selected target will be cleared.
		///  You should call base.SelectTarget() if you override this. </summary>
		public virtual void SelectTarget(Targetable t)
		{
			//Debug.Log("SelectTarget: " + t);
			if (selectedTarget != t) ClearTarget();
			if (t == null) return;

			selectedTarget = t;

			lastCalcedTargetPos = selectedTarget.transform.position;
			lastTargetPos = lastCalcedTargetPos;
			if (useEdgeToEdge)
			{
				Vector3 myPos = transform.position; myPos.y = lastTargetPos.y + selectedTarget.centerOffs.y;
				Vector3 rayDir = ((lastTargetPos + selectedTarget.centerOffs) - myPos);
				RaycastHit[] hits = Physics.RaycastAll(myPos, rayDir.normalized, rayDir.magnitude + 1f);
				for (int i = 0; i < hits.Length; i++)
				{
					if (hits[i].transform == selectedTarget.transform)
					{
						lastCalcedTargetPos = new Vector3(hits[i].point.x, lastTargetPos.y, hits[i].point.z);
						break;
					}
				}
			}

			gameObject.BroadcastMessage("OnTargetSelected", selectedTarget, SendMessageOptions.DontRequireReceiver);
		}

		/// <summary> Called when the target is cleared. You should call base.ClearTarget() if you override
		///  this. </summary>
		public virtual void ClearTarget()
		{
			//Debug.Log("ClearTarget: " + selectedTarget);
			actor.ClearQueuedSkill(); // might not have target selected, so call this before next check
			if (selectedTarget == null) return;
			StopInteract();
			if (selectedTarget != null)
			{
				gameObject.BroadcastMessage("OnTargetCleared", selectedTarget, SendMessageOptions.DontRequireReceiver);
			}
			selectedTarget = null;
		}

		/// <summary> The gameObject as target interact. The character will try to move to it and face it 
		/// before the Interact related events are triggered. </summary>
		public virtual void SetTargetInteract(GameObject go)
		{
			if (go != null)
			{
				Targetable t = go.GetComponent<Targetable>();
				SetTargetInteract(t);
			}
		}

		/// <summary> The character will try to move to it and face it 
		/// before the Interact related events are triggered. </summary>
		public virtual void SetTargetInteract(Targetable t)
		{
			if (t != null)
			{
				if (queuedInteract == t) return;
				StopInteract();
				if (selectedTarget != t) SelectTarget(t);

				// check if can actually interact with the target
				// if it is hostile then the normal interact can't be applied 

				if (t.TargetableType() == Type.Character)
				{
					CharacterControllerBase ch = t as CharacterControllerBase;
					if (ch != null)
					{
						StatusTowardsOther st = actor.HighestStatusToTarget(ch.actor);
						if (st == StatusTowardsOther.Friendly)
						{
							if ((validInteractTarget & ValidInteractTargets.FriendlyActor) != ValidInteractTargets.FriendlyActor) return;
						}
						else if (st == StatusTowardsOther.Neutral)
						{
							if ((validInteractTarget & ValidInteractTargets.NeutralActor) != ValidInteractTargets.NeutralActor) return;
						}
						else if (st == StatusTowardsOther.Hostile)
						{
							if ((validInteractTarget & ValidInteractTargets.HostileActor) != ValidInteractTargets.HostileActor) return;
						}
					}
					else return;
				}
				else if (t.TargetableType() == Type.Object)
				{
					if ((validInteractTarget & ValidInteractTargets.RPGObject) != ValidInteractTargets.RPGObject) return;
				}

				queuedInteract = t;
				interactActive = false;
			}
		}

		/// <summary> Trigger event on currently active interact </summary>
		public virtual void StopInteract()
		{
			if (false == interactActive)
			{
				queuedInteract = null;
				return;
			}

			// doing this before events to prevent the StopInteract from being called twice if the user calls clear target in the event
			interactActive = false;

			if (queuedInteract != null) // sanity check
			{
				// tell this character that it is stopping interaction with a target
				gameObject.BroadcastMessage("OnInteractStopped", queuedInteract, SendMessageOptions.DontRequireReceiver);

				// tell target that interaction with it is stopping
				queuedInteract.gameObject.BroadcastMessage("OnInteractStop", this, SendMessageOptions.DontRequireReceiver);
			}
			queuedInteract = null;
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> You will not need to override this in a base class as it already returns Type.Character. </summary>
		public override Type TargetableType()
		{
			return Type.Character;
		}

		/// <summary> You will not need to override this in a base class as it already returns actor (as data object). </summary>
		public override object DataObject()
		{
			return actor;
		}

		/// <summary> Return true if the character may accept input to generate movement </summary>
		public virtual bool MovementControlAllowed()
		{
			// This is overridden in PlayerBaseController to take movementCanStopInteraction into account
			return (controlEnabled && !hint_DoNotMove && !Interacting);
		}

		/// <summary> Derived class must override this to tell plyGame if this controller (Character) is a
		///  player character controller or non-player character (NPC). </summary>
		public virtual bool IsPlayer()
		{
			return false;
		}

		/// <summary> Enable or Disable Input (or AI in case of NPCs). Call base.EnableControl() if you override this. </summary>
		public virtual void EnableControl(bool en)
		{
			controlEnabled = en;
		}

		/// <summary> Called when the character is killed. Call base.Death() if you override this. </summary>
		public virtual void OnDeath()
		{
			ClearTarget();
			controlEnabled = false;
			this.enabled = false;
			if (onDeathInvoker != null) onDeathInvoker(this, null);
		}

		public virtual void OnRestore()
		{
			ClearTarget();
			controlEnabled = true;
			this.enabled = true;
			if (onRestoreInvoker != null) onRestoreInvoker(this, null);
		}

		/// <summary> Set the movement speed of the character </summary>
		public virtual void SetMoveSpeed(float speed)
		{
			moveSpeed = speed;
		}

		/// <summary> Set the turn speed of the character </summary>
		public virtual void SetTurnSpeed(float speed)
		{
			turnSpeed = speed;
		}

		/// <summary> Return the current move speed being used. This defaults to 
		/// returning moveSpeed but some controllers might override this if they 
		/// have other movement speed types, for example running during a chase. </summary>
		public virtual float MoveSpeed()
		{
			return moveSpeed;
		}

		/// <summary> Return the current turn speed being used. This defaults to 
		/// returning turnSpeed but some controllers might override this if they 
		/// have other movement speed types, for example running during a chase. </summary>
		public virtual float TurnSpeed()
		{
			return turnSpeed;
		}

		/// <summary> Is the character touching the floor/ ground? </summary>
		public virtual bool Grounded()
		{
			return true;
		}

		/// <summary> Character's current velocity </summary>
		public virtual Vector3 Velocity()
		{
			return Vector3.zero;
		}

		/// <summary> The calculated move vector. Needed by animation controllers that controls 
		/// root motion, like the basic mecanim controller. </summary>
		public virtual Vector3 Movement()
		{
			return Vector3.zero;
		}

		/// <summary> Turn the character to face in direction. Return false if this character controller do
		///  not accept requests to turn. Actor uses this to ask the character to look in direction it
		///  needs to perform a skill. The delayAfter determine how long the character will face the
		///  target direction, after reaching it and before returning to viewing in direction it is moving
		///  (if moving). </summary>
		public virtual bool RequestFaceDirection(Vector3 direction, float delayAfter)
		{
			return false;
		}

		/// <summary> Turn the character to face the target location (position). Return false if this
		///  character controller do not accept requests to turn. Actor uses this to ask the character to
		///  look in a direction to perform skill. The delayAfter determine how long the character will
		///  face the target direction, after reaching it and before returning to viewing in direction is
		///  is moving (if moving). </summary>
		public virtual bool RequestLookAt(Vector3 position, float delayAfter)
		{			
			return RequestFaceDirection((position - _tr.position).normalized, delayAfter);
		}

		/// <summary> Move the character to position. Return false if this character controller do not
		///  accept requests to move. Actor uses this to ask the character to move, for example when it
		///  needs the character to move closer to selected target or to perform a skill. </summary>
		/// <param name="position">The position to move to</param>
		/// <param name="useFasterMovement">A hint that a run speed should be used if the character supports it</param>
		public virtual bool RequestMoveTo(Vector3 position, bool useFasterMovement)
		{
			return false;
		}

		/// <summary> Ask character to stop moving and/ or turning </summary>
		public virtual void Stop()
		{
		}

		/// <summary> Ask character to stop. Removing queued targets and stop moving. </summary>
		public virtual void StopAll()
		{
			StopInteract();
			actor.ClearQueuedSkill();
			Stop();
		}

		#endregion
		// ============================================================================================================
	}
}