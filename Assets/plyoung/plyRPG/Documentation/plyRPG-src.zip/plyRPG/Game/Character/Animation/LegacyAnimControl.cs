﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// The Legacy Animation controller decides when to play the character's idle and movement related animations.
	/// </summary>
	[AddComponentMenu("plyGame/Character/Animation/LegacyAnim Control")]
	public class LegacyAnimControl : AnimationControlBase
	{
		// ============================================================================================================

		public Animation ani;					//!< The animation component being controlled
		public CharacterControllerBase chara;	//!< The character controller
		public float minSpeedDetect = 0.2f;		//!< Minimum movement speed before animation changes from idle to one of the defined movement animations

		public bool useBodyRot = false;
		public Transform bip;
		public Transform spine;

		public List<LegacyAnimGroup> aniGroups = new List<LegacyAnimGroup>();

		// ============================================================================================================

		enum State
		{
			Normal,
			Jumping,
			Falling,
			Landing,
			Death,
			Controlled	// being controlled externally - do not change to idle/ movement
		}
		
		private State state = State.Normal;
		private Transform _tr;

		private Vector3 movement = Vector3.zero;
		private float speed = 0f;
		private float prevSpeedDetect = 0f;
		private bool doBodyRotate = false;
		private float bodyRotate = 0f;
		private float currentRotation = 0f;
		private float lowerBodyRotSpeed = 6f;
		private bool canLand = false;

		private LegacyAnimGroup curr = null;

		// ============================================================================================================

		protected void Reset()
		{
			if (ani == null) ani = GetComponentInChildren<Animation>();
			if (chara == null) chara = GetComponentInChildren<CharacterControllerBase>();

			LegacyAnimGroup gr = new LegacyAnimGroup();
			gr.name = "Default";
			gr.deathAnim.wrapMode = WrapMode.Clamp;
			gr.jumpAnim.wrapMode = WrapMode.Once;
			gr.fallAnim.wrapMode = WrapMode.Once;
			gr.landAnim.wrapMode = WrapMode.Once;
			gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Walk", speedDetect = 4 });
			gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Run", speedDetect = 999 });

			aniGroups = new List<LegacyAnimGroup>(0);
			aniGroups.Add(gr);
		}

		protected void Awake()
		{
			GameGlobal.Create();
			_tr = chara.transform;

			if (aniGroups.Count == 0)
			{
				LegacyAnimGroup gr = new LegacyAnimGroup();
				gr.name = "Default";
				gr.deathAnim.wrapMode = WrapMode.Once;
				gr.jumpAnim.wrapMode = WrapMode.Once;
				gr.fallAnim.wrapMode = WrapMode.Once;
				gr.landAnim.wrapMode = WrapMode.Once;
				gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Walk", speedDetect = 4 });
				gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Run", speedDetect = 999 });
				aniGroups.Add(gr);
			}

			curr = aniGroups[0];
		}

		protected void Start()
		{
			if (ani == null) ani = GetComponentInChildren<Animation>();
			if (chara == null) chara = GetComponentInChildren<CharacterControllerBase>();

			if (ani == null)
			{
				Debug.LogError("[LegacyAnim Control] No animation component set.");
				enabled = false;
				return;
			}

			if (chara == null)
			{
				Debug.LogError("[LegacyAnim Control] No character controller set.");
				enabled = false;
				return;
			}

			// Init basic animations
			for (int i = 0; i < aniGroups.Count; i++)
			{
				aniGroups[i].deathAnim.Init(ani, true);
				aniGroups[i].jumpAnim.Init(ani, true);
				aniGroups[i].fallAnim.Init(ani, true);
				aniGroups[i].landAnim.Init(ani, true);

				if (false == aniGroups[i].idleAnim.Init(ani, false))
				{
					Debug.LogError("[LegacyAnim Control] Idle definition is invalid in Group: " + aniGroups[i].name);
					enabled = false;
					return;
				}

				// Init movement animations
				for (int j = 0; j < aniGroups[i].moveDefs.Count; j++) aniGroups[i].moveDefs[j].Init(ani);
				aniGroups[i].moveDefs.Sort((a, b) => { return a.speedDetect.CompareTo(b.speedDetect); });
			}

			// Bind callbacks
			chara.onJump += OnJump;
			chara.onDeath += OnDeath;
			chara.onRestore += OnRestore;

			// Done
			GoIdle();
		}

		// ============================================================================================================

		protected void Update()
		{
			if (state == State.Controlled || state == State.Death) return;

			movement = chara.Velocity(); movement.y = 0f;
			speed = movement.magnitude;

			switch (state)
			{
				case State.Normal:
				{
					if (speed != prevSpeedDetect)
					{
						prevSpeedDetect = speed;
						if (speed < minSpeedDetect)
						{
							doBodyRotate = false;
							curr.idleAnim.CrossFade();
						}
						else
						{
							for (int i = 0; i < curr.moveDefs.Count; i++)
							{
								if (speed <= curr.moveDefs[i].speedDetect)
								{
									bodyRotate = curr.moveDefs[i].PlayAni(speed, movement, chara, _tr, bip, spine);
									doBodyRotate = useBodyRot && (bodyRotate != 0f);
									break;
								}
							}
						}
					}
				} break;

				case State.Jumping: curr.jumpAnim.CrossFade(); break;
				case State.Falling: curr.fallAnim.CrossFade(); break;
				case State.Landing: curr.landAnim.CrossFade(); break;
			}
		}

		protected void LateUpdate()
		{
			if (state == State.Controlled || state == State.Death) return;
			if (doBodyRotate)
			{
				// Rotate the character and then rotate the upper-body to face forward
				currentRotation = Mathf.Lerp(currentRotation, bodyRotate, Time.deltaTime * lowerBodyRotSpeed);
				bip.RotateAround(bip.position, _tr.up, currentRotation);
				spine.RotateAround(spine.position, _tr.up, currentRotation * -1.0f);
			}
		}

		protected void FixedUpdate()
		{
			if (state == State.Controlled || state == State.Death) return;
			if (chara.Grounded())
			{
				if (state == State.Falling || (state == State.Jumping && canLand))
				{
					OnLand();
				}
			}
			else if (state == State.Jumping)
			{
				canLand = true;
			}
		}

		// ============================================================================================================

		private object OnJump(object sender, object[] args)
		{
			canLand = false;
			prevSpeedDetect = -9999;
			state = State.Jumping;
			Invoke("Fall", curr.jumpAnim.ClipLength);
			return curr.jumpDelay;
		}

		public void OnDeath(object npc, object[] args)
		{
			state = State.Death;
			curr.deathAnim.Play(true);
		}

		public void OnRestore(object npc, object[] args)
		{
			GoIdle();
		}

		private void OnLand()
		{
			canLand = false;
			prevSpeedDetect = -9999;
			state = State.Landing;
			Invoke("Land", curr.landAnim.ClipLength * (speed < minSpeedDetect ? 1.0f : curr.landMoveMulti));
		}

		private void Fall()
		{
			if (chara.Grounded()) return;
			prevSpeedDetect = -9999;
			state = State.Falling;
		}

		private void Land()
		{
			if (state != State.Landing) return;
			prevSpeedDetect = -9999;
			state = State.Normal;
		}

		// ============================================================================================================

		public void GoIdle()
		{
			state = State.Normal;
			curr.idleAnim.Play();
		}

		public void PlayAnimation(string name, bool queued, QueueMode queueMode, PlayMode playMode)
		{
			state = State.Controlled;
			if (queued) ani.PlayQueued(name, queueMode, playMode);
			else ani.Play(name, playMode);
		}

		public void CrossfadeAnimation(string name, float fadeLength, bool queued, QueueMode queueMode, PlayMode playMode)
		{
			state = State.Controlled;
			if (queued) ani.CrossFadeQueued(name, fadeLength, queueMode, playMode);
			else ani.CrossFade(name, fadeLength, playMode);
		}

		public void BlendAnimation(string name, float targetWeight, float fadeLength)
		{
			ani.Blend(name, targetWeight, fadeLength);
		}

		// ============================================================================================================

		public bool SetActiveGroup(string name)
		{
			if (!string.IsNullOrEmpty(name))
			{
				if (curr.name.Equals(name)) return true;
				for (int i = 0; i < aniGroups.Count; i++)
				{
					if (aniGroups[i].name.Equals(name))
					{
						curr = aniGroups[i];
						GoIdle();
						return true;
					}
				}
			}

			Debug.LogError("Failed to change Animation Group. Name not found: " + name);
			return false;
		}

		// ============================================================================================================
	}
}