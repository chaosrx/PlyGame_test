﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> All actors must have an Actor Class. The actor class links the actor with its
	///  attributes. </summary>
	[AddComponentMenu("")]
	[RequireComponent(typeof(plyBlox))]
	public class ActorClass : MonoBehaviour
	{
		#region properties

		[HideInInspector] public UniqueID id = new UniqueID();		//!< Unique id
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		[HideInInspector] public int maxLevel = 50;		//!< Max level that can be reached
		[HideInInspector] public int maxXP = 100000;	//!< XP needed to reach max level (the leveling curve is clamped between 0 and this value)
		[HideInInspector] public plyCurve xpCurve = new plyCurve(50, 0, 100000); //!< The curved used to determine XP and Level relation

		[HideInInspector] public List<ActorAttributeData> attributesInitData = new List<ActorAttributeData>(0); //!< The Attributes this Actor Class should have linked to and data that they should be initialized to at run-time. Do not use this directly at runtime as it is only used to init the attributes list

		[HideInInspector] public plyBlox blox;			//!< The blox object of this Actor Class

		#endregion
		// ============================================================================================================
		#region runtime

		/// <summary> The Actor that owns this Actor Class instance. </summary>
		public Actor owner { get; set; }

		/// <summary> List of instantiated attributes. Created from the attributesInitData. </summary>
		public List<ActorAttribute> attributes { get; private set; }

		/// <summary> Reference to the Health (HP) attribute of this Actor. The HP attribute works with
		///  Consumable value. The attribute's 'Value' is the max that its Consumable value can reach. </summary>
		public ActorAttribute HP { get; private set; }

		/// <summary> Reference to the Experience points (XP) of this Actor. The XP attribute works with
		///  its 'Value' property, not Consumable value property. </summary>
		public ActorAttribute XP { get; private set; }

		/// <summary> Current Level of this Actor </summary>
		public int currLevel 
		{
			get { return _currLevel; } 
			set 
			{
				_currLevel = value;
				if (_currLevel < 1) _currLevel = 1;
				if (_currLevel > maxLevel) _currLevel = maxLevel;

				if (XP != null)
				{	// reset XP to reflect the correct value for selected level
					// xpCurve counts from 0 (not 1). So -1 to start level 1 at (0)
					//XP.data.baseValue = xpCurve.GetYValue(_currLevel - 1);
					XP.SetBaseValue(xpCurve.GetYValue(_currLevel - 1));
				}

				UpdateLevelLinkedAttribs();
			}
		}
		private int _currLevel = 1;

		#endregion
		// ============================================================================================================
		#region copy

		public override string ToString()
		{
			return def.screenName;
		}

		public void CopyTo(ActorClass o)
		{
			o.id = this.id.Copy();
			o.def = this.def.Copy();

			o.maxLevel = this.maxLevel;
			o.maxXP = this.maxXP;
			o.xpCurve = new plyCurve(this.xpCurve);

			o.attributesInitData = new List<ActorAttributeData>();
			for (int i = 0; i < this.attributesInitData.Count; i++)
			{
				o.attributesInitData.Add((ActorAttributeData)this.attributesInitData[i].Copy());
			}

			this.blox.CopyTo(o.blox);
		}

		#endregion
		// ============================================================================================================
		#region start/init

		protected void Reset()
		{
			if (blox == null) blox = GetComponent<plyBlox>();
		}

		protected void Start()
		{
			if (blox == null) blox = GetComponent<plyBlox>();
			if (blox.NeedObjectActive == false) gameObject.SetActive(false); // no need for the object to be active
		}

		/// <summary> Called by Actor after creating an instance of its actor class so that some final
		///  Initialisation can be performed. </summary>
		public void Init(Actor owner, int startLevel)
		{
			this.owner = owner;
			attributes = new List<ActorAttribute>(0);
			for (int i = 0; i < attributesInitData.Count; i++)
			{
				ActorAttribute attDef = ActorAttributesAsset.Instance.GetDefinition(attributesInitData[i].id);
				if (attDef != null)
				{
					ActorAttribute att = (ActorAttribute)attDef.Copy();
					att.data = attributesInitData[i];
					att.Init(this, startLevel);
					attributes.Add(att);
				}
				else
				{
					Debug.LogError("[ActorClass] An attribute definition could not be found. Check the attributes for actor class: " + def.screenName);
				}
			}

			if (false == ActorAttributesAsset.Instance.hpAttribId.IsEmpty)
			{
				this.HP = GetAttribute(ActorAttributesAsset.Instance.hpAttribId);
				if (this.HP == null)
				{	// designer did not add HP to the class but it is linked in the attribute settings, so force add it now
					ActorAttribute attDef = ActorAttributesAsset.Instance.GetDefinition(ActorAttributesAsset.Instance.hpAttribId);
					if (attDef != null)
					{
						this.HP = (ActorAttribute)attDef.Copy();
						this.HP.data = new ActorAttributeData();
						this.HP.Init(this, startLevel);
						attributes.Add(this.HP);
					}
					else
					{
						Debug.LogError("[ActorClass] Failed to add the Health attribute.");
					}
				}
			}

			if (false == ActorAttributesAsset.Instance.xpAttribId.IsEmpty)
			{
				this.XP = GetAttribute(ActorAttributesAsset.Instance.xpAttribId);
				if (this.XP == null)
				{	// designer did not add XP to the class but it is linked in the attribute settings, so force add it now
					ActorAttribute attDef = ActorAttributesAsset.Instance.GetDefinition(ActorAttributesAsset.Instance.xpAttribId);
					if (attDef != null)
					{
						this.XP = (ActorAttribute)attDef.Copy();
						this.XP.data = new ActorAttributeData();
						this.XP.data.baseValue = 0;
						this.XP.data.maxValue = maxXP;
						this.XP.Init(this, -1);
						attributes.Add(this.XP);
					}
					else
					{
						Debug.LogError("[ActorClass] Failed to add the Experience attribute.");
					}
				}
				else
				{
					this.XP.data.baseValue = 0;
					this.XP.data.maxValue = maxXP;
					this.XP.Init(this, -1);
				}
			}

			currLevel = startLevel;
			if (this.XP != null)
			{
				this.XP.RegisterChangeListener(OnXPChange);
			}
		}

		#endregion
		// ============================================================================================================
		#region load/save (called directly by Actor when needed)

		public void Save(string key)
		{
			PersistableObject.SaveBloxLovalVars(key, blox);
			GameGlobal.SetIntKey(key + ".lv", currLevel);

			// save the attributes
			string k = key + ".att";
			for (int i = 0; i < attributes.Count; i++)
			{
				attributes[i].Save(k);
			}
		}

		public void Load(string key)
		{
			PersistableObject.LoadBloxLovalVars(key, blox);
			int newLv = GameGlobal.GetIntKey(key + ".lv", currLevel);

			// Call init so that the attributes are created
			Init(owner, newLv);

			// now load the attributes and recalculate as needed
			string k = key + ".att";
			for (int i = 0; i < attributes.Count; i++)
			{
				// don't bother if the attribute can grow as it is then controlled by level
				attributes[i].Load(k);
				attributes[i].Recalc(false);
			}
		}

		public void DeleteSaveData(string key)
		{
			PersistableObject.DeleteSavedBloxLovalVars(key, blox);
			GameGlobal.DeleteKey(key + ".lv");

			// delete any saved attribute keys
			string k = key + ".att";
			for (int i = 0; i < attributes.Count; i++)
			{
				attributes[i].DeleteSaveData(k);
			}
		}

		#endregion
		// ============================================================================================================
		#region sys

		private void OnXPChange(object sender, object[] args)
		{	//args[0] = Value, args[1] = Consumable Value 
			float xp = (float)args[0];			
			int prevLevel = _currLevel;
			_currLevel = xpCurve.GetXValue(xp) + 1; // +1 cause plyCurve counts from 0 not 1 (levels are counted form 1)
			if (_currLevel < 1) _currLevel = 1;
			if (_currLevel > maxLevel) _currLevel = maxLevel;
			
			if (_currLevel != prevLevel)
			{
				owner.BroadcastMessage("OnLevelChanged", _currLevel, SendMessageOptions.DontRequireReceiver);
				UpdateLevelLinkedAttribs();
			}
		}

		private void UpdateLevelLinkedAttribs()
		{
			for (int i = 0; i < attributes.Count; i++)
			{
				attributes[i].LevelChanged(_currLevel);
			}
		}

		#endregion
		// ============================================================================================================
		#region attributes

		/// <summary> Get a reference to an attribute of the actor by Id. Return null if failed. </summary>
		public ActorAttribute GetAttribute(UniqueID id)
		{
			if (id.IsEmpty) return null;
			for (int i = 0; i < attributes.Count; i++)
			{
				if (attributes[i].id == id) return attributes[i];
			}
			return null;
		}

		/// <summary> Get a reference to the attribute of the actor by its name, custom def.ident or def.meta data.
		///  Return null if failed. </summary>
		public ActorAttribute GetAttribute(string ident, plyGameObjectIdentifyingType identType)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			if (identType == plyGameObjectIdentifyingType.ident)
			{
				for (int i = 0; i < attributes.Count; i++) if (attributes[i].def.ident.Equals(ident)) return attributes[i];
			}
			if (identType == plyGameObjectIdentifyingType.screenName)
			{
				for (int i = 0; i < attributes.Count; i++) if (attributes[i].def.screenName.Equals(ident)) return attributes[i];
			}
			if (identType == plyGameObjectIdentifyingType.shortName)
			{
				for (int i = 0; i < attributes.Count; i++) if (attributes[i].def.shortName.Equals(ident)) return attributes[i];
			}
			if (identType == plyGameObjectIdentifyingType.meta)
			{
				for (int i = 0; i < attributes.Count; i++) if (attributes[i].def.meta.Equals(ident)) return attributes[i];
			}
			return null;
		}

		/// <summary> Get the Id of an attribute of the actor by its name, custom def.ident or def.meta data.
		///  Return UniqueID.Empty if not found. </summary>
		public UniqueID GetAttributeUniqueId(string ident, plyGameObjectIdentifyingType identType)
		{
			ActorAttribute s = GetAttribute(def.ident, identType);
			if (s != null) return s.id;
			return UniqueID.Empty;
		}

		public int LevelToXP(int level)
		{
			if (XP == null) return 0;
			// 0 indexed so return value from one less
			return xpCurve.GetYValue(level-1);
		}

		#endregion
		// ============================================================================================================
	}
}