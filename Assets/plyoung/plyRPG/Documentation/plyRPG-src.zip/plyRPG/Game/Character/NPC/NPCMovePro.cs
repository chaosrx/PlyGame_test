﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using UnityEngine.AI;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/NPC/Movement/Pro-Move (navmesh)")]
	[RequireComponent(typeof(NavMeshAgent))]
	public class NPCMovePro : NPCMoveBase
	{
		public NavMeshAgent agent;

		[Tooltip("This determines how far from the target position the NPC will accept as valid area to move towards. Making this value bigger can result in an NPC moving towards a target that might be unreachable and thus get 'stuck' on the other side of a wall.")]
		public float positionSampling = 1.0f;

		// ============================================================================================================

		private Transform _tr;
		private bool forceTurning = false;
		private Vector3 targetDirection = Vector3.zero;
		private Vector3 forward = Vector3.zero;
		private float turnSpeed = 0f;
		private bool isCaulculatingPath = false;
		private int navLayer = 0;
		private NavMeshPath path;

		// ============================================================================================================

		protected void Reset()
		{
			Setup();
			if (agent)
			{
				agent.acceleration = 60f;
				agent.speed = 0f;
				agent.angularSpeed = 0f;
				agent.stoppingDistance = 1f;
			}
		}

		protected void Awake()
		{
			path = new NavMeshPath();
		}

		protected void Start()
		{
			Setup();

			if (agent == null)
			{
				Debug.LogError("[NPCMovePro] No NavMeshAgent assigned.");
				enabled = false;
				return;
			}

#if UNITY5
			navLayer = (1 << NavMesh.GetAreaFromName("Walkable"));
#else
			navLayer = (1 << NavMesh.GetNavMeshLayerFromName("Default"));
#endif
			_tr = agent.transform;
		}

		private void Setup()
		{
			if (agent == null) agent = GetComponent<NavMeshAgent>();
		}

		protected void OnEnable()
		{
			if (agent) agent.enabled = true;
		}

		protected void OnDisable()
		{
			if (agent) agent.enabled = false;
		}

		protected void Update()
		{
			if (GameGlobal.Paused)
			{
				if (isCaulculatingPath) Stop();
				return;
			}

			if (null == agent) return;
			if (false == agent.enabled) return;

			if (forceTurning)
			{
				forward = Vector3.RotateTowards(_tr.forward, targetDirection, turnSpeed * Time.deltaTime, 0.0f);
				_tr.rotation = Quaternion.LookRotation(forward);
				//if (Vector3.Dot(_tr.forward, targetDirection) > 0.98f) forceTurning = false;
			}

			// check if a path was calculated and start following it if it is valid
			if (isCaulculatingPath)
			{
				if (path.status == NavMeshPathStatus.PathComplete)
				{
					agent.path = path;
				}
				else
				{	// only complete paths are valid
					isCaulculatingPath = false;
					Stop();
				}
			}

			//if (isMoving)
			//{
			//	if (false == agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
			//	{
			//		Stop();
			//	}
			//}
		}

		// ============================================================================================================

		public override void MoveTo(Vector3 pos, float moveSpeed, float turnSpeed)
		{
			forceTurning = false;
			if (agent == null) return;
			if (agent.enabled)
			{
				// check if target pos will be on the navmesh, else get closest point
				//NavMeshHit n;
				//if (NavMesh.SamplePosition(pos, out n, positionSampling, navLayer))
				//{
				//	// issue move
				//	isMoving = true;
				//	agent.updateRotation = true;
				//	agent.speed = moveSpeed;
				//	agent.angularSpeed = turnSpeed;
				//	agent.destination = n.position;
				//	agent.SetDestination(n.position);
				//}
				//else
				//{
				//	// could not find a point in range, try a raycast in case the Y position is too far off
				//	RaycastHit hit;
				//	if (Physics.Raycast(pos + new Vector3(0f, 999f, 0f), Vector3.down, out hit))
				//	{
				//		if (NavMesh.SamplePosition(hit.point, out n, positionSampling, navLayer))
				//		{
				//			// issue move
				//			isMoving = true;
				//			agent.updateRotation = true;
				//			agent.speed = moveSpeed;
				//			agent.angularSpeed = turnSpeed;
				//			agent.destination = n.position;
				//			agent.SetDestination(n.position);
				//			return;
				//		}
				//	}
				//}

				NavMeshHit n;
				if (false == NavMesh.SamplePosition(pos, out n, positionSampling, navLayer))
				{
					RaycastHit hit;
					if (false == Physics.Raycast(pos + new Vector3(0f, 999f, 0f), Vector3.down, out hit))
					{
						return;
					}

					if (false == NavMesh.SamplePosition(hit.point, out n, positionSampling, navLayer))
					{
						return;
					}
				}

				// start calculating a path
				isCaulculatingPath = agent.CalculatePath(n.position, path);
				agent.updateRotation = true;
				agent.speed = moveSpeed;
				agent.angularSpeed = turnSpeed;

			}
		}

		public override void FaceDirection(Vector3 direction, float turnSpeed)
		{
			this.turnSpeed = turnSpeed / 100f; // this speed might be set quite high to work with NavAgent, so div it
			targetDirection = direction;
			forceTurning = true;
			if (agent != null) agent.updateRotation = false;
		}

		public override void Stop()
		{
			isCaulculatingPath = false;
			forceTurning = false;
			if (agent == null) return;
			if (agent.enabled)
			{
				agent.updateRotation = true;
				agent.Stop();
				agent.ResetPath();
			}
		}

		public override Vector3 Velocity()
		{
			//if (!isMoving) return Vector3.zero;
			return agent.velocity;
		}

		public override Vector3 DesiredVelocity()
		{
			//if (!isMoving) return Vector3.zero;
			return agent.desiredVelocity;
		}

		public override void UpdateVelocity(Vector3 v)
		{
			agent.velocity = v;
		}

		public override bool Grounded()
		{
			return true;
		}

		public override bool IsMovingOrPathing()
		{
			//return isMoving;
			if (agent == null) return false;
			if (!agent.enabled) return false;
			return (agent.pathPending || agent.remainingDistance > agent.stoppingDistance);
		}

		public override bool InControlledTurn()
		{
			return forceTurning;
		}

		// ============================================================================================================
	}
}