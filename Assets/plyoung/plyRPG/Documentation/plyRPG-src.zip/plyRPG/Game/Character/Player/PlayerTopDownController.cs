﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/Player/Top-Down Controller")]
	[RequireComponent(typeof(CharacterController))]
	public class PlayerTopDownController : PlayerBaseController
	{
		public CharacterController characterController;

		public bool allowButtonMove = true;		
		public bool allowClickMove = true;
		public bool allowClickHoldMove = true;
		public float clickMoveMin = 1f;
		public float clickDetect = 0.25f;
		public bool alwaysFaceMouse = false;

		public bool allowJump = false;
		public float jumpSpeed = 12f;
		public float gravity = 30f;

		public GameObject clickMarkerFab;

		public bool pf_Support = false;
		public float pf_CheckHeight = 1.0f;
		public float pf_CheckDist = 1.1f;

		// ============================================================================================================

		private Transform camTr;

		private const float inputThreshold = 0.01f;
		private float hMoved = 0f;
		private float vMoved = 0f;
		private Vector3 movement = Vector3.zero;
		private Vector3 moveDirection = Vector3.zero;
		private Vector3 gravityVec = Vector3.zero;
		private bool startedJump = false;
		private float jumpWaitTimer = 0f;
		private const float nextJumpTimeout = 0.5f; // helper to prevent weird bunny hopping jumping that fails the animation system
		private float nextJumpTimer = 0f;

		private Vector3 targetFacing = Vector3.zero;
		private Vector3 forward = Vector3.zero;
		private Vector3 targetClickPosition;
		private Vector3 lastMovement = Vector3.zero;
		private bool clickMoving = false;
		private bool forcedTurning = false;
		private bool forcedTurningCompleting = false;
		private float forcedTurnTimeout = 0f;
		private bool wasGrounded = false;
		private int clickInput = 0; // 0:none, 1:held, 2:down, 3:up
		private GameObject clickMarker;
		private Vector3 prevMousePos = Vector3.zero;
		private Plane mouseRayPlane = new Plane(new Vector3(0, 1f, 0), Vector3.zero); // used when alwaysFaceMouse = true

		private int Key_FBMove = -1;
		private int Key_LRMove = -1;
		private int Key_Jump = -1;
		private int Key_GamepadLRMove = -1;
		private int Key_GamepadFBMove = -1;
		private int Key_ClickMove = -1;

		// ============================================================================================================

		new protected void Reset()
		{
			base.Reset();
			moveSpeed = 7.0f;
			turnSpeed = 10f;
			mouseSelDistance = 100f;
			mouseSelAngle = 360;
			buttonSelDistance = 20f;
			buttonSelAngle = 360;

			if (characterController == null) characterController = GetComponent<CharacterController>();
		}

		protected override void Awake()
		{
			base.Awake();			
			if (characterController == null) characterController = GetComponent<CharacterController>();
			if (characterController == null)
			{
				Debug.LogError("[Top-Down Controller] No CharacterController assigned. Character will now be disabled.");
				enabled = false;
				return;
			}

			_tr = characterController.transform;
		}

		protected override void Start()
		{
			base.Start();

			if (clickMarkerFab != null)
			{
				clickMarker = (GameObject)Instantiate(clickMarkerFab);
				clickMarker.name = "Player Click-Marker";
				clickMarker.SetActive(false);
			}

			// Cache the input idx
			Key_ClickMove = plyInput.GetInputIdx("Player Top-Down/ClickMove");
			Key_LRMove = plyInput.GetInputIdx("Player Top-Down/ForwardBack Move");
			Key_FBMove = plyInput.GetInputIdx("Player Top-Down/LeftRight Move");
			Key_Jump = plyInput.GetInputIdx("Player Top-Down/Jump");
			Key_GamepadFBMove = plyInput.GetInputIdx("Player Top-Down/Gamepad ForwardBack Move");
			Key_GamepadLRMove = plyInput.GetInputIdx("Player Top-Down/Gamepad LeftRight Move");

		}

		new protected void Update()
		{
			base.Update();

			if (camTr == null)
			{
				if (Player.Camera != null)
				{
					camTr = Player.Camera.transform;
				}
				else return;
			}

			if (GameGlobal.Paused) return;
			UpdateMovement();
		}

		private void UpdateMovement()
		{
			if (MovementControlAllowed())
			{
				if (allowButtonMove)
				{
					hMoved = plyInput.GetAxis(Key_FBMove);
					vMoved = plyInput.GetAxis(Key_LRMove);
					if (plyInput.IsActive(Key_GamepadLRMove) && hMoved == 0.0f) hMoved = plyInput.GetAxis(Key_GamepadLRMove);
					if (plyInput.IsActive(Key_GamepadFBMove) && vMoved == 0.0f) vMoved = plyInput.GetAxis(Key_GamepadFBMove);

					movement = (vMoved * camTr.forward) + (hMoved * camTr.right);
					movement.y = 0f;

					if (movement != Vector3.zero)
					{
						StopInteract();
						clickMoving = false;
						actor.ReceivedMoveCommand();
						targetFacing = movement.normalized;
						forcedTurning = false;
					}
				}

				if (allowClickMove)
				{
					// 0:none, 1:held, 2:went-down
					if (allowClickHoldMove) clickInput = plyInput.GetButtonDown(Key_ClickMove) ? 2 : plyInput.GetButton(Key_ClickMove) ? 1 : 0;
					else clickInput = plyInput.GetButtonDown(Key_ClickMove) ? 2 : 0;
					if (clickInput != 0)
					{
						Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
						RaycastHit hit;
						if (Physics.Raycast(ray, out hit, Mathf.Infinity, floorClickMask))
						{
							// first thing clicked must be a floor layer, else ignore the click
							// I use floorClickMask so that clicks can be set to pass only through certain things
							// for example, it should pass through Player but not NPCs
							if (hit.transform.gameObject.layer == GameGlobal.LayerMapping.Floor)
							{
								StopInteract();
								targetClickPosition = hit.point;
								forcedTurning = false;

								// if mouse went down, check if clicked far enough from character, else set click pos to zero
								// if holding mouse and click pos is too close to character, use the previously known movement
								if (clickInput == 2)
								{
									if ((targetClickPosition - _tr.position).magnitude < clickMoveMin)
									{
										lastMovement = Vector3.zero;
									}
									else
									{
										clickMoving = true;
										movement = (targetClickPosition - _tr.position);
										movement.y = 0f;
										targetFacing = movement.normalized;
										lastMovement = movement;

										if (clickMarker != null)
										{
											clickMarker.transform.position = targetClickPosition;
											clickMarker.SetActive(false); // just in case it was still active so that things that triggers in OnEnable will work
											clickMarker.SetActive(true);
										}

										actor.ReceivedMoveCommand();
									}
								}
								else
								{
									if ((targetClickPosition - _tr.position).magnitude < clickMoveMin)
									{
										//movement = lastMovement;
										//targetFacing = movement.normalized;									
										lastMovement = Vector3.zero;
									}
									else
									{
										clickMoving = true;
										movement = (targetClickPosition - _tr.position);
										movement.y = 0f;
										targetFacing = movement.normalized;
										lastMovement = movement;
										actor.ReceivedMoveCommand();
									}
								}
							}
						}
					}
				}

				if (clickMoving)
				{
					movement = (targetClickPosition - _tr.position);
					movement.y = 0f;
				}
			}

			if (allowJump)
			{
				if (!startedJump)
				{
					if (nextJumpTimer > 0.0f) nextJumpTimer -= Time.deltaTime;
					if (plyInput.GetButtonDown(Key_Jump) && nextJumpTimer <= 0.0f && allowButtonMove && wasGrounded && MovementControlAllowed())
					{
						StopInteract();
						forcedTurning = false;
						startedJump = true;
						jumpWaitTimer = 0f;
						moveDirection = Vector3.zero;
						if (onJump != null) jumpWaitTimer = (float)onJump(this, null);
						actor.ReceivedMoveCommand();
					}

					else
					{
						if (movement.magnitude > inputThreshold) moveDirection = (movement.normalized * moveSpeed);
						else moveDirection = Vector3.zero;
					}
				}

				else
				{
					jumpWaitTimer -= Time.deltaTime;
					if (jumpWaitTimer <= 0.0f)
					{
						startedJump = false;
						nextJumpTimer = nextJumpTimeout;
						gravityVec.y = jumpSpeed;
					}
				}
			}
			else
			{
				if (movement.magnitude > inputThreshold) moveDirection = (movement.normalized * moveSpeed);
				else moveDirection = Vector3.zero;
			}

			if (forcedTurning)
			{				
				forward = Vector3.Lerp(_tr.forward, targetFacing, Time.deltaTime * turnSpeed);
				if (forward != Vector3.zero) _tr.rotation = Quaternion.LookRotation(forward, Vector3.up);

				if (forcedTurningCompleting)
				{
					forcedTurnTimeout -= Time.deltaTime;
					if (forcedTurnTimeout <= 0.0f)
					{
						forcedTurning = false;
						if (movement != Vector3.zero) targetFacing = movement.normalized;
					}
				}

				else
				{
					// check if facing in relatively correct direction and turn this off
					if (Vector3.Dot(_tr.forward, targetFacing) > 0.98f)
					{
						// I can't allow immediate return to facing the direction the character is moving
						// in as it will look stupid with a turn sped of 5 or more. So lets run backward
						// for a while before returning to facing correctly
						forcedTurningCompleting = true;
					}
				}
			}
			
			if (!forcedTurning)
			{	// already applied above if was in fixed turning mode
				if (alwaysFaceMouse) 
				{
					//if (prevMousePos != Input.mousePosition)
					{
						prevMousePos = Input.mousePosition;
						Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
						float rayDistance;
						if (mouseRayPlane.Raycast(ray, out rayDistance))
						{
							Vector3 p = ray.GetPoint(rayDistance); p.y = _tr.position.y;
							targetFacing = (p - _tr.position).normalized;
						}
					}
				}
				else targetFacing = moveDirection;
				forward = Vector3.Lerp(_tr.forward, targetFacing, Time.deltaTime * turnSpeed);
				if (forward != Vector3.zero) _tr.rotation = Quaternion.LookRotation(forward, Vector3.up);
			}

			if (pf_Support && !startedJump)
			// check if inside floor and force out of it
			{
				if (gravityVec.y <= 0.0f)
				{
					RaycastHit hitinfo;
					if (Physics.Raycast(_tr.position + (Vector3.up * pf_CheckHeight), -Vector3.up, out hitinfo, pf_CheckDist, 1 << GameGlobal.LayerMapping.Floor))
					{
						//moveDirection.y = 0f;
						_tr.position = new Vector3(_tr.position.x, hitinfo.point.y, _tr.position.z);
						wasGrounded = true;
						gravityVec.y = 0.0f;
					}
				}
			}

			gravityVec.y -= gravity * Time.deltaTime;
			if ((characterController.Move((moveDirection + gravityVec) * Time.deltaTime) & CollisionFlags.Below) != 0)
			{
				wasGrounded = true;
				gravityVec = Vector3.zero;
			}
			else
			{
				wasGrounded = false;
			}
		
			if (clickMoving)
			{
				targetClickPosition.y = _tr.position.y;
				if ((targetClickPosition - _tr.position).magnitude < 0.2f)
				{
					movement = Vector3.zero;
					clickMoving = false;
				}
			}
		}

		// ============================================================================================================

		public override bool Grounded()
		{
			return wasGrounded;
		}

		public override Vector3 Velocity()
		{
			return characterController.velocity;
		}

		public override bool RequestFaceDirection(Vector3 direction, float delayAfter)
		{
			//Debug.Log("RequestFaceDirection");
			forcedTurning = true;
			forcedTurningCompleting = false;
			targetFacing = direction;
			targetFacing.y = 0f;
			forcedTurnTimeout = delayAfter;
			return true;
		}

		public override bool RequestMoveTo(Vector3 position, bool useFasterMovement)
		{
			//Debug.Log("RequestMoveTo: " + _tr.position + "  => " + position);
			clickMoving = true;
			targetClickPosition = position;
			movement = (targetClickPosition - _tr.position);
			movement.y = 0f;
			return true;
		}

		public override void Stop()
		{
			movement = Vector3.zero;
			clickMoving = false;
			
			// do not disable forced turning here else it will mess up things when Stop is called
			// by actor when the Skill should be played - causing turned timeout to fail
			//forcedTurning = false;
		}

		public override Vector3 Movement()
		{
			return moveDirection;
		}

		public override void OnDeath()
		{
			Stop();
			base.OnDeath();
			if (characterController) characterController.enabled = false;
		}

		public override void OnRestore()
		{
			base.OnRestore();
			if (characterController) characterController.enabled = true;
		}

		// ============================================================================================================
	}
}