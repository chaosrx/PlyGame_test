﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> All plyGame characters must have the Actor component. It contains the definitions and
	///  general info on the character. </summary>
	[AddComponentMenu("plyGame/Character/Actor/Actor")]
	public class Actor : MonoBehaviour, IPersistable
	{
		#region Properties

		public bool persistenceOn = true;
		public bool persistActorData = true;
		public bool persistClass = false;
		public bool persistKnowSkills = false;
		public bool persistFactions = false;

		public UniqueID id = new UniqueID();			//!< Unique Id of the Actor. Same for all instances of same Actor/ Character prefab
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data
		public UniqueID classId = new UniqueID();	//!< Id of the actor class this Actor uses
		public int startLevel = 1;					//!< Level to initialize this Actor to

		public bool overwriteStatus = false; //!< uses statusTowardsPlayer if true
		public StatusTowardsOther statusTowardsPlayer = StatusTowardsOther.Friendly; //!< Status of the Actor (normally NPC) towards the player

		public bool essential = false;  //!< set to true to hint that this actor should not be killed

		public List<UniqueID> startFactions = new List<UniqueID>(0);	//!< Ids of the faction this Actor is associated with at start
		public List<UniqueID> startSkills = new List<UniqueID>(0);		//!< Ids of the Skills this Actor starts with

		public bool autoDetectDeath = true;								//!< Should Actor auto handle HP reaching 0?
		public ObjectDestroyerHandler objectDestroyer = new ObjectDestroyerHandler();	//!< Used to perform object destroy when Kill() is called
		public List<Component> disableOnDeath = new List<Component>(0); //!< What additional components should be disabled? Actor already disable various components related to characters by default.

		#endregion
		// ============================================================================================================
		#region Runtime

		/// <summary> Instance of the actor class used by this Actor </summary>
		public ActorClass actorClass { get; private set; }

		/// <summary> Cached reference to Bag so it is quicker to get to without having to 
		/// lookup the Bag component teach time. Note, can be null. </summary>
		public ItemBag bag { get; private set; }

		/// <summary> Reference to the plyGame character controller of this actor/ character </summary>
		public CharacterControllerBase character
		{
			get
			{
				if (_character == null) _character = GetComponent<CharacterControllerBase>();
				return _character;
			}
		}
		private CharacterControllerBase _character = null;

		/// <summary> List of skills (instantiated) this Actor knows. </summary>
		public List<Skill> knownSkills { get; private set; }

		/// <summary> The Factions that this Actor is associated with. </summary>
		public List<ActorFaction> factions { get; private set; }

		public Skill executingSkill { get; private set; }			// The skill currently being executed
		public Skill queuedSkill { get; private set; }				// The skill queued to be executed when possible
		private Targetable queuedSkill_SelectedObject = null;		// Object selected for the queued skill
		private Vector3 queuedSkill_TargetPosition = Vector3.zero;  // Target position for the queued skill
		private Vector3 queuedSkill_MousePosition = Vector3.zero;	// Target mouse position for the queued skill
		private Vector3 targetDirectionForSkill = Vector3.zero;		// Direction to to turn to before skill can be used
		private Vector3 targetPositionForSkill = Vector3.zero;		// Position to reach before skill can be used
		private int maxSkillSaveHelper = 0;

		private bool inDeathLoop = false; // true while character is doing the death loop
		private int waitFrame = 2;

		private bool _isPlayer = false;
		public bool isPlayer { get { return _isPlayer; } set { _isPlayer = value; } }

		#endregion
		// ============================================================================================================
		#region Start/ Init

		protected void Reset()
		{
			id = UniqueID.Create(id);

			// check if the persistence object is present and add if not
			persistenceOn = true;
			PersistableObject p = gameObject.GetComponent<PersistableObject>();
			if (p == null) p = gameObject.AddComponent<PersistableObject>();

			// check if Player or NPC
			CharacterControllerBase chara = gameObject.GetComponent<CharacterControllerBase>();
			if (chara != null)
			{
				if (chara.IsPlayer())
				{
					objectDestroyer.method = ObjectDestroyerHandler.DestroyMethod.DoNothing;
					persistActorData = true;
					persistClass = true;
					persistKnowSkills = true;
					p.persistDestroyedState = false;
					p.persistActiveState = false;
				}
				else
				{
					persistActorData = true;
					persistClass = false;
					persistKnowSkills = false;
				}
			}
		}

		protected void Awake()
		{
			GameGlobal.Create(); // make sure global is available
			waitFrame = 2;

			// init some lists that might need to be not-null for 
			// code that access them too early
			factions = new List<ActorFaction>(0);
			knownSkills = new List<Skill>(0);

			if (persistenceOn)
			{	// make sure a PersistableObject is present
				PersistableObject p = GetComponent<PersistableObject>();
				if (p == null)
				{
					persistenceOn = false;
					Debug.LogError("PersistableObject not found on [" + gameObject.name + "]. Persistence turned off.");
				}
			}

			// cache reference to item bag if bag present
			bag = GetComponent<ItemBag>();
		}

		protected IEnumerator Start()
		{
			ActorClassesAsset.Instance.UpdateCacheIfNeeded();
			if (classId.IsEmpty && ActorClassesAsset.Instance.classes.Count > 0)
			{
				classId = ActorClassesAsset.Instance.classes[0].id;
				Debug.LogWarning("[Actor: " + def.screenName + "] The Actor Class was not set. The first defined Actor Class, " + ActorClassesAsset.Instance.classes[0].def.screenName + ", will now be selected for this Actor: " + def.screenName + "::" + name);
			}

			_character = GetComponent<CharacterControllerBase>();
			if (_character == null)
			{
				Debug.LogWarning("[Actor: " + def.screenName + "] Could not find the Character component. The Actor object will now be deactivated: " + def.screenName);
				gameObject.SetActive(false);
			}
			else
			{
				if (false == persistenceOn || false == persistClass)
				{	// do not create the Class yet if persistence is used since the class might have changed
					// during run-time and save as another class to use. in this case I will create the
					// class via the Load() function
					CreateActorClass();
				}

				// create the skills
				knownSkills = new List<Skill>(0);
				for (int i = 0; i < startSkills.Count; i++)
				{
					Skill s = SkillsAsset.Instance.GetDefinition(startSkills[i]);
					if (s == null)
					{
						Debug.LogWarning("There are undefined skill in your character's Start Skills list: " + name);
					}
					else 
					{
						LearnSkill(s, true); 
					}
				}

				// skip one frame
				yield return null;

				// init factions. this call needs to be delayed since FactionManager
				// can only init the factions during Start()
				for (int i = 0; i < startFactions.Count; i++)
				{
					JoinFaction(startFactions[i], true);
				}
			}
		}

		private void CreateActorClass()
		{
			GameObject classFab = ActorClassesAsset.Instance.GetPrefab(classId);
			if (classFab == null)
			{
				Debug.LogWarning("[Actor: " + def.screenName + "::" + name + "] The Actor Class definition could not be found. Attempting to use first defined class.");
				classFab = ActorClassesAsset.Instance.classFabs.Count > 0 ? ActorClassesAsset.Instance.classFabs[0] : null;
			}

			if (classFab != null)
			{
				GameObject go = (GameObject)Instantiate(classFab);
				actorClass = go.GetComponent<ActorClass>();
				go.transform.parent = transform;
				go.transform.localPosition = Vector3.zero;
				go.transform.localRotation = Quaternion.identity;
				go.name = "ActorClass: " + actorClass.def.screenName;
				actorClass.Init(this, startLevel);
			}
			else
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The Actor Class definition could not be found. The Character object will now be disabled.");
				gameObject.SetActive(false);
				return;
			}

			if (actorClass == null)
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] has no Actor Class set. The Character object will now be disabled as it will throw error and not work correctly until the Actor Class is set in the Actor Inspector.");
				gameObject.SetActive(false);
				return;
			}
		}

		#endregion
		// ============================================================================================================
		#region Loading and Saving

		public void Save(string key)
		{
			if (!persistenceOn) return;
			key = key + ".act";

			// *** save basics
			if (persistActorData)
			{
				GameGlobal.SetIntKey(key + ".stp", overwriteStatus ? (int)statusTowardsPlayer : -1);
				GameGlobal.SetBoolKey(key + ".ess", essential);
			}

			// *** save class
			if (persistClass)
			{
				GameGlobal.SetStringKey(key + ".class", actorClass.id.ToString());
				actorClass.Save(key);
			}

			// *** save known skills
			if (persistKnowSkills)
			{
				DeleteSkillVarKeys(key + ".skills");
				maxSkillSaveHelper = knownSkills.Count;
				if (knownSkills.Count > 0)
				{
					string data = "";
					for (int i = 0; i < knownSkills.Count; i++)
					{
						data += knownSkills[i].id.ToString() + (char)31;

						// save skill variables
						if (knownSkills[i].blox != null)
						{
							string skillKey = key + ".skill." + i.ToString();
							string varData = knownSkills[i].blox.EncodeLocalVariables(false);
							if (!string.IsNullOrEmpty(varData)) GameGlobal.SetStringKey(skillKey, varData);
						}
					}
					GameGlobal.SetStringKey(key + ".skills", data);
				}
				else
				{	// need to actually save the key as the presence of the key indicates that no skills should be known
					// in case there where starting skills however unlikely it is that character would unlearn all start skills
					GameGlobal.SetStringKey(key + ".skills", "0");
				}
			}

			// *** save factions
			if (persistFactions)
			{
				if (factions.Count > 0)
				{
					string data = "";
					for (int i = 0; i < factions.Count; i++) data += factions[i].id.ToString() + (char)31;
					GameGlobal.SetStringKey(key + ".fac", data);
				}
				else
				{
					GameGlobal.SetStringKey(key + ".fac", "0");
				}
			}
		}

		public void Load(string key)
		{
			if (!persistenceOn) return;
			key = key + ".act";

			// *** load basics
			if (persistActorData)
			{
				int st = GameGlobal.GetIntKey(key + ".stp", overwriteStatus ? (int)statusTowardsPlayer : -1);
				if (st == -1) overwriteStatus = false;
				else statusTowardsPlayer = (StatusTowardsOther)st;
				essential = GameGlobal.GetBoolKey(key + ".ess", essential);
			}

			// *** load class
			if (persistClass)
			{
				string classId_s = GameGlobal.GetStringKey(key + ".class", null);
				if (classId_s != null)
				{	// find the class id in the defined classes before accepting it as valid
					UniqueID cid = new UniqueID(classId_s);
					ActorClass c = ActorClassesAsset.Instance.GetDefinition(cid);
					if (c != null) classId = c.id;
				}
				CreateActorClass();
				actorClass.Load(key);
			}

			// *** load known skills
			if (persistKnowSkills)
			{
				// if the key is set then it means data was saved before about the skills
				// if key is not set then simply leave skills alone
				string data = GameGlobal.GetStringKey(key + ".skills", null);
				//Debug.Log(name + " data = " + data);
				if (data != null)
				{
					if (data.Length > 1)
					{
						string[] skillIds_s = data.Split((char)31);
						List<UniqueID> skillIds = new List<UniqueID>();
						for (int i = 0; i < skillIds_s.Length; i++)
						{
							if (string.IsNullOrEmpty(skillIds_s[i])) continue;
							skillIds.Add(new UniqueID(skillIds_s[i]));
							//Debug.Log("skillIds[" + i + "] = " + skillIds[i].ToString() + " from " + skillIds_s[i]);
						}

						// first check if any known skill not in this list and if so, remove it
						if (knownSkills.Count > 0)
						{
							for (int i = knownSkills.Count - 1; i >= 0; i--)
							{
								bool found = false;
								for (int j = 0; j < skillIds.Count; j++)
								{
									if (knownSkills[i].id == skillIds[j]) { found = true; break; }
								}
								if (false == found)
								{
									Destroy(knownSkills[i].gameObject);
									knownSkills.RemoveAt(i);
								}
							}
						}

						// now learn skills
						for (int i = 0; i < skillIds.Count; i++)
						{
							Skill sk = LearnSkill(skillIds[i], true);
							if (sk != null)
							{	// restore skill variables
								if (sk.blox != null)
								{
									string skillKey = key + ".skill." + i.ToString();
									string varData = GameGlobal.GetStringKey(skillKey, null);
									sk.blox.DecodeLocalVariables(varData);
								}								
							}
						}
					}
					else
					{
						if (data == "0")
						{
							// only unlearn if the data is set specifically to "0"
							for (int i = 0; i < knownSkills.Count; i++) Destroy(knownSkills[i].gameObject);
							knownSkills = new List<Skill>(0);
						}
					}
				}
			} 
			if (maxSkillSaveHelper < knownSkills.Count) maxSkillSaveHelper = knownSkills.Count;

			// *** restore factions
			if (persistFactions)
			{
				string data = GameGlobal.GetStringKey(key + ".fac", null);
				if (data != null)
				{
					if (data.Length > 1)
					{
						string[] facIds_s = data.Split((char)31);
						UniqueID[] facIds = new UniqueID[facIds_s.Length];
						for (int i = 0; i < facIds_s.Length; i++) facIds[i] = new UniqueID(facIds_s[i]);

						// first check if in faction not in saved list and leave it
						if (factions.Count > 0)
						{
							for (int i = factions.Count - 1; i >= 0; i--)
							{
								bool found = false;
								for (int j = 0; j < facIds.Length; j++)
								{
									if (factions[i].id == facIds[j]) { found = true; break; }
								}
								if (false == found) factions.RemoveAt(i);
							}
						}

						// now join factions
						for (int i = 0; i < facIds.Length; i++)
						{
							JoinFaction(facIds[i], true);
						}
					}
					else
					{
						if (data == "0")
						{
							// only clear all factions if data = "0"
							factions = new List<ActorFaction>(0);
						}
					}
				}

			} // persistFactions

		}

		public void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			key = key + ".act";

			// delete basics
			if (persistActorData)
			{
				GameGlobal.DeleteKey(key + ".stp");
				GameGlobal.DeleteKey(key + ".ess");
			}

			// delete class
			if (persistClass)
			{
				GameGlobal.DeleteKey(key + ".class");
				actorClass.DeleteSaveData(key);
			}

			// delete known skills
			if (persistKnowSkills)
			{
				GameGlobal.DeleteKey(key + ".skills");
				DeleteSkillVarKeys(key + ".skills");
			}

			// delete factions
			if (persistFactions)
			{
				GameGlobal.DeleteKey(key + ".fac");
			}
		}

		public void DisablePersistence()
		{
			persistenceOn = false;
		}

		private void DeleteSkillVarKeys(string key)
		{
			for (int i = 0; i < maxSkillSaveHelper; i++)
			{
				string bagKey = key + ".skill." + i.ToString();
				GameGlobal.DeleteKey(bagKey);
			}
		}

		#endregion
		// ============================================================================================================
		#region Update

		protected void Update()
		{
			if (waitFrame > 0)
			{
				waitFrame--;
				if (waitFrame <= 0)
				{
					// do stuff here that needs to wait one frame
					gameObject.BroadcastMessage("OnActorReady", SendMessageOptions.DontRequireReceiver);
				}
			}

			if (inDeathLoop)
			{
				objectDestroyer.Update();
			}
		}

		protected void LateUpdate()
		{
			if (actorClass == null) return; // can be null during 1st frame
			if (inDeathLoop || false == character.controlEnabled) return;

			if (autoDetectDeath && actorClass.HP != null)
			{
				if (actorClass.HP.ConsumableValue <= 0)
				{
					Kill();
					return;
				}
			}

			if (GameGlobal.Paused) return;

			if (executingSkill != null)
			{
				if (false == executingSkill.IsExecuting())
				{
					character.hint_DoNotMove = false;
					executingSkill = null;
				}
			}

			else
			{
				if (queuedSkill != null)
				{
					if (queuedSkill_SelectedObject != null)
					{
						queuedSkill_TargetPosition = queuedSkill_SelectedObject.transform.position;
					}

					if (CanPerformQueuedSkill())
					{
						if (false == queuedSkill.mayPerformWhileMove)
						{
							character.hint_DoNotMove = true;
							character.Stop();
						}

						executingSkill = queuedSkill;
						queuedSkill = null;
						executingSkill.Execute(queuedSkill_SelectedObject, queuedSkill_TargetPosition, queuedSkill_MousePosition);

						if (character.IsPlayer())
						{
							if (executingSkill.targetLocation == Skill.TargetLocation.MouseOver || executingSkill.targetLocation == Skill.TargetLocation.CrosshairOver)
							{
								character.SelectTarget(queuedSkill_SelectedObject);
							}
						}
					}
				}
			}

		}

		#endregion
		// ============================================================================================================
		#region Skills

		/// <summary> Add Skill to list of known Skills. Return reference to the new Skill object.
		/// Returns null on error. </summary>
		public virtual Skill LearnSkill(UniqueID skillId, bool suppressLog)
		{
			if (skillId == null)
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The skill id is null.");
				return null;
			}
			if (skillId.IsEmpty)
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The skill id is empty.");
				return null;
			}

			Skill s = GetKnownSkill(skillId);
			if (s != null)
			{
				if (!suppressLog) Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The Actor already knows this skill.");
				return s;
			}

			GameObject skillfab = SkillsAsset.Instance.GetPrefab(skillId);
			if (skillfab != null)
			{
				GameObject go = (GameObject)Instantiate(skillfab);
				Skill sk = go.GetComponent<Skill>();
				go.transform.parent = transform;
				go.transform.localPosition = Vector3.zero;
				go.transform.localRotation = Quaternion.identity;
				go.name = "Skill: " + sk.def.screenName;
				sk.owner = this;
				knownSkills.Add(sk);
				if (maxSkillSaveHelper < knownSkills.Count) maxSkillSaveHelper = knownSkills.Count;
				return sk;
			}
			else
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The skill definition could not be found.");
			}

			return null;
		}

		/// <summary> Add Skill to list of known Skills. Return reference to the new Skill object, 
		/// Returns null on error. </summary>
		public virtual Skill LearnSkill(Skill skill, bool suppressLog)
		{
			if (skill == null)
			{
				Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The skill id is null.");
				return null;
			}

			Skill sk = GetKnownSkill(skill);
			if (sk != null)
			{
				if (!suppressLog) Debug.LogError("[Actor: " + def.screenName + "::" + name + "] The Actor already knows this skill.");
				return sk;
			}

			GameObject go = (GameObject)Instantiate(skill.gameObject);
			sk = go.GetComponent<Skill>();
			go.transform.parent = transform;
			go.transform.localPosition = Vector3.zero;
			go.transform.localRotation = Quaternion.identity;
			go.name = "Skill: " + sk.def.screenName;
			sk.owner = this;
			knownSkills.Add(sk);
			if (maxSkillSaveHelper < knownSkills.Count) maxSkillSaveHelper = knownSkills.Count;
			return sk;
		}

		/// <summary> Remove a skill from the list of skills the actor knows. Will silently fail if error. </summary>
		public virtual void UnlearnSkill(UniqueID skillId)
		{
			if (skillId == null) return;
			if (skillId.IsEmpty) return;
			int idx = -1;
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skillId) { idx = i; break; }
			}
			if (idx >= 0)
			{
				Destroy(knownSkills[idx].gameObject);
				knownSkills.RemoveAt(idx);
			}
		}

		/// <summary> Remove a skill from the list of skills the actor knows. Will silently fail if error. </summary>
		public virtual void UnlearnSkill(Skill skill)
		{
			if (skill == null) return;
			int idx = -1;
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skill.id) { idx = i; break; }
			}
			if (idx >= 0)
			{
				Destroy(knownSkills[idx].gameObject);
				knownSkills.RemoveAt(idx);
			}
		}

		/// <summary> Return True if Skill is in list of known skills. </summary>
		public virtual bool KnowSkill(UniqueID skillId)
		{
			if (skillId == null) return false;
			if (skillId.IsEmpty) return false;
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skillId) return true;
			}
			return false;
		}

		/// <summary> Return True if Skill is in list of known skills. </summary>
		public virtual bool KnowSkill(Skill skill)
		{
			if (skill == null) return false;
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skill.id) return true;
			}
			return false;
		}

		/// <summary> Return the known skill else null if not known. </summary>
		public virtual Skill GetKnownSkill(UniqueID skillId)
		{
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skillId) return knownSkills[i];
			}
			return null;
		}

		/// <summary> Return the known skill else null if not known. </summary>
		public virtual Skill GetKnownSkill(Skill skill)
		{
			for (int i = 0; i < knownSkills.Count; i++)
			{
				if (knownSkills[i].id == skill.id) return knownSkills[i];
			}
			return null;
		}

		/// <summary> Queue Skill to be used as soon as possible. Return false if the Skill is not known.
		///  Could still fail to execute the skill if the Actor unlearn it before it is executed. </summary>
		public virtual bool QueueSkillForExecution(Skill skill, bool autoLearn)
		{
			Skill s = GetKnownSkill(skill);
			if (s == null && autoLearn) s = LearnSkill(skill, true);
			if (s != null)
			{
				QueueSkillForExecution(s);
				return true;
			}
			return false;
		}

		/// <summary> Queue Skill to be used as soon as possible. Return false if the Skill is not known.
		///  Could still fail to execute the skill if the Actor unlearn it before it is executed. </summary>
		public virtual bool QueueSkillForExecution(UniqueID skillId, bool autoLearn)
		{
			Skill s = GetKnownSkill(skillId);
			if (s == null && autoLearn) s = LearnSkill(skillId, true);
			if (s != null)
			{
				QueueSkillForExecution(s);
				return true;
			}
			return false;
		}

		public virtual void QueueSkillForExecution(Skill skill)
		{
			QueueSkillForExecution(skill, false, null, Vector3.zero, Vector3.zero);
		}

		/// <summary> Queue Skill to be used as soon as possible. Does not check if the Actor knows the
		///  skill so be sure to check before you queue it. Could still fail to execute the skill if it the
		///  Actor unlearn it before it is executed. </summary>
		public virtual void QueueSkillForExecution(Skill skill, bool ifNoOtherQueued, Targetable forceSelectedObject, Vector3 forceSelectedPosition, Vector3 forceMousePosition)
		{
			if (skill == null) return;
			if (ifNoOtherQueued && queuedSkill != null) return;

			if (skill.canBeQueued == false)
			{	// first check if can be placed in queue
				if (executingSkill != null)
				{
					if (executingSkill.IsExecuting())
					{
						ClearQueuedSkill(); // just in case something was queued already
						return;
					}
				}

				// can't queue the skill if it is cooling down and canBeQueued = false
				if (skill.CoolingDown()) return;

				// can't be queued if character must stand still to execute but is currently moving
				if (skill.forceStop == false && skill.mayPerformWhileMove == false)
				{
					if (character.Velocity().magnitude >= 0.01f) return;
				}
			}

			if (false == ifNoOtherQueued)
			{
				if (skill.targetLocation == Skill.TargetLocation.SelectedDirection ||
					skill.targetLocation == Skill.TargetLocation.AtSelected)
				{	// need to make sure the selected is a valid target before queuing skill
					if (false == skill.IsValidTargetable(character.selectedTarget, character._tr, character._tr.position, skill.obstacbleCheckHeight, skill.obstacleCheckMask))
					{
						return;
					}
				}

				if (skill.targetLocation == Skill.TargetLocation.MouseOver)
				{   // mouse over will only work if over valid target
					queuedSkill_SelectedObject = skill.FindValidTargetAt(Player.Camera.ScreenPointToRay(Input.mousePosition));
					if (queuedSkill_SelectedObject == null) return;
				}

				else if (skill.targetLocation == Skill.TargetLocation.CrosshairOver)
				{
					Vector3 pos = new Vector3(Screen.width / 2f, Screen.height / 2f, 0f) + skill.crosshairOffset;
					queuedSkill_SelectedObject = skill.FindValidTargetAt(Player.Camera.ScreenPointToRay(pos));
					if (queuedSkill_SelectedObject == null) return;
				}

				else
				{
					queuedSkill_SelectedObject = character.selectedTarget;
				}

				if (character.IsPlayer())
				{
					// mouse position is where mouse ray hits the floor
					Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
					RaycastHit hit;
					if (Physics.Raycast(ray, out hit, (1 << GameGlobal.LayerMapping.Floor)))
					{
						queuedSkill_MousePosition = hit.point;
					}

					// If that fails then check on a plane that goes through player position
					else
					{
						Plane groundPlane = new Plane(Vector3.up, transform.position);
						float rayDistance;
						if (groundPlane.Raycast(ray, out rayDistance))
						{
							queuedSkill_MousePosition = ray.GetPoint(rayDistance);
						}
						else
						{	// failed. just take character's position
							queuedSkill_MousePosition = transform.position;
						}
					}
				}
				else
				{
					// for an NPC the mouse position is where targeted is at
					if (character.selectedTarget != null) queuedSkill_MousePosition = character.selectedTarget.transform.position;
				}

				if (queuedSkill_SelectedObject != null)
				{
					queuedSkill_TargetPosition = queuedSkill_SelectedObject.transform.position;
				}
				else
				{
					queuedSkill_TargetPosition = queuedSkill_MousePosition;
				}

				queuedSkill = skill;
			}
			else
			{
				queuedSkill = skill;
				queuedSkill_SelectedObject = forceSelectedObject;
				queuedSkill_MousePosition = forceMousePosition;
				queuedSkill_TargetPosition = forceSelectedPosition;
			}

		}

		public virtual void CancelIfQueued(Skill skill)
		{
			if (queuedSkill != null)
			{
				if (queuedSkill.id == skill.id)
				{
					queuedSkill = null;
					queuedSkill_SelectedObject = null;
				}
			}
		}

		private bool CanPerformQueuedSkill()
		{
			//if (false == queuedSkill.mayPerformWhileMove)
			//{	// not allowed to perform when falling/jumping and since this can't
			//	// be forceStop anyway I can just as well let it fail now
			//	this is causing a problem where the character cant use a skill when going down a slope
			//	if (false == character.Grounded())
			//	{
			//		ClearQueuedSkill();
			//		return false;
			//	}
			//}

			if (false == queuedSkill.mayPerformWhileMove && false == queuedSkill.forceStop)
			{	// no force stopping if moving so check if moving and do not allow skill to perform if moving
				if (character.Velocity().magnitude >= 0.01f)
				{
					ClearQueuedSkill();
					return false;
				}
			}

			if (queuedSkill.IsReady())
			{
				// check if the character is within range
				if (false == queuedSkill.DistanceAcceptable(character._tr.position, queuedSkill_TargetPosition, queuedSkill_MousePosition, out targetPositionForSkill, queuedSkill_SelectedObject))
				{
					// if can't move into range then queued skill can just as well be dropped
					if (false == character.RequestMoveTo(targetPositionForSkill, true))
					{
						queuedSkill = null;
						return false;
					}
				}

				else
				{
					// and correct direction to perform the skill
					if (queuedSkill.actorMustFaceTarget && false == queuedSkill.FacingAcceptable(character._tr.forward, queuedSkill_TargetPosition, queuedSkill_MousePosition, out targetDirectionForSkill))
					{
						if (false == character.RequestFaceDirection(targetDirectionForSkill, queuedSkill.executionTimeout > 0.1f ? queuedSkill.executionTimeout : 0.1f))
						{
							// if can't turn to face then queued skill can just as well be dropped
							queuedSkill = null;
							return false;
						}
					}

					else
					{
						return true;
					}
				}
			}

			return false;
		}

		/// <summary> Clear queued skill </summary>
		public void ClearQueuedSkill()
		{
			queuedSkill = null;
			queuedSkill_SelectedObject = null;
		}

		#endregion
		// ============================================================================================================
		#region Factions

		/// <summary> Let Actor Join faction </summary>
		/// <param name="factionId">Id of the faction. </param>
		/// <param name="suppressLog">Set true if no error messages should be printed. </param>
		public void JoinFaction(UniqueID factionId, bool suppressLog)
		{
			ActorFaction f = ActorFactionManager.Instance.GetRuntimeById(factionId);
			if (f == null)
			{
				if (!suppressLog) Debug.LogError("The Faction is not defined.");
				return;
			}

			if (null != GetActorFaction(factionId))
			{
				if (!suppressLog) Debug.LogError("The Actor is already in the Faction.");
				return;
			}

			factions.Add(f);
		}

		/// <summary> Let Actor Leave faction </summary>
		/// <param name="factionId">Id of the faction. </param>
		/// <param name="suppressLog">Set true if no error messages should be printed. </param>
		public void LeaveFaction(UniqueID factionId, bool suppressLog)
		{
			if (!suppressLog)
			{
				ActorFaction f = ActorFactionManager.Instance.GetRuntimeById(factionId);
				if (f == null)
				{
					if (!suppressLog) Debug.LogError("The Faction is not defined.");
					return;
				}
			}

			ActorFaction fact = GetActorFaction(factionId);
			if (fact != null) factions.Remove(fact);
		}

		/// <summary>
		/// return reference to faction if actor in it, else null
		/// </summary>
		public ActorFaction GetActorFaction(UniqueID factionId)
		{
			for (int i = 0; i < factions.Count; i++)
			{
				if (factions[i].id == factionId)
				{
					return factions[i];
				}
			}
			return null;
		}

		#endregion
		// ============================================================================================================
		#region Status

		/// <summary>
		/// Returns the "highest" status of this Actor towards the target via the Factions that both belongs to.
		/// Status goes up from Friendly at lowest level, then Neutral, and then Hostile being highest.
		/// The check is not two-way, meaning the status of the target Actor's Factions are not test against
		/// the Factions of this Actor. This Actor's Faction statuses is only checked against the Factions of the
		/// target Actor. So a Faction can be friendly towards another while the other Faction might be 
		/// Hostile to it. Return Friendly if this Actor or Target is in no Factions.
		/// Will also check statusTowardsPlayer if target is player
		/// </summary>
		public StatusTowardsOther HighestStatusToTarget(Actor target)
		{
			if (target.character.IsPlayer() && overwriteStatus)
			{
				return statusTowardsPlayer;
			}

			if (character.IsPlayer())
			{
				if (target.overwriteStatus) return target.statusTowardsPlayer;
			}

			StatusTowardsOther ret = StatusTowardsOther.Friendly;

			if (factions.Count == 0)
			{
				//Debug.LogWarning(string.Format("Trying to get Status of {0} towards {1} but {2} is not in any factions.", name, target.name, name));
				return StatusTowardsOther.Friendly;
			}

			if (target.factions.Count == 0)
			{
				//Debug.LogWarning(string.Format("Trying to get Status of {0} towards {1} but {2} is not in any factions.", name, target.name, target.name));
				return StatusTowardsOther.Friendly;
			}

			for (int i = 0; i < factions.Count; i++)
			{
				for (int j = 0; j < target.factions.Count; j++)
				{
					int idx = ActorFactionManager.Instance.GetRuntimeIdx(target.factions[j]);
					if (idx < 0) continue;
					if (idx >= factions[i].statusTo.Count) break; // kind of an error but assume it to mean the status is friendly since it is not set
					if ((int)factions[i].statusTo[idx] > (int)ret) ret = factions[i].statusTo[idx];
					if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
				}
				if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
			}

			// - why did i do this? it would return status of other towards me which is not what this function should do
			//if (ret != StatusTowardsOther.Hostile)
			//{
			//	for (int i = 0; i < target.factions.Count; i++)
			//	{
			//		for (int j = 0; j < factions.Count; j++)
			//		{
			//			int idx = ActorFactionManager.Instance.GetRuntimeIdx(factions[j]);
			//			if (idx < 0) continue;
			//			if (idx >= target.factions[i].statusTo.Count) break; // kind of an error but assume it to mean the status is friendly since it is not set
			//			if ((int)target.factions[i].statusTo[idx] > (int)ret) ret = target.factions[i].statusTo[idx];
			//			if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
			//		}
			//		if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
			//	}
			//}

			return ret;

			//// consider base status too when I am NPC and Target is a Player
			//if (target.character.IsPlayer()) ret = statusTowardsPlayer;

			//if (ret == StatusTowardsOther.Hostile) return ret;
			//if (factions.Count == 0) return ret;
			//if (target.factions.Count == 0) return ret;

			//for (int i = 0; i < factions.Count; i++)
			//{
			//	for (int j = 0; j < target.factions.Count; j++)
			//	{
			//		int idx = ActorFactionManager.Instance.GetRuntimeIdx(target.factions[j]);
			//		if (idx >= factions[i].statusTo.Count) break; // kind of an error but assume it to mean the status is friendly since it is not set
			//		if (factions[i].statusTo[idx] > ret) ret = factions[i].statusTo[idx];
			//		if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
			//	}
			//	if (ret == StatusTowardsOther.Hostile) break; // can't go higher than this so break now
			//}
			//return ret;
		}

		///// <summary>
		///// Similar to HighestFactionStatusToTarget() but also takes the target's status towards this actor
		///// also into account when determining the highest status.
		///// </summary>
		//public StatusTowardsOther HighestFactionStatusToTargetBiDirectional(Actor target)
		//{
		//	StatusTowardsOther s1 = this.HighestStatusToTarget(target);
		//	StatusTowardsOther s2 = target.HighestStatusToTarget(this);
		//	if ((int)s1 > (int)s2) return s1;
		//	return s2;
		//}

		///// <summary>
		///// Returns True if any faction of the Actor has the given Status towards the Target
		///// If this is an NPC and the target a Player then the base status (to player) is also considered
		///// </summary>
		//public bool HasStatusToTarget(Actor target, StatusTowardsOther st)
		//{
		//	// consider base status too when I am NPC and Target is a Player
		//	if (target.character.IsPlayer())
		//	{
		//		if (st == statusTowardsPlayer) return true;
		//	}
		//	if (factions.Count == 0) return false;
		//	if (target.factions.Count == 0) return false;
		//	for (int i = 0; i < factions.Count; i++)
		//	{
		//		for (int j = 0; j < target.factions.Count; j++)
		//		{
		//			int idx = ActorFactionManager.Instance.GetRuntimeIdx(target.factions[j]);
		//			if (idx >= factions[i].statusTo.Count) continue;
		//			if (factions[i].statusTo[idx] == st) return true;
		//		}
		//	}
		//	return false;
		//}

		///// <summary>
		///// Returns True if factions of the actor has only the given status towards target
		///// If this is an NPC and the target a Player then the base status (to player) is also considered
		///// </summary>
		//public bool OnlyHasStatusToTarget(Actor target, StatusTowardsOther st)
		//{
		//	// consider base status too when I am NPC and Target is a Player
		//	if (target.character.IsPlayer())
		//	{
		//		if (st != statusTowardsPlayer) return false;
		//	}
		//	if (factions.Count == 0) return false; // technically it has no status towards target
		//	if (target.factions.Count == 0) return false; // technically it has no status towards target
		//	for (int i = 0; i < factions.Count; i++)
		//	{
		//		for (int j = 0; j < target.factions.Count; j++)
		//		{
		//			int idx = ActorFactionManager.Instance.GetRuntimeIdx(target.factions[j]);
		//			if (idx >= factions[i].statusTo.Count) continue;
		//			if (factions[i].statusTo[idx] != st) return false;
		//		}
		//	}
		//	return true;
		//}

		#endregion
		// ============================================================================================================
		#region Pub

		/// <summary>
		/// Returns the def.screenName of the Actor id set (not empty), else the GameObject's name
		/// </summary>
		public string Name()
		{
			return (string.IsNullOrEmpty(def.screenName) ? gameObject.name : def.screenName);
		}

		/// <summary> Call this to kill the Actor. Its HP attribute (if used) will be forced to 0 and it will be set in death state </summary>
		public void Kill()
		{
			if (inDeathLoop) return; // already in death loop
			inDeathLoop = true;

			if (actorClass != null && actorClass.HP != null)
			{
				actorClass.HP.SetConsumableValue(0f, null);
			}

			// let the character respond like disabling control of it
			character.OnDeath();

			// disable movement controller if present
			NPCMoveBase mover = gameObject.GetComponent<NPCMoveBase>();
			if (mover != null) mover.enabled = false;

			// disable components misc
			if (GetComponent<Collider>() != null) GetComponent<Collider>().enabled = false;

			// disable additional components
			for (int i = 0; i < disableOnDeath.Count; i++)
			{
				plyUtil.EnDisableComponent(disableOnDeath[i], false);
			}

			// set object to destroy
			objectDestroyer.Start(gameObject.transform);

			// broadcast to listeners
			gameObject.BroadcastMessage("OnActorDeath", SendMessageOptions.DontRequireReceiver);
		}

		public void Restore()
		{
			inDeathLoop = false;

			if (actorClass != null && actorClass.HP != null)
			{
				actorClass.HP.SetConsumableValue(actorClass.HP.Value, null);
			}

			character.OnRestore();

			NPCMoveBase mover = gameObject.GetComponent<NPCMoveBase>();
			if (mover != null) mover.enabled = true;

			if (GetComponent<Collider>() != null) GetComponent<Collider>().enabled = true;

			for (int i = 0; i < disableOnDeath.Count; i++)
			{
				plyUtil.EnDisableComponent(disableOnDeath[i], true);
			}

			gameObject.BroadcastMessage("OnActorRestored", SendMessageOptions.DontRequireReceiver);
		}

		/// <summary> Called by the player controller to inform the Actor that the player pressed some keys used to move the character. 
		/// This is so the Actor can check whether a queued skill, waiting to execute, might need to be canceled. </summary>
		public void ReceivedMoveCommand()
		{
			if (queuedSkill != null)
			{
				if (false == queuedSkill.mayPerformWhileMove && false == queuedSkill.forceStop)
				{
					ClearQueuedSkill();
				}
			}
		}

		public string ObjectPrettyName()
		{
			return (string.IsNullOrEmpty(def.screenName) ? gameObject.name : def.screenName);
		}

		/// <summary> Return true if the actor is dead. Will only function properly
		/// if the Health attribute is configured and the Actor Class has the same
		/// attribute in its list of attributes. If Health is not configured then
		/// this will always return false. </summary>
		public bool IsDead()
		{
			if (actorClass == null) return false;
			if (actorClass.HP == null) return false;
			if (actorClass.HP.ConsumableValue <= 0) return true;
			return false;
		}

		#endregion
		// ============================================================================================================
	}
}