﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> Base class for all Animation Controllers </summary>
	[AddComponentMenu("")]
	public class AnimationControlBase : MonoBehaviour
	{

		// ============================================================================================================
	}
}