﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("plyGame/Systems/Location Marker")]
	public class LocationMarker : MonoBehaviour
	{
		public int ident = 0;
		public string notes;

		// ============================================================================================================

		void OnDrawGizmos()
		{
			Gizmos.color = new Color(0.57f, 0.66f, 0.70f, 1f);
			Gizmos.DrawLine(transform.position - Vector3.up * 0.1f, transform.position + Vector3.up * 1.75f);
			Gizmos.DrawCube(transform.position - Vector3.up * 0.1f, new Vector3(0.1f, 0.1f, 0.1f));
			Gizmos.DrawIcon(transform.position + Vector3.up * 2f, "plygame/marker.png");
		}

		// ============================================================================================================
	}
}