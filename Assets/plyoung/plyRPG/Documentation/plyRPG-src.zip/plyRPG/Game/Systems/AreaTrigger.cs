﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("plyGame/Systems/Area Trigger")]
	[RequireComponent(typeof(plyBlox))]
	public class AreaTrigger : MonoBehaviour
	{

		public enum AreaKind
		{
			None,
			Rectangular,
			Circular
		}

		public AreaKind areaKind = AreaKind.Circular;
		public bool isActive = true;

		public enum TriggerOnlyOn
		{
			Any = 0,
			Player = 1,
			NPC = 2,
			AnyExcludeNonCharacter = 3,
		}

		public TriggerOnlyOn triggerOnlyOn = TriggerOnlyOn.Player;

		// ============================================================================================================

		private plyBlox blox;

		// ============================================================================================================

		protected void Reset()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyTrigger;
		}

		protected void Awake()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyTrigger;

			// check if there is a plyBlox with Events. If not, disable this object
			blox = GetComponent<plyBlox>();
			if (blox == null)
			{
				isActive = false;
				gameObject.SetActive(false);
			}
			else if (blox.states.Count == 0)
			{
				isActive = false;
				gameObject.SetActive(false);
			}
		}

		protected void Start()
		{
			if (areaKind == AreaKind.Circular)
			{
				SphereCollider col = gameObject.AddComponent<SphereCollider>();
				col.isTrigger = true;
				col.radius = 1f; // it scales with the transform's localScale
			}
			else if (areaKind == AreaKind.Rectangular)
			{
				BoxCollider col = gameObject.AddComponent<BoxCollider>();
				col.isTrigger = true;
				col.size = Vector3.one; // one cause the localScale of the object is already used
			}

			if (!isActive)
			{
				gameObject.SetActive(false);
			}
		}

		// ============================================================================================================

		void OnDrawGizmos()
		{
			Gizmos.color = Color.magenta;
			Gizmos.DrawLine(transform.position - Vector3.up * 0.1f, transform.position + Vector3.up * 1.75f);
			Gizmos.DrawCube(transform.position - Vector3.up * 0.1f, new Vector3(0.1f, 0.1f, 0.1f));
			Gizmos.DrawIcon(transform.position + Vector3.up * 2f, "plygame/trigger.png");
		}

		void OnDrawGizmosSelected()
		{
			if (areaKind == AreaKind.Circular)
			{
				float r = Mathf.Max(transform.localScale.x, Mathf.Max(transform.localScale.y, transform.localScale.z));
				Gizmos.color = new Color(1f, 0f, 1f, 0.15f);
				Gizmos.DrawSphere(transform.position, r);
				Gizmos.color = Color.magenta;
				Gizmos.DrawWireSphere(transform.position, r);
			}

			else if (areaKind == AreaKind.Rectangular)
			{
				Gizmos.matrix = transform.localToWorldMatrix;
				Gizmos.color = new Color(1f, 0f, 1f, 0.15f);
				Gizmos.DrawCube(Vector3.zero, Vector3.one);
				Gizmos.color = Color.magenta;
				Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
			}
		}

		// ============================================================================================================
	}
}