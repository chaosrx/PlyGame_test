﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> All defined Skills. </summary>
	[System.Serializable]
	public class SkillsAsset : ScriptableObject
	{

		//[HideInInspector] 
		public List<GameObject> skillFabs = new List<GameObject>(0); //!< List of defined Skill prefabs.

		public float globalCooldownValue = 1f; // seconds

		// ============================================================================================================

		[HideInInspector, System.NonSerialized]
		public List<Skill> skills = new List<Skill>(0); //!< List of defined Skills. Should call UpdateCache() or UpdateCacheIfNeeded() before using this for first time.

		/// <summary> Provide access to asset at runtime </summary>
		public static SkillsAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (SkillsAsset)GameGlobal.Instance.GetAsset<SkillsAsset>();
					// create a fake if no real asset exist
					if (_instance == null) _instance = ScriptableObject.CreateInstance<SkillsAsset>();
				}
				return _instance;
			}
		}
		private static SkillsAsset _instance;

		/// <summary> Updates the list of skills from skillFabs list. </summary>
		public void UpdateCacheIfNeeded()
		{
			if (skillFabs.Count > skills.Count) UpdateCache();
		}

		/// <summary> Updates the list of skills from skillFabs list. </summary>
		public void UpdateCache()
		{
			bool foundNull = false;
			skills = new List<Skill>(skillFabs.Count);
			for (int i = 0; i < skillFabs.Count; i++)
			{
				if (skillFabs[i] == null)
				{
					foundNull = true;
					continue;
				}
				skills.Add(skillFabs[i].GetComponent<Skill>());
			}

			if (foundNull) plyUtil.CleanupList<GameObject>(skillFabs);
		}

		/// <summary> Gets the Skill prefab by Id. Return null if failed. </summary>
		public GameObject GetPrefab(UniqueID id)
		{
			Skill s = GetDefinition(id);
			if (s != null) return s.gameObject;
			return null;
		}

		/// <summary> Gets the Skill definition by Id. Return null if failed. </summary>
		public Skill GetDefinition(UniqueID id)
		{
			if (id == null) return null;
			if (id.IsEmpty) return null;
			if (skillFabs.Count > skills.Count) UpdateCache();
			for (int i = 0; i < skills.Count; i++)
			{
				if (skills[i].id == id) return skills[i];
			}
			return null;
		}

		/// <summary> Get the defined skill by its name, custom def.ident or def.meta data. Return null if not found. </summary>
		public Skill GetDefinition(string ident, plyGameObjectIdentifyingType identType)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			if (identType == plyGameObjectIdentifyingType.ident)
			{
				for (int i = 0; i < skills.Count; i++) if (skills[i].def.ident.Equals(ident)) return skills[i];
			}
			if (identType == plyGameObjectIdentifyingType.screenName)
			{
				for (int i = 0; i < skills.Count; i++) if (skills[i].def.screenName.Equals(ident)) return skills[i];
			}
			if (identType == plyGameObjectIdentifyingType.shortName)
			{
				for (int i = 0; i < skills.Count; i++) if (skills[i].def.shortName.Equals(ident)) return skills[i];
			}
			if (identType == plyGameObjectIdentifyingType.meta)
			{
				for (int i = 0; i < skills.Count; i++) if (skills[i].def.meta.Equals(ident)) return skills[i];
			}
			return null;
		}

		/// <summary> Get the defined skill by its name, custom def.ident or def.meta data. Return UniqueID.Empty if not found. </summary>
		public UniqueID GetDefinitionUniqueId(string ident, plyGameObjectIdentifyingType identType)
		{
			Skill s = GetDefinition(ident, identType);
			if (s != null) return s.id;
			return UniqueID.Empty;
		}

		/// <summary> Get the Skill definition index into the skills list by its Id. Return -1 if not found. </summary>
		public int GetDefinitionIdx(UniqueID id)
		{
			if (id.IsEmpty) return -1;
			if (skillFabs.Count > skills.Count) UpdateCache();
			for (int i = 0; i < skills.Count; i++)
			{
				if (skills[i].id == id) return i;
			}
			return -1;
		}

		/// <summary> Get Skill name by Id. Return "-invalid-" if not found. </summary>
		public string GetScreenName(UniqueID id)
		{
			if (id.IsEmpty) return "-invalid-";
			if (skillFabs.Count > skills.Count) UpdateCache();
			for (int i = 0; i < skills.Count; i++)
			{
				if (skills[i].id == id) return skills[i].def.screenName;
			}
			return "-invalid-";
		}

		/// <summary> Get a list of names of all defined Skills. </summary>
		public string[] GetNames()
		{
			if (skillFabs.Count > skills.Count) UpdateCache();
			string[] n = new string[skills.Count];
			for (int i = 0; i < n.Length; i++) n[i] = skills[i].def.screenName;
			return n;
		}

		// ============================================================================================================
	}
}