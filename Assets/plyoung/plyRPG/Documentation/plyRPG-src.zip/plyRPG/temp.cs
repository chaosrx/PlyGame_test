﻿
//using plyGame;
//public class MyPlayerController : CharacterControllerBase
//{
//	protected override void Awake()
//	{ }

//	protected override void Start()
//	{ }
//}

//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using plyBloxKit;
//using plyGame;

//[plyBlock("Character", "Skills (plyRPG)", "Reset Execution Timer", BlockType.Action, Order = 6, ShowName = "Reset Execution Timer",
//	Description = "Reset the Execution Timer to 0.")]
//public class Skill_ResetExecutionTimer_plyBlock : plyBlock
//{
//	[plyBlockField("of Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to check.")]
//	public SystemObject_Value val;

//	[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
//	public GameObject_Value target;

//	[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
//	public bool cacheTarget = false;

//	private Actor actor = null;

//	public override void Created()
//	{
//		GameGlobal.Create();
//		blockIsValid = val != null;
//		if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
//		if (target == null) cacheTarget = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		if (actor == null)
//		{
//			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
//			if (o != null)
//			{
//				actor = o.GetComponent<Actor>();
//				if (actor == null)
//				{
//					blockIsValid = false;
//					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
//					return BlockReturn.Error;
//				}
//			}
//		}

//		Skill skill = val.RunAndGetSystemObject() as Skill;
//		if (skill == null)
//		{
//			Log(LogType.Error, "The Skill value is invalid.");
//			return BlockReturn.Error;
//		}

//		Skill knownSkill = actor.GetKnownSkill(skill);
//		if (knownSkill != null)
//		{
//			knownSkill.executeTimer = 0f;
//		}
//		else
//		{
//			Log(LogType.Error, "The Skill is not known by the Actor.");
//			return BlockReturn.Error;
//		}

//		if (false == cacheTarget) actor = null;
//		return BlockReturn.OK;
//	}
//}


//[plyBlock("Character", "Skills (plyRPG)", "Reset Cooldown Timer", BlockType.Action, Order = 6, ShowName = "Reset Cooldown Timer",
//	Description = "Reset the Cooldown Timer to 0.")]
//public class Skill_ResetCooldownTimer_plyBlock : plyBlock
//{
//	[plyBlockField("of Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to check.")]
//	public SystemObject_Value val;

//	[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
//	public GameObject_Value target;

//	[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
//	public bool cacheTarget = false;

//	private Actor actor = null;

//	public override void Created()
//	{
//		GameGlobal.Create();
//		blockIsValid = val != null;
//		if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
//		if (target == null) cacheTarget = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		if (actor == null)
//		{
//			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
//			if (o != null)
//			{
//				actor = o.GetComponent<Actor>();
//				if (actor == null)
//				{
//					blockIsValid = false;
//					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
//					return BlockReturn.Error;
//				}
//			}
//		}

//		Skill skill = val.RunAndGetSystemObject() as Skill;
//		if (skill == null)
//		{
//			Log(LogType.Error, "The Skill value is invalid.");
//			return BlockReturn.Error;
//		}

//		Skill knownSkill = actor.GetKnownSkill(skill);
//		if (knownSkill != null)
//		{
//			knownSkill.cooldownTimer = 0f;
//		}
//		else
//		{
//			Log(LogType.Error, "The Skill is not known by the Actor.");
//			return BlockReturn.Error;
//		}

//		if (false == cacheTarget) actor = null;
//		return BlockReturn.OK;
//	}
//}


//[plyBlock("Misc", "Misc", "Get NPC Around Point", BlockType.Variable, Order = 1, ShowName = "Get NPC", Description = "",
//	ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value))]
//public class plyBlock_FindActorsAroundPoint : GameObject_Value
//{
//	[plyBlockField("around point", ShowName = true, ShowValue = true)]
//	public Vector3_Value point;

//	[plyBlockField("and radius", ShowName = true, ShowValue = true)]
//	public Float_Value radius;

//	public override void Created()
//	{
//		GameGlobal.Create();
//		blockIsValid = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		Vector3 p = point == null ? Vector3.zero : point.RunAndGetVector3();
//		float r = radius == null ? 1f : radius.RunAndGetFloat();
//		value = GetFirstActorAround(p, r);
//		return BlockReturn.OK;
//	}

//	private class CollectedTarget
//	{
//		public Targetable t;
//		public float distance;
//	}


//	private GameObject GetFirstActorAround(Vector3 aroundPoint, float radius)
//	{
//		Collider[] colliderHits = Physics.OverlapSphere(aroundPoint, radius, 1 << GameGlobal.LayerMapping.NPC);
//		if (colliderHits.Length > 0)
//		{
//			// return a random one
//			return colliderHits[Random.Range(0, colliderHits.Length].gameObject;

//			// or comment out the above line of code and use the following to get the object closest to the point

//			//// create a list of all the hits and how far they are from the target point
//			//List<CollectedTarget> collectedTargets = new List<CollectedTarget>();
//			//for (int i = 0; i < colliderHits.Length; i++)
//			//{
//			//	Targetable target = colliderHits[i].gameObject.GetComponent<Targetable>();
//			//	if (target != null)
//			//	{
//			//		if (target == mainTarget) continue;
//			//		collectedTargets.Add(new CollectedTarget()
//			//		{
//			//			t = target,
//			//			distance = Vector3.Distance(colliderHits[i].transform.position, aroundPoint)
//			//		});
//			//	}
//			//}

//			//// sort the objects by distance from the point so the returned one is one closest to the point
//			//collectedTargets.Sort(delegate(CollectedTarget a, CollectedTarget b) { return a.distance.CompareTo(b.distance); });
//			//return collectedTargets[0].t.gameObject;
//		}

//		// else nothing was found
//		return null;
//	}

//}



//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using plyBloxKit;
//using plyGame;

//[plyBlock("Input", "Input (plyGame)", "Set Mouse Button Handled", BlockType.Action, Order = 1, ShowName = "Set Mouse Button Handled",
//	Description = "Tell plyGame that the mouse input was handled this frame.")]
//public class plyInput_MouseInputHandled_plyBlock : plyBlock
//{
//	public override void Created()
//	{
//		GameGlobal.Create();
//		blockIsValid = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		plyInput.MouseInputHandled = true;
//		return BlockReturn.OK;
//	}
//}


//using UnityEngine;
//using plyBloxKit;
//using plyCommon;
//using plyGame;

//[plyBlock("Misc", "Misc", "Color as Color32", BlockType.Variable, Order = 0, Description = "...",
//	ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value))]
//public class Color_As_Color32_polyBlock : SystemObject_Value
//{
//	[plyBlockField("color", ShowAfterField = "as Color32", ShowValue = true)]
//	public Color_Value col;

//	public override void Created()
//	{
//		blockIsValid = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		value = col == null ? new Color32() : (Color32)col.RunAndGetColor();
//		return BlockReturn.OK;
//	}
//}

//using UnityEngine;
//using plyBloxKit;
//using plyCommon;
//using plyGame;

//[plyBlock("Misc", "Misc", "Color as Color32", BlockType.Variable, Order = 0, Description = "...",
//	ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value))]
//public class Color_As_Color32_polyBlock : SystemObject_Value
//{
//	[plyBlockField("color", ShowAfterField = "as Color32", ShowValue = true)]
//	public Color_Value col;

//	public override void Created()
//	{
//		blockIsValid = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		value = col == null ? new Color32() : (Color32)col.RunAndGetColor();
//		return BlockReturn.OK;
//	}
//}


//using UnityEngine;
//using plyBloxKit;
//using plyCommon;
//using plyGame;

//[plyBlock("Character", "Control (plyRPG)", "Toggle Jump", BlockType.Action, Order = 5, Description = "...")]
//public class Toggle_Player_Jump : plyBlock
//{
//	[plyBlockField("Toggle Jump", ShowName = true, ShowValue = true)]
//	public bool allow = true;

//	public override void Created()
//	{
//		GameGlobal.Create(); // make sure Global is available
//		blockIsValid = true;
//	}

//	public override BlockReturn Run(BlockReturn param)
//	{
//		// enable line of code for the one you are using
//		//PlayerThirdPersonController chara = Player.Instance as PlayerThirdPersonController;
//		//PlayerTopDownController chara = Player.Instance as PlayerTopDownController;

//		chara.allowJump = allow;
//		return BlockReturn.OK;
//	}
//}
