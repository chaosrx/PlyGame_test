﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Equip (plyRPG)", "Item is Equipped", BlockType.Condition, Order = 4,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Return True if Item is equipped, else False.")]
	public class IsEquiped_plyBlock : Bool_Value
	{
		[plyBlockField("Item", ShowAfterField="is equipped", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to check.")]
		public SystemObject_Value itVal;

		[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has equip slots.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private EquipmentSlots slots;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = itVal != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");

		}

		public override BlockReturn Run(BlockReturn param)
		{
			// ** Get reference to equip slots
			if (slots == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				slots = go.GetComponent<EquipmentSlots>();
				if (slots == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Equipment Slots component on it.");
					return BlockReturn.Error;
				}
			}

			Item item = itVal.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			value = slots.ItemIsEquipped(item);

			if (!cacheTarget) slots = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}