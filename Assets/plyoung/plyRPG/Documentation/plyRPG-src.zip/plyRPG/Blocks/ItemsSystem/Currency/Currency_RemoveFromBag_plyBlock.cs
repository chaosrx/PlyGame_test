﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Currency (plyRPG)", "Remove from Bag", BlockType.Action, Order = 2,
		Description = "Add specified Item to a Bag.")]
	public class Currency_RemoveFromBag_plyBlock : plyBlock
	{
		[plyBlockField("Remove", ShowAfterField = "Currency from Bag", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Amount - Integer", Description = "How much currency to remove from the bag. Will subtract currency, whether the number is positive or negative.")]
		public Int_Value amount;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = amount != null;
			if (!blockIsValid) Log(LogType.Error, "The amount must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			int i = amount.RunAndGetInt();
			if (i < 0) i *= -1;
			if (false == bag.RemoveCurrency(i))
			{
				Log(LogType.Warning, string.Format("Failed to subtract currency as there where not enough. Wanted: {0}, while there where only: {1}", i, bag.currency));
			}

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}