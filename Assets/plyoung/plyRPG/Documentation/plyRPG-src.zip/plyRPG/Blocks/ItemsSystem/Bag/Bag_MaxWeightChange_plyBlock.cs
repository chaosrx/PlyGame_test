﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Change Max Weight", BlockType.Action, Order = 3, ShowName = "Change Max Weight",
		Description = "Change the max weight of a bag.")]
	public class Bag_MaxWeightChange_plyBlock : plyBlock
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("by", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Value - Integer", Description = "The amount to change the max weight by. This can be either a positive or negative number.")]
		public Int_Value val;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = val != null;
			if (!blockIsValid) Log(LogType.Error, "The value should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			bag.ChangeMaxWeightBy(val.RunAndGetInt());

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}