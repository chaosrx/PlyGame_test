﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Object", "Customizer (plyRPG)", "Change Object", BlockType.Action, Order = 5, ShowName = "Change Object",
		Description = "Change the active object of a group in target Simple Customizer.")]
	public class Customize_ChangeObj_plyBlock : plyBlock
	{
		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName="Index - Integer", Description = "The index to apply.")]
		public Int_Value idx;

		[plyBlockField("on", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), SubName="Group - String/Integer", Description = "The group name (string) or index (integer) to affect.")]
		public plyValue_Block group;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target GameObject that has a SimpleCustomizer component on it.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private SimpleCustomizer cust = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = idx != null && group != null;
			if (!blockIsValid) Log(LogType.Error, "The index and group fields must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (cust == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				cust = go.GetComponent<SimpleCustomizer>();
				if (cust == null)
				{
					Log(LogType.Error, "The Target is invalid. It has no SimpleCustomizer component.");
					return BlockReturn.Error;
				}
			}

			object v = group.RunAndGetValue();
			int gid = -1;
			if (v.GetType() == typeof(string))
			{
				gid = cust.GetObjectGroup((string)v);
			}
			else if (v.GetType() == typeof(int))
			{
				gid = (int)v;
			}
			else
			{
				Log(LogType.Error, "The group field must contain either an Integer (index) or String (name) value.");
				return BlockReturn.Error;
			}

			if (false == cust.ChangeObject(gid, idx.RunAndGetInt()))
			{
				Log(LogType.Error, "Something went wrong. You might have passed an invalid index.");
				return BlockReturn.Error;
			}

			if (!cacheTarget) cust = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}