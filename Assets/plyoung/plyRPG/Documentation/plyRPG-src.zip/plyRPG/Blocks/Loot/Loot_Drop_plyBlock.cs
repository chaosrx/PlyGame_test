﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Loot (plyRPG)", "Drop Loot", BlockType.Action, Order = 2,
		Description = "Create the rewards defined in a Loot Table.")]
	public class Loot_Drop_plyBlock : plyBlock
	{
		[plyBlockField("Drop Loot", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), SubName = "Loot Table - String", Description = "Name of Loot Table.")]
		public String_Value name;

		[plyBlockField("at", SubName = "Position - Vector3", ShowName = true, ShowValue = true, DefaultObject=typeof(Vector3_Value), Description = "Position from which to drop loot.")]
		public Vector3_Value pos;

		[plyBlockField("with Subject", SubName = "Subject - GameObject", ShowName = true, ShowValue = true, EmptyValueName = "none", Description = "The NPC or other Object involved in the Drop, if any. Needed when you specified the use of NPC Levels or Subject in the Loot Table.")]
		public GameObject_Value npc;

		[plyBlockField("Y mod",  Description = "Y offset to create the loot drops at. Normally you pass in the position of and object for 'position' but you might not want the items to drop from the feet so add a height offset here.")]
		public float yMod = 0.5f;

		[plyBlockField("Direct to Bag", Description = "If this is set then the loot will be added to the Player bag directly. The Position and Y-Mod options are ignored in this case.")]
		public bool directToBag = false;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = name != null;
			if (!blockIsValid) Log(LogType.Error, "The name field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameObject go = npc == null ? null : npc.RunAndGetGameObject();

			if (directToBag)
			{
				if (false == LootAsset.Instance.DropLootToPlayerBag(name.RunAndGetString(), go))
				{
					Log(LogType.Error, "Error while trying to create loot drops.");
					return BlockReturn.Error;
				}
			}
			else
			{
				Vector3 p = (pos == null ? Vector3.zero : pos.RunAndGetVector3()) + new Vector3(0f, yMod, 0f);
				if (false == LootAsset.Instance.DropLoot(name.RunAndGetString(), p, go))
				{
					Log(LogType.Error, "Error while trying to create loot drops.");
					return BlockReturn.Error;
				}
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}