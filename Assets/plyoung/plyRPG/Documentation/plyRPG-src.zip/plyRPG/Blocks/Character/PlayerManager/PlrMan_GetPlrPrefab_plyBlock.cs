﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Get Player Prefab", BlockType.Variable, Order = 2,
		ReturnValueType = typeof(GameObject_Value), ReturnValueString = "Returns - GameObject", CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return reference to the Player Prefab from the Player Manager.")]
	public class PlrMan_GetPlrPrefab_plyBlock : GameObject_Value
	{
		[plyBlockField("Get Player Prefab", ShowAfterField = "in Player Manager", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Index - Integer", Description = "The index into the list of defined Actor Prefabs, starting at (0)")]
		public Int_Value idx;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = idx != null;
			if (!blockIsValid) Log(LogType.Error, "The index field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = PlayerManager.Instance.GetPlayerPrefab(idx.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}