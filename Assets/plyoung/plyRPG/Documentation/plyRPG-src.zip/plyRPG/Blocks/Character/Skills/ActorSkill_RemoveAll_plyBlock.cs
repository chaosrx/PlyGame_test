﻿//// THIS IS ADDED AS AN OUTSIDE BLOCK

//// -= plyBlox =-
//// www.plyoung.com
//// Copyright (c) Leslie Young
//// ====================================================================================================================

//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using plyBloxKit;
//using plyCommon;

//namespace plyGame
//{
//	[plyBlock("Character", "Skills (plyRPG)", "Remove all Skills", BlockType.Action, Order = 6, ShowName = "Remove all Skills",
//		Description = "Remove all Skill from the Actor.")]
//	public class ActorSkill_RemoveAll_plyBlock : plyBlock
//	{
//		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
//		public GameObject_Value target;

//		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
//		public bool cacheTarget = false;

//		private Actor actor = null;

//		public override void Created()
//		{
//			GameGlobal.Create(); // make sure Global is available
//			blockIsValid = true;
//			if (target == null) cacheTarget = true;
//		}

//		public override BlockReturn Run(BlockReturn param)
//		{
//			if (actor == null)
//			{
//				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
//				if (o != null)
//				{
//					actor = o.GetComponent<Actor>();
//					if (actor == null)
//					{
//						blockIsValid = false;
//						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
//						return BlockReturn.Error;
//					}
//				}
//			}

//			if (actor.knownSkills.Count > 0)
//			{
//				List<UniqueID> knownSkills = new List<UniqueID>();
//				for (int i = 0; i < actor.knownSkills.Count; i++) 
//				{
//					knownSkills.Add(actor.knownSkills[i].id);
//				}

//				for (int i = 0; i < knownSkills.Count; i++) 
//				{
//					actor.UnlearnSkill(knownSkills[i]);
//				}
//			}

//			if (false == cacheTarget) actor = null;
//			return BlockReturn.OK;
//		}

//		// ============================================================================================================
//	}
//}