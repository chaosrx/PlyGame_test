﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Get Known", BlockType.Variable, Order = 6, ShowName = "Get Skill",
		ReturnValueString = "Return - SystemObject", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns a reference to the Known Skill of the Actor at specified index of the list of known skills. This can be used in combination with the Loop Block and `Known Count` to run through the list of all known skills.")]
	public class Skill_KnownGet_plyBlock : SystemObject_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("at", ShowName = true, ShowValue = true, EmptyValueName = "-0-", SubName = "Index - Integer", Description = "Index into List of Known Skills. Remember that indices always start at 0 and run up to one less than the Known Count. So if the player knows 3 skills then 0, 1, and 2 are valid indices.")]
		public Int_Value idx;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			int i = idx == null ? 0 : idx.RunAndGetInt();
			if (i < 0 || i >= actor.knownSkills.Count)
			{
				Log(LogType.Error, "The given Index [" + i + "] is invalid, the Actor has [" + actor.knownSkills.Count + "] known skills.");
				return BlockReturn.Error;
			}

			value = actor.knownSkills[i];
			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}