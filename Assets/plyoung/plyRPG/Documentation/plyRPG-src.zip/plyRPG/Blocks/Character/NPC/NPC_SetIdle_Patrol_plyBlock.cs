﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Idle: Patrol", BlockType.Action, Order = 10,
		Description = "Set the target NPC to Patrol, following a specified path, when it is in 'idle' mode (not chasing something)")]
	public class NPC_SetIdle_Patrol_plyBlock : plyBlock
	{
		[plyBlockField("Set", ShowAfterField = "to: Patrol", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("path", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Path - GameObject", Description = "The path to follow.")]
		public GameObject_Value pathGo;

		[plyBlockField("on point", ShowName = true, ShowValue = true, EmptyValueName = "-0-", SubName = "Point - Integer", Description = "Index of a point on the path to start at. (optional)")]
		public Int_Value point;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = pathGo != null;
			if (!blockIsValid) Log(LogType.Error, "The Path to follow should be set.");
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (npc == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null) npc = o.GetComponent<NPCController>();
					if (npc == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
						return BlockReturn.Error;
					}

				}

				npc.Stop();

				GameObject go = pathGo.RunAndGetGameObject();
				if (go != null)
				{
					WaypointPath wp = go.GetComponent<WaypointPath>();
					if (wp != null)
					{
						int p = point == null ? 0 : point.RunAndGetInt();
						npc.SetPatrolPath(wp, p);
						npc.idleMode = NPCController.IdleMode.Patrol;
					}
					else
					{
						blockIsValid = false;
						Log(LogType.Error, "Not a valid Path object.");
						return BlockReturn.Error;
					}
				}
				else
				{
					blockIsValid = false;
					Log(LogType.Error, "The Path object is -null-");
					return BlockReturn.Error;
				}

				if (false == cacheTarget) npc = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}