﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Common (plyRPG)", "Player", BlockType.Variable, Order = 1, ShowName = "Player",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value),
		Description = "Returns the active player GameObject. Prints error to console if player is not yet set.")]
	public class Get_Player_plyBlock : GameObject_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (Player.Instance == null)
			{
				Log(LogType.Error, "Player is not yet set.");
				return BlockReturn.Error;
			}

			value = Player.Instance.gameObject;

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}