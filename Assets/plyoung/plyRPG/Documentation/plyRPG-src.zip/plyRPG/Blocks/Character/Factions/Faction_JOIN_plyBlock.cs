﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Factions (plyRPG)", "Join", BlockType.Action, Order = 15, ShowIcon = "faction", 
		Description = "Let the character Join a Faction.")]
	public class Faction_JOIN_plyBlock : plyBlock
	{
		[plyBlockField("Let",ShowName = true,  ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("join", ShowIfTargetFieldInvalid = "faction1", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Faction ident - String", Description = "The Faction to get the status of. You can choose to either select it from a list or to find it via an ident type. Select 'none' in the list to see a field on the Block into which you can put a String Block which identifies the Faction to find.")]
		public String_Value factionIdent1;

		[plyBlockField("join Faction", CustomValueStyle = "plyBlox_BoldLabel")]
		public FactionFieldData faction1 = new FactionFieldData();

		[plyBlockField("Faction ident type", ShowIfTargetFieldInvalid = "faction1", Description = "What kind of value are you using to identify the Faction by? Only needed if you did not pick the Faction from a List.")]
		public plyGameObjectIdentifyingType identType1 = plyGameObjectIdentifyingType.screenName;

		private UniqueID id1;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;

			if (string.IsNullOrEmpty(faction1.id))
			{
				if (factionIdent1 == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Faction is not set.");
					return;
				}
			}
			else
			{
				id1 = new UniqueID(faction1.id); 
				factionIdent1 = null; // make sure is null since I use it for test later
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			ActorFaction f1 = null;

			if (factionIdent1 != null) f1 = ActorFactionManager.Instance.GetRuntimeByIdent(factionIdent1.RunAndGetString(), identType1);
			else f1 = ActorFactionManager.Instance.GetRuntimeById(id1);
			if (f1 == null)
			{
				Log(LogType.Error, "Faction not found");
				blockIsValid = false;
				return BlockReturn.Error;
			}

			Actor actor = null;
			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (o != null)
			{
				actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return BlockReturn.Error;
				}
			}

			actor.JoinFaction(f1.id, true);

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}