﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Change Attribute", BlockType.Action, Order = 4, ShowName = "Change Attribute",
		Description = "Change the Attribute's Value, Consumable Value, or Bonus Value by increasing or decreasing it. Useful to increase or decrease the value for attributes like Health, Mana, or Experience.")]
	public class ActorAttribute_Change_plyBlock : plyBlock
	{
		[plyBlockField("Value Type", ShowValue = true, Description = "Choose to change the Value, ConsumableValue, or Bonus Value of the Attribute. For an attribute like Strength or Wisdom you would only be interested in the 'Value'. With attributes like Health, Experience, Mana Points, etc, the 'Value' is the current max the attribute's 'Consumable Value' can reach. So, when you want to change what the health is at currently, you would use the 'Consumable Value' and if you wanted to change how much health the character can have in total, you would use the 'Value'.\n\nChanging the Value will set the base value. Bonuses will then be added and the Value change related events will trigger.")]
		public ActorAttribute.ValueType valueType = ActorAttribute.ValueType.ConsumableValue;

		[plyBlockField("Attribute", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public string attribName = "";

		[plyBlockField("Ident type", Description = "What kind of value did you enter in the previous field to identify the Attribute by?")]
		public plyGameObjectIdentifyingType identType = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("by", ShowName = true, ShowValue = true, DefaultObject = typeof(Float_Value), SubName="Value - Float", Description = "Enter a negative value to decrease or a positive number to increase the value. The Consumable Value will not decrease below 0 or increase above the attribute's Value (base + bonuses). If you are changing the Value then the base value will be changed and then bonuses will be applied. The base value will not decreased below 0.")]
		public Float_Value val;

		[plyBlockField("with influence", ShowName = true, ShowValue = true, EmptyValueName = "-none-", SubName = "Influence - GameObject", Description = "This should be set to the object considered the reason for the change in attribute value. Normally you leave this -none- but in the case where a Health attribute's consumable value is decreased you might want to set this so that the target knows what attacked it.")]
		public GameObject_Value influence;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ActorAttribute attrib = null;
		
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		private void GetAttribute()
		{
			Actor actor = null;
			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (o != null)
			{
				actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return;
				}
			}

			attrib = actor.actorClass.GetAttribute(attribName, identType);
			if (attrib == null)
			{
				blockIsValid = false;
				Log(LogType.Error, "The Attribute [" + attribName + "] could not be found on the Actor [" + actor.def.screenName + "]");
				return;
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (attrib == null)
			{
				GetAttribute();
				if (false == blockIsValid) return BlockReturn.Error;
			}				

			if (valueType == ActorAttribute.ValueType.ConsumableValue)
			{
				//attrib.ConsumableValue += val.RunAndGetFloat();
				attrib.SetConsumableValue(attrib.ConsumableValue + val.RunAndGetFloat(), influence == null ? null : influence.RunAndGetGameObject());
			}
			else if (valueType == ActorAttribute.ValueType.Value)
			{
				attrib.ChangeBaseValueBy((int)val.RunAndGetFloat());
			}
			else if (valueType == ActorAttribute.ValueType.Bonus)
			{
				attrib.ChangeSimpleBonus((int)val.RunAndGetFloat());
			}

			if (false == cacheTarget) attrib = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}