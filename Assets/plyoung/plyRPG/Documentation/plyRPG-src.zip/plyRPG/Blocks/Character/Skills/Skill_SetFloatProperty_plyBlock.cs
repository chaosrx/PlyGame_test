﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Set Skill Property", BlockType.Action, Order = 6, ShowName = "Set Skill",
		Description = "Set a property of a Skill on the specified Actor.")]
	public class Skill_SetFloatProperty_plyBlock : Float_Value
	{
		public enum PropType
		{
			ExecutionTime,
			CooldownTime,
			HitHeightPercentage,
			HitDelay,
			
			MaxProjectiles,
			CreateDelay,
			BetweenCreateDelay,
			MoveSpeed,
			CollisionRayWidth,
			MaxLiveTime,

			MaxTargetSelect,
			MaxDistanceFromSelf,
			TargetRangeAngle,
			TargetRangeRadius,

			MaxSecondaryTargets,
			SecondaryRangeRadius,

		}

		[plyBlockField("Property", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public PropType propType = PropType.ExecutionTime;

		[plyBlockField("of Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill.")]
		public SystemObject_Value targetSkill;

		[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, EmptyValueName = "-0-", SubName = "Value - Float", Description = "Value to set it to.")]
		public Float_Value targetVal;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = targetSkill != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = targetSkill.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			Skill knownSkill = actor.GetKnownSkill(skill);
			if (knownSkill != null)
			{
				float f = targetVal == null ? 0f : targetVal.RunAndGetFloat();
				switch (propType)
				{
					case PropType.ExecutionTime: { knownSkill.executionTimeout = f; } break;
					case PropType.CooldownTime: { knownSkill.cooldownTimeout = f; } break;
					case PropType.HitHeightPercentage: { knownSkill.hitHeightPercentage = (int)f; } break;
					case PropType.HitDelay: { knownSkill.instantHitDelay = f; } break;

					case PropType.MaxProjectiles: { knownSkill.maxEffects = (int)f; } break;
					case PropType.CreateDelay: { knownSkill.projectileCreateDelay = f; } break;
					case PropType.BetweenCreateDelay: { knownSkill.projectileCreateDelayBetween = f; } break;
					case PropType.MoveSpeed: { knownSkill.projectileMoveSpeed = f; } break;
					case PropType.CollisionRayWidth: { knownSkill.collisionRayWidth = f; } break;
					case PropType.MaxLiveTime: { knownSkill.maxLiveTime = f; } break;

					case PropType.MaxTargetSelect: { knownSkill.maxEffects = (int)f; } break;
					case PropType.MaxDistanceFromSelf: { knownSkill.targetingDistance = f; } break;
					case PropType.TargetRangeAngle: { knownSkill.targetingAngle = (int)f; } break;
					case PropType.TargetRangeRadius: { knownSkill.targetingRadius = (int)f; } break;

					case PropType.MaxSecondaryTargets: { knownSkill.secondaryMaxTargets = (int)f; } break;
					case PropType.SecondaryRangeRadius: { knownSkill.secondaryRadius = (int)f; } break;
				}
			}
			else
			{
				Log(LogType.Error, "The Skill is not known by the Actor.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}