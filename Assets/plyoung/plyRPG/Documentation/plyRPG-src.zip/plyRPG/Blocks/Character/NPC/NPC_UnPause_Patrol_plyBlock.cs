﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "(dis)Enable Patrol", BlockType.Action, Order = 10,
		Description = "Can be used to pause a NPC that is following a path.")]
	public class NPC_UnPause_Patrol_plyBlock : plyBlock
	{
		[plyBlockField("state", ShowValue = true)]
		public plyEnabledState enable = plyEnabledState.Enabled;

		[plyBlockField("patrol of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be NPC object.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (npc == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					npc = o.GetComponent<NPCController>();
					if (npc == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. It should be an object with the NPCController component on it.");
						return BlockReturn.Error;
					}
				}
			}

			npc.EnablePatrol(enable == plyEnabledState.Enabled);
			if (false == cacheTarget) npc = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}