﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Select Prev Target", BlockType.Action, Order = 5, ShowName = "Select Prev Target",
		Description = "Player will find and select the previous targetable. This is similar to the player using the button bound to selecting the next target (default: TAB) but in reverse.")]
	public class Character_SelectPrevTarget_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Player.Instance.HandleButtonSelect(true, true);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}