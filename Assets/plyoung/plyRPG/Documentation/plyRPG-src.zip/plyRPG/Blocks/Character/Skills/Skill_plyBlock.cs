﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Skill", BlockType.Variable, Order = 6,
		ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns a reference to defined Skill.")]
	public class Skill_plyBlock : SystemObject_Value
	{
		[plyBlockField("Skill:", ShowIfTargetFieldInvalid = "skillNfo", ShowName = true, ShowValue = true, Description = "You can either select the Skill from a list or choose to identify it by its screen name, ident, meta, or short name. Choose 'none' from the list to use the ident method and then add a String block in the provided space so that you can enter the ident.")]
		public String_Value ident;

		[plyBlockField("Skill", CustomValueStyle = "plyBlox_BoldLabel")]
		public SkillFieldData skillNfo = new SkillFieldData();

		[plyBlockField("ident type", ShowIfTargetFieldInvalid = "skillNfo", Description = "What kind of value did you enter to identify the Skill by?")]
		public plyGameObjectIdentifyingType identType = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Skill, if you know it will not change, improving performance a little. This is done either way when the skill was selected from a list.")]
		public bool cacheTarget = false;

		private Skill skill = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available

			if (string.IsNullOrEmpty(skillNfo.id))
			{
				if (ident == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Item ident is not set.");
					return;
				}
			}
			else
			{
				// force caching if skillNfo is used since the skill will not change in this case
				cacheTarget = true;
				ident = null; // set to null since the nfo method is used
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (skill == null)
			{
				// ** need to lookup the skill
				if (ident != null)
				{
					// first find the id
					skill = SkillsAsset.Instance.GetDefinition(ident.RunAndGetString(), identType);
					if (skill == null)
					{
						Log(LogType.Error, "The specified Skill is not defined: " + ident.RunAndGetString() + " (" + identType + ")");
						return BlockReturn.Error;
					}
				}

				// ** skill was selected from list
				else
				{	// create an id and lookup the skill. gonna cache it since it won't change at runtime.
					UniqueID uid = new UniqueID(skillNfo.id);
					skill = SkillsAsset.Instance.GetDefinition(uid);
					if (skill == null)
					{
						Log(LogType.Error, "The Skill does not seem to be defined any longer.");
						return BlockReturn.Error;
					}
				}
			}

			value = skill;
			if (!cacheTarget) skill = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}