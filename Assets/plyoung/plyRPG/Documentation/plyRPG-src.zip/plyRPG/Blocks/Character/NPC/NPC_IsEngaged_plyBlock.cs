﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Is Engaged", BlockType.Condition, Order = 10,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if the NPC is engaged with (attacking/ interacting with) another character.")]
	public class NPC_IsEngaged_plyBlock : Bool_Value
	{
		[plyBlockField("target", ShowAfterField="is Engaged", ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (npc == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) npc = o.GetComponent<NPCController>();
				if (npc == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
					return BlockReturn.Error;
				}

			}

			value = npc.selectedTarget != null;

			if (false == cacheTarget) npc = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}