﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Get Skill Blox", BlockType.Variable, Order = 6, ShowName = "Get Blox",
		ReturnValueString = "Return - plyBlox", ReturnValueType = typeof(plyBlox_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Get a reference to the specified Skill's plyBlox object. Error if target Actor does not know the Skill or it has no plyBlox component on it.")]
	public class Skill_GetBlox_plyBlock : plyBlox_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to get plyBlox from.")]
		public SystemObject_Value val;

		[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = val.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			Skill sk = actor.GetKnownSkill(skill);
			
			if (sk == null)
			{
				Log(LogType.Error, "The Target does not know the Skill: " + skill.ToString());
				return BlockReturn.Error;
			}

			if (sk.blox == null)
			{
				Log(LogType.Error, "The Skill does not have a plyBlox and Local Variables: " + skill.ToString());
				return BlockReturn.Error;
			}

			value = sk.blox;

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}