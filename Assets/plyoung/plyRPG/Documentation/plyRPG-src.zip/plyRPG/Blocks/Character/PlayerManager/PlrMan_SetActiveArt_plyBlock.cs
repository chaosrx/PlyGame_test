﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Set Player Art", BlockType.Action, Order = 2,
		Description = "Set the 'active' art prefab in Player Manager from the list of defined prefabs. This is the art that will be used when 'Spawn Player' is called.")]
	public class PlrMan_SetActiveArt_plyBlock : plyBlock
	{

		[plyBlockField("Set Player Art", ShowAfterField = "in Player Manager", ShowName = true, ShowValue = true, DefaultObject=typeof(Int_Value), SubName = "Index - Integer", Description = "The index into the list of defined Art Prefabs, starting at (0)")]
		public Int_Value idx;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = idx != null;
			if (!blockIsValid) Log(LogType.Error, "The index field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			PlayerManager.Instance.SetActivePlayerArt(idx.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}