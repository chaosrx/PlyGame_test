﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Anim", "Character Legacy (plyRPG)", "Play Anim", BlockType.Action, Order = 5,
		 Description = "Request the target character to play an animation. The character legacy animation controller will be set on a 'controlled' state and will not automatically switch to idle or movement related animations until you reset it via the 'Go Idle' block.")]
	public class Chara_PlayAnim_plyBlock : plyBlock
	{
		[plyBlockField("Play character anim", ShowIfTargetFieldInvalid = "aniName", ShowName = true, ShowValue = true, Description = "Either add a String Block (containing the clip name) or enter the clip/ animation name directly in the properties.")]
		public String_Value aniNameStr;

		[plyBlockField("Play character anim:", CustomValueStyle = "plyBlox_BoldLabel")]
		public CharaAniClipNameData aniName = new CharaAniClipNameData();

		[plyBlockField("on", SubName = "Target - GameObject", EmptyValueName = "-self-", ShowName = true, ShowValue = true, Description = "The character.")]
		public GameObject_Value targetChara;

		[plyBlockField("Reverse", SubName = "Reverse - Boolean", Description = "Should the animation be played in reverse?")]
		public bool reverse = false;

		[plyBlockField("Speed", SubName = "Speed - Boolean", Description = "Playback speed. 1 is default speed that the animation was imported at.")]
		public float speed = 1f;

		[plyBlockField("WrapMode", SubName = "WrapMode", Description = "What should happen when the animation reaches it end.")]
		public WrapMode wrapMode = WrapMode.Default;

		[plyBlockField("PlayMode", SubName = "PlayMode", Description = "If PlayMode.StopSameLayer then all animations in the same layer will be stopped.\nIf PlayMode.StopAll then all animations currently playing will be stopped.")]
		public PlayMode playMode = PlayMode.StopSameLayer;

		[plyBlockField("Crossfade", SubName = "Crossfade - Boolean", Description = "Should the animation fade in over a period of time while other animations fade out?")]
		public bool crossfade = false;

		[plyBlockField("Fade Length", SubName = "Fade Length - Float", Description = "[Only if Crossfade = True]\nFade occur over a period of time in seconds.")]
		public float fadeLength = 0.3f;

		[plyBlockField("Queued", SubName = "Queued - Boolean", Description = "Should it wait for the previous animation to finish before being played?")]
		public bool queued = false;

		[plyBlockField("QueueMode", SubName = "QueueMode", Description = "[Only if Queued = True]\nIf QueueMode.CompleteOthers this animation will only start once all other animations have stopped playing.\nIf QueueMode.PlayNow this animation will start playing immediately on a duplicated animation state.")]
		public QueueMode queueMode = QueueMode.CompleteOthers;

		[plyBlockField("Cache target", Description = "Tell plyBlox whether it may cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private LegacyAnimControl animController;
		private string clipName;

		public override void Created()
		{
			blockIsValid = true;
			if (targetChara == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (animController == null)
			{
				GameObject go = targetChara == null ? owningBlox.gameObject : targetChara.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Target is invalid.");
					return BlockReturn.Error;
				}

				animController = go.GetComponent<LegacyAnimControl>();
				if (animController == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target does not have a legacy animation controller.");
					return BlockReturn.Error;
				}

				if (animController.ani == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The legacy animation controller's animation field is not valid.");
					return BlockReturn.Error;
				}
			}

			if (clipName == null)
			{
				// check if the animation clip is present
				bool found = false;
				clipName = aniName.IsValid() ? aniName.name : (aniNameStr == null ? null : aniNameStr.RunAndGetString());
				if (!string.IsNullOrEmpty(clipName))
				{
					foreach (AnimationState state in animController.ani)
					{
						if (state.name.Equals(clipName)) { found = true; break; }
					}
				}

				if (!found)
				{
					blockIsValid = false;
					Log(LogType.Error, "The named animation was not found.");
					return BlockReturn.Error;
				}
			}

			if (reverse) animController.ani[clipName].time = animController.ani[clipName].length;
			animController.ani[clipName].speed = reverse ? (-speed) : speed;
			animController.ani[clipName].wrapMode = wrapMode;

			if (crossfade)
			{
				animController.CrossfadeAnimation(clipName, fadeLength, queued, queueMode, playMode);
			}

			else
			{
				animController.PlayAnimation(clipName, queued, queueMode, playMode);
			}

			if (!cacheTarget) { animController = null; clipName = null; }
			else if (!aniName.IsValid()) clipName = null; // do not cache name if using aniNameStr
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}