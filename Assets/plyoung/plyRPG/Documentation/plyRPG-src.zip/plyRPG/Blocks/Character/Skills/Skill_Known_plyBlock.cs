﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Skill Known", BlockType.Condition, Order = 6,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if the Actor knows the Skill, else False.")]
	public class Skill_Known_plyBlock : Bool_Value
	{
		[plyBlockField("Target", EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("knows Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to check for.")]
		public SystemObject_Value val;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = val.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			value = actor.KnowSkill(skill);

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}