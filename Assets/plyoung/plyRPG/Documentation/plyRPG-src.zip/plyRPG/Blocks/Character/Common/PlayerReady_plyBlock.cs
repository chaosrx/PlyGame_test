﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Common (plyRPG)", "Player is Ready", BlockType.Condition, Order = 1, ShowName = "Player is Ready",
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Use this to check if the Player is ready before trying to access it via a block like 'Player'. This should especially be done when you want to access player data in Events that are not on the Player object itself as the player might not be ready by the time those events are triggered.")]
	public class PlayerReady_plyBlock : Bool_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = Player.IsReady;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}