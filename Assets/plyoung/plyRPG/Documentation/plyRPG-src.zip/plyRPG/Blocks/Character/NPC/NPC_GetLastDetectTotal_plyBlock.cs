﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Last Detected Total", BlockType.Variable, Order = 10, ShowName = "Last Detected Total",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the count of how many characters where last detected by the NPC. The list of detected characters is only updated when the NPC does detection so the bets place to use this is ion the `NPC > On Detected Characters` as the list is not continuously updated for other events.")]
	public class NPC_GetLastDetectTotal_plyBlock : Int_Value
	{
		[plyBlockField("by", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (npc == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null) npc = o.GetComponent<NPCController>();
					if (npc == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
						return BlockReturn.OK;
					}

				}

				value = npc.LastDetectedTotal();

				if (false == cacheTarget) npc = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}